param([string]$Target = "$env:LOCALAPPDATA\Programs\DeltaEngineering", [switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$base = 'https://github.com/FreeCAD/FreeCAD/releases/download/1.1.4'
$name = 'FreeCAD_1.1.4-Windows-x86_64-py311-installer.exe'
$tmp = Join-Path $env:TEMP $name
Write-Host "Downloading official FreeCAD 1.1.4 (about 520 MB)..."
Invoke-WebRequest "$base/$name" -OutFile $tmp -UseBasicParsing
$want = (([string](Invoke-RestMethod "$base/$name-SHA256.txt")) -split '\s+')[0]
$got = (Get-FileHash $tmp -Algorithm SHA256).Hash
if ($got -ine $want) { throw "SHA256 mismatch: expected $want got $got" }
Write-Host "SHA256 verified. Installing to $Target ..."
$p = Start-Process $tmp -ArgumentList '/S', "/D=$Target" -Wait -PassThru
if ($p.ExitCode -ne 0) { throw "FreeCAD installer exit code $($p.ExitCode)" }
if (-not (Test-Path "$Target\bin\FreeCAD.exe")) { throw "FreeCAD.exe not found after install" }
New-Item -ItemType Directory -Force "$Target\Mod" | Out-Null
Copy-Item "$PSScriptRoot\Mod\DeltaEngineering" "$Target\Mod\DeltaEngineering" -Recurse -Force
Copy-Item "$PSScriptRoot\LaunchDelta.FCMacro" "$Target\LaunchDelta.FCMacro" -Force
if (-not $NoShortcut) {
  $dir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
  $s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $dir 'Delta Engineering.lnk'))
  $s.TargetPath = "$Target\bin\FreeCAD.exe"
  $s.Arguments = "`"$Target\LaunchDelta.FCMacro`""
  $s.WorkingDirectory = $Target
  $s.Save()
}
Write-Host "Done. Start 'Delta Engineering' from the Start Menu."
