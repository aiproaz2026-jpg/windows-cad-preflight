@echo off
setlocal
set "DEST=%APPDATA%\FreeCAD\Mod\DeltaEngineering"
if not exist "%ProgramFiles%\FreeCAD 1.1\bin\FreeCAD.exe" echo Install official FreeCAD 1.1.4 first from freecad.org
xcopy /E /I /Y "%~dp0Mod\DeltaEngineering" "%DEST%"
echo Installed to %DEST%. Start FreeCAD and choose the Delta workbench.
pause
