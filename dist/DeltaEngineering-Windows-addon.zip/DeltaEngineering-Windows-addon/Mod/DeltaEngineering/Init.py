# Preload the trusted local parametric-object classes before project restoration.
# FreeCAD's document import guard otherwise refuses unregistered proxy modules.
import DeltaEngineering.core

import DeltaEngineering.domain

import DeltaEngineering.routing

import DeltaEngineering.profiles

import DeltaEngineering.branches

import DeltaEngineering.port_connections

import DeltaEngineering.patterns
