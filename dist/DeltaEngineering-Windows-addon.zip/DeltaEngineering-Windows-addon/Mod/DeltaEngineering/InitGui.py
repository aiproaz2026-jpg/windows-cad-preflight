from DeltaEngineering.gui import register
register()
