# SPDX-License-Identifier: GPL-3.0-or-later
"""User-created documents, no pilot object-name dependency."""
import FreeCAD as App


def ensure_project(doc):
    doc.UndoMode=1
    groups={}
    for reserved in ('DrawingSystem','MechanicalSystem','PipingSystem','ElectricalSystem'):
        existing=doc.getObject(reserved)
        if existing and not hasattr(existing,'Group'):raise ValueError('Reserved group name is already used: '+reserved)
    for name,label in [('DrawingSystem','الرسم والأبعاد'),('MechanicalSystem','الميكانيكا'),('PipingSystem','المواسير'),('ElectricalSystem','الكهرباء')]:
        obj=doc.getObject(name)
        if obj and not hasattr(obj,'Group'):raise ValueError('Reserved group name is already used: '+name)
        if not obj:obj=doc.addObject('App::DocumentObjectGroup',name)
        obj.Label=label;groups[name]=obj
    return groups


def new_project(name='EngineeringProject'):
    doc=App.newDocument(name)
    ensure_project(doc)
    return doc


def add_to(doc,group,obj):
    ensure_project(doc)[group].addObject(obj)


def model_objects(doc):
    """Export visible leaf geometry, not dimensions/construction paths duplicated by pipes."""
    pipe_sources={o.SourcePath.Name for o in doc.Objects if getattr(o,'SourcePath',None)}
    pipe_sources.update(o.Source.Name for o in doc.Objects if o.TypeId=='Part::Revolution' and o.Source)
    pipe_sources.update(o.PatternSource.Name for o in doc.Objects if getattr(o,'PatternSource',None))
    pipe_sources.update(o.Profile.Name for o in doc.Objects if getattr(o,'Profile',None) and hasattr(o.Profile,'Name'))
    for o in doc.Objects:
        if o.TypeId=='Part::Fillet' and o.Base:pipe_sources.add(o.Base.Name)
        if o.TypeId in ('Part::Cut','Part::Fuse','Part::Common'):
            pipe_sources.update(source.Name for source in (o.Base,o.Tool) if source)
    result=[]
    for obj in doc.Objects:
        if obj.TypeId in ('App::Line','App::Plane','App::Point','App::Origin','App::OriginFeature'):continue
        if obj.isDerivedFrom('App::DocumentObjectGroup'):continue
        if not hasattr(obj,'Shape') or obj.Shape.isNull():continue
        if hasattr(obj,'DeviceType') or hasattr(obj,'SourceTerminal') or hasattr(obj,'SourceDevice'):continue
        if obj.Name in pipe_sources or hasattr(obj,'LinkedGeometry'):continue
        if getattr(obj,'Visibility',True) is False:continue
        if any(hasattr(parent,'ViewObject') and not parent.ViewObject.Visibility for parent in obj.InListRecursive if parent.isDerivedFrom('App::Part') or parent.isDerivedFrom('PartDesign::Body')):continue
        if obj.isDerivedFrom('App::Part') or obj.isDerivedFrom('PartDesign::Body'):continue
        # Native PartDesign intermediate shapes are not separate export items.
        if obj.isDerivedFrom('Sketcher::SketchObject'):continue
        if any(parent.isDerivedFrom('PartDesign::Body') and parent.Tip!=obj for parent in obj.InList):continue
        result.append(obj)
    return result


def electrical_objects(doc):
    return [o for o in doc.Objects if hasattr(o,'DeviceType') or hasattr(o,'SourceTerminal')]


def ancestor_placement(obj):
    if hasattr(obj,'getGlobalPlacement'):
        return obj.getGlobalPlacement().multiply(obj.Placement.inverse())
    parent=obj.getParentGeoFeatureGroup() if hasattr(obj,'getParentGeoFeatureGroup') else None
    return parent.getGlobalPlacement() if parent else App.Placement()


def world_shape(obj):
    """Shape copy including native parent Part placement, without double placement."""
    shape=obj.Shape.copy();shape.Placement=ancestor_placement(obj).multiply(shape.Placement)
    return shape


def world_point(obj,point):
    return ancestor_placement(obj).multiply(obj.Placement).multVec(point)


def require_root_frame(obj,operation):
    """Reject an unsupported parent transform before building dependent geometry."""
    placement=ancestor_placement(obj)
    if obj.getParentGeoFeatureGroup() or placement.Base.Length>1e-7 or abs(placement.Rotation.Angle)>1e-7:
        raise ValueError(operation+': parent Part/Body containers are not supported by this custom command; use root-frame sources')
