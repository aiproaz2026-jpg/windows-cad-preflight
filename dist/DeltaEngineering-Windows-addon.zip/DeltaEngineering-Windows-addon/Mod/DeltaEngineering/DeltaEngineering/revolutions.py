# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded native Part revolution from a planar profile, retained native history."""
import math
import FreeCAD as App
from .precision import scalar,length


def parameters(source,base,axis,angle):
    from .profiles import profile_face
    face=profile_face(source);angle=scalar(angle)
    if not 0<angle<=360:raise ValueError('Revolution angle must be above zero and at most 360 degrees')
    if not all(math.isfinite(v) for v in (base.x,base.y,base.z,axis.x,axis.y,axis.z)) or axis.Length<1e-7:raise ValueError('Use finite axis base and a nonzero axis direction')
    axis=App.Vector(axis);axis.normalize();normal=face.normalAt(0,0);point=face.Vertexes[0].Point
    if abs(normal.dot(axis))>1e-7 or abs(normal.dot(base-point))>1e-6:raise ValueError('Revolution axis must lie in profile plane')
    # Bound the supported workflow to an axis outside/tangent to the entire
    # profile's conservative bounding box. No self-crossing revolve promise.
    side=normal.cross(axis);box=face.BoundBox
    distances=[side.dot(App.Vector(x,y,z)-base) for x in (box.XMin,box.XMax) for y in (box.YMin,box.YMax) for z in (box.ZMin,box.ZMax)]
    if min(distances)<-1e-6 and max(distances)>1e-6:raise ValueError('Axis crosses profile bounding box; this bounded workflow requires a profile on one side')
    return App.Vector(base),axis,angle


def validate(obj):
    if obj.Shape.isNull() or not obj.Shape.isValid() or len(obj.Shape.Solids)!=1:raise ValueError('Revolution must produce one valid solid')
    if 'Invalid' in obj.State or 'Error' in obj.State:raise ValueError('Native revolution reports an invalid state')


def create(doc,source,base,axis,angle=360):
    if source.Document!=doc:raise ValueError('Select a planar source in active document')
    base,axis,angle=parameters(source,base,axis,angle)
    doc.openTransaction('Native planar-profile revolution')
    try:
        obj=doc.addObject('Part::Revolution','ProfileRevolution');obj.Label='دوران مصمت أصلي مرتبط بمقطع'
        obj.Source=source;obj.Base=base;obj.Axis=axis;obj.Angle=angle;obj.Solid=True;doc.recompute();validate(obj)
        from .documents import add_to
        add_to(doc,'MechanicalSystem',obj)
        if App.GuiUp:source.Visibility=False;obj.ViewObject.ShapeColor=(0.72,0.75,0.8)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def update(doc,obj,base,axis,angle):
    if obj.Document!=doc or obj.TypeId!='Part::Revolution' or not obj.Source:raise ValueError('Select a native profile revolution')
    base,axis,angle=parameters(obj.Source,base,axis,angle)
    doc.openTransaction('Edit native profile revolution')
    try:
        obj.Base=base;obj.Axis=axis;obj.Angle=angle;doc.recompute();validate(obj)
        from .validation import valid_document
        valid_document(doc);doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
