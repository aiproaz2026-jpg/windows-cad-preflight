from .arabic import message
from .arabic_qt import Messages,Inputs
# SPDX-License-Identifier: GPL-3.0-or-later
from PySide import QtCore,QtWidgets
import FreeCAD as App,FreeCADGui as Gui
from . import electrical as graph
from .core import Device
from .domain import netlist,add_terminal_wire,add_terminal


class ElectricalPanel(QtWidgets.QDockWidget):
    def __init__(self):
        super().__init__('محرر الكهرباء التجريبي',Gui.getMainWindow())
        self.setObjectName('DeltaElectricalPanel')
        self.setLayoutDirection(QtCore.Qt.RightToLeft)
        area=QtWidgets.QWidget();self.setWidget(area)
        layout=QtWidgets.QVBoxLayout(area)
        note=QtWidgets.QLabel('قوالب أصلية توضيحية، ليست IEC/ANSI. توصيلات منطقية فقط دون حسابات أو اعتماد هندسي. القالب يخص الرمز الجديد فقط.')
        note.setWordWrap(True);layout.addWidget(note)
        from .symbols import TEMPLATES
        self.template=QtWidgets.QComboBox()
        for key,(label,terminals) in TEMPLATES.items():self.template.addItem(label,key)
        self.template.setToolTip('قوالب توضيحية أصلية فقط، ليست رموز IEC/ANSI أو منتجات مصنعة. اختيار القالب لا يعدّل الرموز الموجودة.')
        layout.addWidget(self.template)
        layout.addWidget(QtWidgets.QLabel('الرموز'))
        self.devices=QtWidgets.QListWidget();layout.addWidget(self.devices)
        self.devices.currentItemChanged.connect(self.refresh_terminals)
        layout.addWidget(QtWidgets.QLabel('أطراف الرمز المحدد'))
        self.terminals=QtWidgets.QListWidget();layout.addWidget(self.terminals)
        grid=QtWidgets.QGridLayout();layout.addLayout(grid)
        actions=[('رمز جديد',self.new_device),('تغيير معرّف الرمز',self.rename_device),('حذف الرمز',self.delete_device),('طرف جديد',self.new_terminal),('تسمية الطرف',self.rename_terminal),('حذف الطرف',self.delete_terminal),('توصيل طرفين',self.connect),('تحديث',self.refresh),('موضع الرمز بدقة',self.move_device),('إزاحة مسار السلك',self.route_wire),('فحص مجموعات الأطراف',self.connectivity),('ترتيب الأطراف واتجاهها',self.layout_terminals)]
        for i,(label,callback) in enumerate(actions):
            button=QtWidgets.QPushButton(label);button.clicked.connect(lambda checked=False,fn=callback:self.safe(fn))
            grid.addWidget(button,i//2,i%2)
        layout.addWidget(QtWidgets.QLabel('التوصيلات، حدد سلكاً لإظهاره في الرسم'))
        self.connections=QtWidgets.QListWidget();layout.addWidget(self.connections)
        self.connections.itemSelectionChanged.connect(self.select_wire)
        row=QtWidgets.QHBoxLayout();layout.addLayout(row)
        for label,callback in [('تسمية السلك',self.rename_wire),('فصل السلك',self.delete_wire)]:
            button=QtWidgets.QPushButton(label);button.clicked.connect(lambda checked=False,fn=callback:self.safe(fn));row.addWidget(button)
        self.status=QtWidgets.QLabel();self.status.setWordWrap(True);layout.addWidget(self.status)
        self.setMinimumWidth(350);self.setMaximumWidth(440)
        self.refresh()
        for label in self.findChildren(QtWidgets.QLabel):label.setTextFormat(QtCore.Qt.PlainText)
        for items in (self.devices,self.terminals,self.connections):items.setLayoutDirection(QtCore.Qt.LeftToRight)

    def doc(self):
        if not App.ActiveDocument:raise ValueError('افتح مشروعاً أولاً')
        if getattr(self,'doc_name',App.ActiveDocument.Name)!=App.ActiveDocument.Name:raise ValueError('تغيّر المستند، اضغط تحديث قبل التعديل')
        App.ActiveDocument.UndoMode=1
        return App.ActiveDocument
    def safe(self,fn):
        try:fn();self.refresh()
        except Exception as exc:
            self.status.setText('لم يتم التعديل: '+message(exc))
            Messages.warning(self,'تعذر التعديل',message(exc))
    def device(self):
        item=self.devices.currentItem()
        if not item:raise ValueError('حدد رمزاً')
        obj=self.doc().getObject(item.data(QtCore.Qt.UserRole))
        if not obj:raise ValueError('الرمز لم يعد موجوداً، اضغط تحديث')
        return obj
    def terminal(self):
        item=self.terminals.currentItem()
        if not item:raise ValueError('حدد طرفاً')
        return item.text()
    def wire(self):
        item=self.connections.currentItem()
        if not item:raise ValueError('حدد سلكاً')
        obj=self.doc().getObject(item.data(QtCore.Qt.UserRole))
        if not obj:raise ValueError('السلك لم يعد موجوداً، اضغط تحديث')
        return obj
    def text(self,title,label,initial=''):
        value,ok=Inputs.getText(self,title,label,text=initial)
        return value.strip() if ok else None
    def refresh(self):
        old=self.devices.currentItem()
        name=old.data(QtCore.Qt.UserRole) if old else None
        self.devices.clear();self.connections.clear()
        d=App.ActiveDocument
        self.doc_name=d.Name if d else None
        if not d:self.status.setText('لا يوجد مشروع مفتوح');return
        for obj in d.Objects:
            if hasattr(obj,'DeviceType'):
                item=QtWidgets.QListWidgetItem(obj.Tag);item.setData(QtCore.Qt.UserRole,obj.Name);self.devices.addItem(item)
                if obj.Name==name:self.devices.setCurrentItem(item)
            if hasattr(obj,'SourceTerminal'):
                source=obj.SourceDevice.Tag if obj.SourceDevice else '?'
                target=obj.TargetDevice.Tag if obj.TargetDevice else '?'
                item=QtWidgets.QListWidgetItem(obj.WireId+' : '+source+':'+obj.SourceTerminal+' → '+target+':'+obj.TargetTerminal)
                item.setData(QtCore.Qt.UserRole,obj.Name);self.connections.addItem(item)
        if self.devices.currentRow()<0 and self.devices.count():self.devices.setCurrentRow(0)
        self.refresh_terminals()
        try:
            rows=netlist(d);self.status.setText('تم فحص المراجع: '+str(len(rows))+' توصيلات منطقية')
        except ValueError as exc:self.status.setText('يوجد خطأ في المراجع: '+message(exc))
    def refresh_terminals(self,*args):
        self.terminals.clear()
        try:
            obj=self.device();self.terminals.addItems(list(obj.Terminals))
            Gui.Selection.clearSelection();Gui.Selection.addSelection(obj)
        except ValueError:pass
    def select_wire(self):
        try:Gui.Selection.clearSelection();Gui.Selection.addSelection(self.wire())
        except ValueError:pass
    def new_device(self):
        tag=self.text('رمز جديد','المعرّف')
        if tag is None:return
        d=self.doc()
        if not tag or any(getattr(o,'Tag',None)==tag for o in d.Objects):raise ValueError('المعرّف فارغ أو مكرر')
        from .symbols import create
        count=sum(hasattr(o,'DeviceType') for o in d.Objects)
        obj=create(d,self.template.currentData(),tag,App.Vector(count*300,0,0))
        if count:obj.TerminalSide='Left';d.recompute()
        Gui.activeDocument().activeView().fitAll()
    def rename_device(self):
        obj=self.device();tag=self.text('تغيير المعرّف','المعرّف الجديد',obj.Tag)
        if tag is not None and tag!=obj.Tag:graph.rename_device(self.doc(),obj,tag)
    def new_terminal(self):
        name=self.text('طرف جديد','اسم الطرف')
        if name is not None:graph.append_terminal(self.doc(),self.device(),name)
    def rename_terminal(self):
        old=self.terminal();new=self.text('تسمية الطرف','الاسم الجديد',old)
        if new is not None and new!=old:graph.rename_terminal(self.doc(),self.device(),old,new)
    def confirm_cascade(self,count):
        return Messages.question(self,'حذف التوصيلات','هذا الحذف سيزيل '+str(count)+' سلك. هل تريد المتابعة؟',Messages.Yes|Messages.No)==Messages.Yes
    def delete_terminal(self):
        obj=self.device();name=self.terminal();count=len(graph.wires_for(self.doc(),obj,name))
        if count and not self.confirm_cascade(count):return
        graph.remove_terminal(self.doc(),obj,name,True)
    def delete_device(self):
        obj=self.device();count=len(graph.wires_for(self.doc(),obj))
        if not self.confirm_cascade(count):return
        graph.remove_device(self.doc(),obj,True)
    def connect(self):
        source=self.device();terminal=self.terminal();d=self.doc()
        targets=[o for o in d.Objects if hasattr(o,'DeviceType') and o!=source]
        if not targets:raise ValueError('أضف رمزاً آخر أولاً')
        tag,ok=Inputs.getItem(self,'طرف النهاية','الرمز',[o.Tag for o in targets],0,False)
        if not ok:return
        target=next(o for o in targets if o.Tag==tag)
        end,ok=Inputs.getItem(self,'طرف النهاية','الطرف',list(target.Terminals),0,False)
        if not ok:return
        wire_id=self.text('توصيل جديد','معرّف السلك')
        if wire_id is None:return
        def action():
            wire=add_terminal_wire(d,source,terminal,target,end,wire_id)
            group=d.getObject('ElectricalSystem')
            if group:group.addObject(wire)
        graph._transaction(d,'Connect terminals',action)
    def rename_wire(self):
        obj=self.wire();name=self.text('تسمية السلك','المعرّف الجديد',obj.WireId)
        if name is not None and name!=obj.WireId:graph.rename_wire(self.doc(),obj,name)
    def delete_wire(self):graph.disconnect(self.doc(),self.wire())

    def move_device(self):
        obj=self.device();values=[]
        from .precision import length
        for axis,value in zip(('X','Y','Z'),(obj.Position.x,obj.Position.y,obj.Position.z)):
            text,ok=Inputs.getText(self,'موضع الرمز','موضع '+axis+' بوحدات طول',text=str(value)+' mm')
            if not ok:return
            values.append(length(text))
        graph.move_device(self.doc(),obj,App.Vector(*values));Gui.activeDocument().activeView().fitAll()
    def route_wire(self):
        obj=self.wire()
        value,ok=Inputs.getDouble(self,'مسار السلك','إزاحة مستوى المسار عن منتصف الطرفين (مم)، بدون تجنب تصادم تلقائي',obj.SchematicOffset.Value,-1000000,1000000,2)
        if ok:graph.wire_offset(self.doc(),obj,value)

    def layout_terminals(self):
        obj=self.device();d=self.doc()
        side,ok=Inputs.getItem(self,'ترتيب الأطراف','جانب الأطراف في الرسم فقط',['يمين','يسار'],0 if obj.TerminalSide=='Right' else 1,False)
        if not ok:return
        text,ok=Inputs.getMultiLineText(self,'ترتيب الأطراف','اسم طرف في كل سطر، من الأعلى للأسفل. يجب إدراج الأسماء الحالية مرة واحدة، دون إضافة أو حذف أو إعادة تسمية. لا توجد مطابقة لترتيب أطراف منتج حقيقي.',text='\n'.join(obj.Terminals))
        if not ok:return
        graph.terminal_layout(d,obj,[name.strip() for name in text.splitlines() if name.strip()],'Right' if side=='يمين' else 'Left')
    def connectivity(self):
        from .connectivity import inspect
        report=inspect(self.doc());dialog=QtWidgets.QDialog(self);dialog.setWindowTitle('مجموعات أطراف متصلة صراحة فقط')
        box=QtWidgets.QVBoxLayout(dialog)
        note=QtWidgets.QLabel('لا توجد وصلات داخلية مفترضة بين أطراف الجهاز. تقاطعات الخطوط ليست عقداً. ليس فحص دوائر أو جهد أو تيار أو أمان. الطرف غير الموصول ليس خطأ تصميم مؤكداً.')
        note.setTextFormat(QtCore.Qt.PlainText);note.setWordWrap(True);box.addWidget(note)
        table=QtWidgets.QTableWidget(len(report['nets']),3);table.setHorizontalHeaderLabels(['المجموعة','الأطراف','الأسلاك'])
        table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        for row,net in enumerate(report['nets']):
            values=[net['id']+(' / غير موصول' if net['isolated'] else ''),', '.join(m['device']+':'+m['terminal'] for m in net['members']),', '.join(net['wires'])]
            for col,value in enumerate(values):table.setItem(row,col,QtWidgets.QTableWidgetItem(value))
        table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch);table.resizeRowsToContents();box.addWidget(table)
        duplicates=QtWidgets.QLabel('أسلاك إضافية بين نفس الطرفين: '+(', '.join(report['duplicate_pair_wires']) or 'لا يوجد'));duplicates.setWordWrap(True);box.addWidget(duplicates)
        close=QtWidgets.QPushButton('إغلاق');close.clicked.connect(dialog.accept);box.addWidget(close);dialog.resize(740,460);dialog.exec_()


def show_panel():
    existing=Gui.getMainWindow().findChild(QtWidgets.QDockWidget,'DeltaElectricalPanel')
    if existing:existing.show();existing.raise_();return existing
    panel=ElectricalPanel()
    Gui.getMainWindow().addDockWidget(QtCore.Qt.RightDockWidgetArea,panel)
    panel.show()
    return panel
