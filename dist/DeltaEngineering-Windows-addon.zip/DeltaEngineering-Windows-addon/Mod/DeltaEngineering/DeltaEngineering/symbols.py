# SPDX-License-Identifier: GPL-3.0-or-later
"""Original illustrative shapes, not IEC/ANSI/manufacturer symbols."""
import FreeCAD as App,Part

TEMPLATES={
 'Generic block':('رمز عام',('1','2')),
 'Motor concept':('محرك توضيحي، غير قياسي',('U','V','W','PE')),
 'Switch concept':('مفتاح مفتوح توضيحي، غير قياسي',('1','2')),
 'Coil concept':('ملف توضيحي، غير قياسي',('A1','A2')),
 'Earth concept':('تأريض توضيحي، غير قياسي',('PE',))}


def outline(device):
    p=device.Position;kind=device.SymbolTemplate
    def v(x,y):return p+App.Vector(x,y,0)
    def line(a,b):return Part.makeLine(v(*a),v(*b))
    def poly(points):return Part.makePolygon([v(x,y) for x,y in points])
    if kind=='Motor concept':
        return [Part.makeCircle(35,p),poly([(-18,-15),(-18,15),(0,-5),(18,15),(18,-15)])]
    if kind=='Switch concept':return [line((-35,0),(-15,0)),line((-15,0),(20,25)),line((25,0),(35,0))]
    if kind=='Coil concept':return [poly([(-28,-22),(-28,22),(28,22),(28,-22),(-28,-22)]),line((-18,-15),(18,15))]
    if kind=='Earth concept':return [line((0,28),(0,0)),line((-30,0),(30,0)),line((-20,-10),(20,-10)),line((-10,-20),(10,-20))]
    return [poly([(-60,-40),(60,-40),(60,40),(-60,40),(-60,-40)])]


def create(doc,kind,tag,position):
    if kind not in TEMPLATES:raise ValueError('Choose an explicit illustrative symbol template')
    tag=tag.strip()
    if not tag or any(getattr(o,'Tag',None)==tag for o in doc.Objects):raise ValueError('Use a unique nonempty device tag')
    from .core import Device
    from .domain import add_terminal
    from .documents import add_to
    from .electrical import _transaction
    def action():
        obj=doc.addObject('PartDesign::FeaturePython','IllustrativeDevice');obj.Label=tag
        Device(obj,tag,position);obj.addProperty('App::PropertyEnumeration','SymbolTemplate','Electrical');obj.SymbolTemplate=list(TEMPLATES);obj.SymbolTemplate=kind
        obj.addProperty('App::PropertyString','SymbolScope','Electrical');obj.SymbolScope='Original illustrative shape only. Not IEC/ANSI, manufacturer, wiring, rating or circuit validation.';obj.setEditorMode('SymbolScope',1)
        obj.setEditorMode('SymbolTemplate',1)
        obj.DeviceType=kind
        for name in TEMPLATES[kind][1]:add_terminal(obj,name)
        add_to(doc,'ElectricalSystem',obj)
        if App.GuiUp:obj.ViewObject.LineColor=(0.08,0.2,0.35);obj.ViewObject.LineWidth=2.5
        return obj
    return _transaction(doc,'Add illustrative typed device',action)
