# SPDX-License-Identifier: GPL-3.0-or-later
"""Geometric quarter-elbows and explicit electrical terminal graph.
Catalog/pressure-rating checks and electrical design calculations are not provided.
"""
import math
import FreeCAD as App
import Part
from .core import positive


class QuarterElbow:
    def __init__(self, obj, radius=150, diameter=100, wall=5):
        for prop in ('BendRadius','OuterDiameter','WallThickness'):
            obj.addProperty('App::PropertyLength',prop,'Elbow')
        obj.addProperty('App::PropertyLength','CenterlineLength','Quantities')
        obj.addProperty('App::PropertyString','Validation','Status')
        obj.BendRadius,obj.OuterDiameter,obj.WallThickness=radius,diameter,wall
        obj.setEditorMode('CenterlineLength',1)
        obj.setEditorMode('Validation',1)
        obj.Proxy=self
        if App.GuiUp: obj.ViewObject.Proxy=0

    def execute(self,obj):
        try:
            r=positive(obj.BendRadius.Value,'Bend radius')
            od=positive(obj.OuterDiameter.Value,'Outer diameter')
            t=positive(obj.WallThickness.Value,'Wall thickness')
            if t>=od/2 or r<=od/2:
                raise ValueError('Require wall < OD/2 and bend radius > OD/2')
            a=App.Vector(r,0,0)
            mid=App.Vector(r/math.sqrt(2),r/math.sqrt(2),0)
            b=App.Vector(0,r,0)
            path=Part.Wire(Part.Arc(a,mid,b).toShape())
            def solid(radius):
                profile=Part.Wire(Part.makeCircle(radius,a,App.Vector(0,1,0)))
                return path.makePipeShell([profile],True,True)
            obj.Shape=solid(od/2).cut(solid(od/2-t))
            obj.CenterlineLength=math.pi*r/2
            obj.Validation='Geometric 90-degree elbow; no catalog rating'
        except (ValueError,RuntimeError) as exc:
            obj.Shape=Part.Shape()
            obj.CenterlineLength=0
            obj.Validation=str(exc)


def add_terminal(device,name):
    if not hasattr(device,'Terminals'):
        device.addProperty('App::PropertyStringList','Terminals','Electrical')
    if not name or name in device.Terminals:
        raise ValueError('Terminal must be nonempty and unique on device')
    device.Terminals=list(device.Terminals)+[name]


def add_terminal_wire(doc,source,source_terminal,target,target_terminal,wire_id):
    from .core import Connection
    if source.Document!=doc or target.Document!=doc:
        raise ValueError('Devices must belong to the same document')
    if source_terminal not in getattr(source,'Terminals',[]) or target_terminal not in getattr(target,'Terminals',[]):
        raise ValueError('Unknown terminal')
    if source==target and source_terminal==target_terminal:
        raise ValueError('Cannot connect a terminal to itself')
    if not wire_id or any(getattr(o,'WireId',None)==wire_id for o in doc.Objects):
        raise ValueError('Wire identifier must be nonempty and unique')
    obj=doc.addObject('PartDesign::FeaturePython','TerminalWire')
    obj.addProperty('App::PropertyString','SourceTerminal','Electrical')
    obj.addProperty('App::PropertyString','TargetTerminal','Electrical')
    obj.SourceTerminal,obj.TargetTerminal=source_terminal,target_terminal
    Connection(obj,source,target,wire_id)
    return obj


def netlist(doc):
    devices=[o for o in doc.Objects if hasattr(o,'DeviceType')]
    tags=[o.Tag for o in devices]
    if len(tags)!=len(set(tags)) or any(not t for t in tags):
        raise ValueError('Device tags must be nonempty and unique')
    result=[]
    seen=set()
    for o in doc.Objects:
        if not hasattr(o,'SourceTerminal'): continue
        if not o.WireId or o.WireId in seen:
            raise ValueError('Wire identifiers must be nonempty and unique')
        seen.add(o.WireId)
        a,b=o.SourceDevice,o.TargetDevice
        if not a or not b or o.SourceTerminal not in a.Terminals or o.TargetTerminal not in b.Terminals:
            raise ValueError('Dangling terminal connection: '+o.Name)
        result.append({'wire':o.WireId,'source':{'device':a.Tag,'terminal':o.SourceTerminal},
                       'target':{'device':b.Tag,'terminal':o.TargetTerminal}})
    return result
