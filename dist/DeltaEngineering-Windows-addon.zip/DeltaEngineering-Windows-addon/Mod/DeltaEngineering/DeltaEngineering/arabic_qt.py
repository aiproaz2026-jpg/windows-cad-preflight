# SPDX-License-Identifier: GPL-3.0-or-later
"""Scoped Qt Arabic presentation for Delta-owned dialogs only."""
from PySide import QtCore,QtWidgets
from .arabic import message

BUTTONS={'OK':'موافق','Cancel':'إلغاء','&Cancel':'إلغاء','&Yes':'نعم','Yes':'نعم','&No':'لا','No':'لا','Close':'إغلاق','&Close':'إغلاق','Save':'حفظ','&Save':'حفظ','Open':'فتح','&Open':'فتح','Discard':'تجاهل','Apply':'تطبيق','Help':'مساعدة','Reset':'إعادة ضبط','Abort':'إيقاف','Retry':'إعادة المحاولة','Ignore':'تجاهل'}
class _DialogStyle(QtCore.QObject):
    def __init__(self,title):super().__init__();self.title=title
    def eventFilter(self,obj,event):
        if event.type()==QtCore.QEvent.Show and isinstance(obj,QtWidgets.QDialog) and obj.windowTitle()==self.title:
            prepare(obj)
        return False

def prepare(widget):
    widget.setLayoutDirection(QtCore.Qt.RightToLeft)
    for edit in widget.findChildren(QtWidgets.QLineEdit)+widget.findChildren(QtWidgets.QAbstractSpinBox)+widget.findChildren(QtWidgets.QPlainTextEdit):
        edit.setLayoutDirection(QtCore.Qt.LeftToRight)
    for label in widget.findChildren(QtWidgets.QLabel):label.setTextFormat(QtCore.Qt.PlainText)
    for button in widget.findChildren(QtWidgets.QAbstractButton):
        if button.text() in BUTTONS:button.setText(BUTTONS[button.text()])
    return widget

def _call(fn,parent,title,*args,**kwargs):
    app=QtWidgets.QApplication.instance();style=_DialogStyle(title)
    app.installEventFilter(style)
    try:return fn(parent,title,*args,**kwargs)
    finally:app.removeEventFilter(style)

class Messages:
    Yes=QtWidgets.QMessageBox.Yes;No=QtWidgets.QMessageBox.No
    @staticmethod
    def warning(parent,title,text,*args,**kwargs):return _call(QtWidgets.QMessageBox.warning,parent,title,message(text),*args,**kwargs)
    @staticmethod
    def critical(parent,title,text,*args,**kwargs):return _call(QtWidgets.QMessageBox.critical,parent,title,message(text),*args,**kwargs)
    @staticmethod
    def information(parent,title,text,*args,**kwargs):return _call(QtWidgets.QMessageBox.information,parent,title,text,*args,**kwargs)
    @staticmethod
    def question(parent,title,text,*args,**kwargs):return _call(QtWidgets.QMessageBox.question,parent,title,text,*args,**kwargs)
class Inputs:
    @staticmethod
    def getText(parent,title,*args,**kwargs):return _call(QtWidgets.QInputDialog.getText,parent,title,*args,**kwargs)
    @staticmethod
    def getMultiLineText(parent,title,*args,**kwargs):return _call(QtWidgets.QInputDialog.getMultiLineText,parent,title,*args,**kwargs)
    @staticmethod
    def getItem(parent,title,*args,**kwargs):return _call(QtWidgets.QInputDialog.getItem,parent,title,*args,**kwargs)
    @staticmethod
    def getInt(parent,title,*args,**kwargs):return _call(QtWidgets.QInputDialog.getInt,parent,title,*args,**kwargs)
    @staticmethod
    def getDouble(parent,title,*args,**kwargs):return _call(QtWidgets.QInputDialog.getDouble,parent,title,*args,**kwargs)
