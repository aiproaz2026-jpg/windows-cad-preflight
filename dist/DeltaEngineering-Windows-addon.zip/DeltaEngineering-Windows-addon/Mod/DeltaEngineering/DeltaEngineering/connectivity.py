# SPDX-License-Identifier: GPL-3.0-or-later
"""Deterministic explicit-terminal connectivity report. No electrical simulation."""
from .domain import netlist


def inspect(doc):
    rows=netlist(doc)
    nodes={};parents={};degree={}
    for obj in doc.Objects:
        if not hasattr(obj,'DeviceType'):continue
        names=list(getattr(obj,'Terminals',[]))
        if any(not name.strip() for name in names) or len(names)!=len(set(names)):raise ValueError('Device terminals must be nonempty and unique: '+obj.Tag)
        for terminal in names:
            key=(obj.Tag,terminal);nodes[key]=obj.Name;parents[key]=key;degree[key]=0
    def root(a):
        while parents[a]!=a:
            parents[a]=parents[parents[a]];a=parents[a]
        return a
    duplicates=[];pairs=set()
    for row in rows:
        a=(row['source']['device'],row['source']['terminal']);b=(row['target']['device'],row['target']['terminal'])
        if a not in parents or b not in parents:raise ValueError('Wire references a non-device terminal')
        if a==b:raise ValueError('Self-connected terminal in wire: '+row['wire'])
        pair=tuple(sorted((a,b)))
        if pair in pairs:duplicates.append(row['wire'])
        pairs.add(pair);degree[a]+=1;degree[b]+=1;parents[root(b)]=root(a)
    groups={}
    for node in sorted(nodes):groups.setdefault(root(node),[]).append(node)
    ordered=sorted(groups.values(),key=lambda items:items[0]);result=[]
    for i,members in enumerate(ordered,1):
        member_set=set(members)
        wires=sorted(row['wire'] for row in rows if (row['source']['device'],row['source']['terminal']) in member_set)
        result.append({'id':'NET'+str(i).zfill(3),'members':[{'device':a,'terminal':b} for a,b in members],'wires':wires,'isolated':len(members)==1 and not wires})
    return {'nets':result,'unwired':[{'device':a,'terminal':b} for (a,b),n in sorted(degree.items()) if n==0],
            'duplicate_pair_wires':sorted(duplicates),'scope':'Explicit terminal graph only. No inferred device-internal connections, crossing junctions, circuits, voltage/current/rating or safety checks.'}
