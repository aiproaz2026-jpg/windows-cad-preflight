# SPDX-License-Identifier: GPL-3.0-or-later
"""Source-linked straight tube leg at an explicit generic tee port."""
import FreeCAD as App,Part
from .core import positive


class PortLeg:
    def __init__(self,obj,source,port,length):
        obj.addProperty('App::PropertyLinkGlobal','PortSource','Connection');obj.PortSource=source
        obj.addProperty('App::PropertyInteger','PortIndex','Connection');obj.PortIndex=port
        obj.addProperty('App::PropertyLinkListGlobal','PlacementParents','Connection');obj.PlacementParents=[p for p in source.InListRecursive if p.isDerivedFrom('App::Part')]
        obj.setEditorMode('PlacementParents',1)
        obj.addProperty('App::PropertyLength','LegLength','Geometry');obj.LegLength=length
        obj.addProperty('App::PropertyLength','OuterDiameter','Geometry')
        obj.addProperty('App::PropertyLength','WallThickness','Geometry')
        obj.addProperty('App::PropertyVector','StartPoint','Connection')
        obj.addProperty('App::PropertyVector','EndPoint','Connection')
        obj.addProperty('App::PropertyLength','CenterlineLength','Quantities')
        obj.addProperty('App::PropertyString','Validation','Status')
        for key in ('OuterDiameter','WallThickness','StartPoint','EndPoint','CenterlineLength','Validation'):obj.setEditorMode(key,1)
        obj.Proxy=self
        obj.setEditorMode('Placement',1)
        if App.GuiUp:obj.ViewObject.Proxy=0
    def execute(self,obj):
        try:
            if any(p.isDerivedFrom('App::Part') for p in obj.InListRecursive):raise ValueError('Generated legs must stay at document root, outside Part containers')
            source=obj.PortSource;index=obj.PortIndex
            if not source or source.Document!=obj.Document or source.Shape.isNull():raise ValueError('Port source missing or invalid')
            if index<0 or index>=len(source.PortCenters):raise ValueError('Invalid explicit port index')
            length=positive(obj.LegLength.Value,'Leg length');od=positive(source.OuterDiameter.Value,'Diameter');wall=positive(source.WallThickness.Value,'Wall')
            if wall>=od/2:raise ValueError('Wall must be less than radius')
            parents=[p for p in source.InListRecursive if p.isDerivedFrom('App::Part')]
            if set(parents)!=set(obj.PlacementParents):raise ValueError('Source reparented: recreate port leg after hierarchy edits')
            placement=source.getGlobalPlacement()
            start=placement.multVec(source.PortCenters[index]);direction=placement.Rotation.multVec(source.PortDirections[index]);direction.normalize()
            shape=Part.makeCylinder(od/2,length,start,direction).cut(Part.makeCylinder(od/2-wall,length,start,direction))
            if not shape.isValid() or len(shape.Solids)!=1:raise ValueError('Invalid tube leg')
            obj.Placement=App.Placement();obj.Shape=shape;obj.StartPoint=start;obj.EndPoint=start+direction*length
            obj.OuterDiameter=od;obj.WallThickness=wall;obj.CenterlineLength=length
            obj.Validation='Connected geometric port leg only; no joint/weld/pressure/network checks'
        except (ValueError,RuntimeError,AttributeError) as exc:
            obj.Shape=Part.Shape();obj.StartPoint=App.Vector();obj.EndPoint=App.Vector();obj.CenterlineLength=0;obj.Validation=str(exc)


def attach(doc,source,index,length):
    from .branches import GeometricTee
    if source.Document!=doc or not isinstance(getattr(source,'Proxy',None),GeometricTee):raise ValueError('Select a port-bearing generic tee in this document')
    if any(getattr(o,'PortSource',None)==source and getattr(o,'PortIndex',-1)==index for o in doc.Objects):raise ValueError('This port already has a generated leg')
    doc.openTransaction('Attach source-linked port tube')
    try:
        obj=doc.addObject('Part::FeaturePython','PortLeg');obj.Label='ماسورة مرتبطة بمنفذ '+str(index+1);PortLeg(obj,source,index,length)
        from .documents import add_to
        add_to(doc,'PipingSystem',obj);doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        if App.GuiUp:obj.ViewObject.ShapeColor=(0.05,0.68,0.64)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def update_leg(doc,obj,length):
    if obj.Document!=doc or not isinstance(getattr(obj,'Proxy',None),PortLeg):raise ValueError('Select a generated port leg in this document')
    doc.openTransaction('Edit source-linked port leg')
    try:
        obj.LegLength=length;doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
