from .arabic import message
from .arabic_qt import Messages,Inputs
# SPDX-License-Identifier: GPL-3.0-or-later
from PySide import QtWidgets,QtCore
import FreeCAD as App,FreeCADGui as Gui
from . import profiles
from .precision import length

class ProfilePanel(QtWidgets.QWidget):
    def __init__(self,parent):
        super().__init__();self.panel=parent;form=QtWidgets.QFormLayout(self)
        form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        info=QtWidgets.QLabel('مقاطع هندسية قابلة للتعديل، ثم بروز مصمت مرتبط بالمقطع. لا توجد حسابات مقاومة أو مواد. الدائرة ومقطع المستطيل على XY؛ البروز عمودي على المقطع.')
        info.setWordWrap(True);form.addRow(info)
        self.category=QtWidgets.QComboBox();self.category.addItems(['إنشاء المقاطع','تحرير المصمتات','القيود الأصلية','الملفات والإخراج']);form.addRow('مجموعة الأدوات',self.category)
        self.fields={}
        for key,label,value in [('x','المركز / البداية X','0'),('y','Y','0'),('z','Z','0'),('radius','نصف قطر الدائرة','50 mm'),('inner','نصف قطر داخلي','25 mm'),('width','عرض المستطيل X','200 mm'),('depth','طول المستطيل Y','100 mm'),('height','ارتفاع البروز','20 mm'),('scale','مقياس PDF: ١ إلى','2')]:
            edit=QtWidgets.QLineEdit(value);edit.setLayoutDirection(QtCore.Qt.LeftToRight);form.addRow(label,edit);self.fields[key]=edit
        self.scaled_view=QtWidgets.QComboBox()
        from .scaled_output import VIEWS
        for key,(label,direction) in VIEWS.items():self.scaled_view.addItem(label,key)
        form.addRow('مسقط PDF بمقياس محدد',self.scaled_view)
        self.stack=QtWidgets.QStackedWidget();form.addRow(self.stack);self.category.currentIndexChanged.connect(self.stack.setCurrentIndex)
        groups=[]
        for i in range(4):
            page=QtWidgets.QWidget();box=QtWidgets.QVBoxLayout(page);box.setContentsMargins(0,0,0,0);box.setAlignment(QtCore.Qt.AlignTop);self.stack.addWidget(page);groups.append(box)
        for label,fn in [('تصدير المحدد STEP',self.step_export),('استيراد STEP',self.step_import),('تصدير مقطع محدد DXF',self.dxf_export),('قص المصمتين المحددين: الأول أساس',lambda:self.boolean('cut')),('دمج المصمتين المحددين',lambda:self.boolean('fuse')),('تقاطع المصمتين المحددين',lambda:self.boolean('common')),('فتح أدوات Part الأصلية',self.native_part),('تدوير حواف المصمت المحددة',self.fillet),('تعديل نصف قطر تدوير الحواف',self.edit_fillet),('إنشاء تكرار خطي لمصمت',self.pattern),('تعديل التكرار الخطي المحدد',self.edit_pattern),('إنشاء دوران مصمت حول محور',self.revolve),('تعديل دوران المصمت المحدد',self.edit_revolve),('إنشاء حلقة بقيود أصلية',self.ring),('تعديل قيود نصفي قطر الحلقة',self.edit_ring),('إنشاء مستطيل بقيود أصلية',self.constrained),('تعديل قيود العرض والطول',self.constraints),('فتح محرر Sketcher الأصلي',self.edit_native),('فحص حالة القيود',self.check),('PDF بمسقط ومقياس محددين',self.scaled),('إنشاء دائرة دقيقة',self.circle),('إنشاء مستطيل دقيق',self.rectangle),('تحديث الدائرة المحددة',self.update_circle),('بروز من المقطع المحدد',self.extrude),('تحديث ارتفاع البروز المحدد',self.height)]:
            button=QtWidgets.QPushButton(label);button.clicked.connect(lambda checked=False,f=fn:self.panel.safe(f))
            if any(word in label for word in ('STEP','DXF','PDF')):group=3
            elif any(word in label for word in ('قيود','Sketcher','حالة')):group=2
            elif any(word in label for word in ('مصمت','بروز','Part','تكرار','التكرار','الحواف')):group=1
            else:group=0
            button.setProperty('tool_group',group);groups[group].addWidget(button)
        note=QtWidgets.QLabel('حدد العنصر من النموذج قبل تعديله. أدوات الأساس الأصلية داخل نفس التطبيق. لا توجد حسابات مقاومة أو اعتماد تصميم.')
        note.setWordWrap(True);form.addRow(note)
        form.setAlignment(QtCore.Qt.AlignTop)
        def context(index):
            self.scaled_view.setVisible(index==3)
            form.labelForField(self.scaled_view).setVisible(index==3)
            keys=[{'x','y','z','radius','width','depth'},{'height'},{'radius','inner','width','depth'},{'scale'}][index]
            for key,edit in self.fields.items():
                edit.setVisible(key in keys)
                label=form.labelForField(edit)
                if label:label.setVisible(key in keys)
        self.category.currentIndexChanged.connect(context);context(0)
    def center(self):return App.Vector(*(length(self.fields[k].text()) for k in ('x','y','z')))
    def select(self,obj):
        Gui.Selection.clearSelection();Gui.Selection.addSelection(obj);Gui.activeDocument().activeView().viewAxonometric();Gui.activeDocument().activeView().fitAll()
        self.panel.status.setText('تم إنشاء / تحديث: '+obj.Label)
    def circle(self):self.select(profiles.circle(self.panel.doc(),self.center(),self.fields['radius'].text()))
    def update_circle(self):
        obj=self.selected();profiles.update_circle(self.panel.doc(),obj,self.center(),self.fields['radius'].text());self.select(obj)
    def rectangle(self):
        from .drafting import make_path
        start=self.center();width=length(self.fields['width'].text());depth=length(self.fields['depth'].text())
        if min(width,depth)<=1e-7:raise ValueError('Rectangle dimensions must be positive')
        obj=make_path(self.panel.doc(),[start,start+App.Vector(width,0,0),start+App.Vector(width,depth,0),start+App.Vector(0,depth,0)],True)
        obj.Label='مستطيل قابل للتعديل';self.select(obj)
    def selected(self):
        selected=Gui.Selection.getSelection()
        if len(selected)!=1:raise ValueError('Select exactly one profile or extrusion')
        if selected[0].Document!=App.ActiveDocument:raise ValueError('Select in the active document')
        return selected[0]
    def extrude(self):self.select(profiles.extrude(self.panel.doc(),self.selected(),self.fields['height'].text()))
    def height(self):
        obj=self.selected();doc=self.panel.doc();height=length(self.fields['height'].text())
        if not isinstance(obj.Proxy,profiles.Extrusion) or height<=1e-7:raise ValueError('Select a linked extrusion and positive height')
        doc.openTransaction('Change extrusion height')
        try:
            obj.Height=height;doc.recompute()
            if obj.Shape.isNull():raise ValueError(obj.Validation)
            doc.commitTransaction()
        except Exception:doc.abortTransaction();doc.recompute();raise
        self.select(obj)

    def constrained(self):
        from .constraints import rectangle
        self.select(rectangle(self.panel.doc(),self.fields['width'].text(),self.fields['depth'].text()))
    def constraints(self):
        from .constraints import update_rectangle
        obj=self.selected();update_rectangle(self.panel.doc(),obj,self.fields['width'].text(),self.fields['depth'].text());self.select(obj)
    def check(self):
        from .constraints import validate
        obj=self.selected()
        if not obj.isDerivedFrom('Sketcher::SketchObject'):raise ValueError('Select a native sketch')
        full=validate(obj);self.panel.status.setText('القيود مكتملة' if full else 'القيود سليمة لكن توجد درجات حرية متبقية')
    def edit_native(self):
        obj=self.selected()
        if not obj.isDerivedFrom('Sketcher::SketchObject'):raise ValueError('Select a native sketch')
        if Gui.activeDocument().getInEdit():raise ValueError('Close the current native editor first')
        self.panel.hybrid.stop();Gui.activateWorkbench('SketcherWorkbench');Gui.activeDocument().setEdit(obj.Name);self.panel.hide();Gui.activeDocument().activeView().fitAll()
        self.panel.status.setText('محرر Sketcher الأصلي: خطوط وأقواس ودوائر وقيود. أغلق المحرر قبل البروز. واجهته ليست معرّبة بالكامل.')

    def edit_ring(self):
        from .constraints import update_annulus
        obj=self.selected();update_annulus(self.panel.doc(),obj,self.fields['radius'].text(),self.fields['inner'].text());self.select(obj)

    def ring(self):
        from .constraints import annulus
        self.select(annulus(self.panel.doc(),self.fields['radius'].text(),self.fields['inner'].text()))

    def scaled(self):
        import os
        from .scaled_output import export_scaled
        path,_=QtWidgets.QFileDialog.getSaveFileName(Gui.getMainWindow(),'PDF بمقياس محدد','','PDF (*.pdf)')
        if not path:return
        if os.path.exists(path) and Messages.question(self,'ملف موجود','استبدال الملف؟',Messages.Yes|Messages.No)!=Messages.Yes:return
        from .precision import scalar
        result=export_scaled(self.panel.doc(),path,scalar(self.fields['scale'].text()),view_name=self.scaled_view.currentData())
        self.panel.status.setText('تم إخراج A3 '+self.scaled_view.currentText()+' بمقياس 1:'+str(result['scale_denominator'])+' | اطبع ١٠٠٪ وتحقق من خط معايرة ١٠٠ مم')

    def boolean(self,operation):
        from .solid_edit import boolean
        selected=Gui.Selection.getSelection()
        if len(selected)!=2:raise ValueError('Select base solid first, then tool solid')
        self.select(boolean(self.panel.doc(),selected[0],selected[1],operation))
    def fillet(self):
        from .fillets import create
        entries=Gui.Selection.getSelectionEx()
        if len(entries)!=1 or not entries[0].SubElementNames:raise ValueError('Select explicit edges on one solid')
        source=entries[0].Object
        if source.Document!=self.panel.doc():raise ValueError('Select source in the active document')
        text,ok=Inputs.getText(self,'تدوير الحواف','نصف قطر ثابت بوحدة طول. أي تغيير بالمصدر يستلزم إعادة اختيار الحواف.',text='2 mm')
        if ok:self.select(create(self.panel.doc(),source,list(entries[0].SubElementNames),text))
    def edit_fillet(self):
        from .fillets import update
        obj=self.selected()
        if obj.TypeId!='Part::Fillet' or not hasattr(obj,'DeltaFilletSourceSignature'):raise ValueError('Select a Delta native fillet')
        text,ok=Inputs.getText(self,'تدوير الحواف','نصف قطر ثابت بوحدة طول',text=format(obj.Edges[0][1],'.12g')+' mm')
        if ok:update(self.panel.doc(),obj,text);self.select(obj)
    def pattern_values(self,obj=None):
        count,ok=Inputs.getInt(self,'تكرار خطي هندسي','عدد النسخ شاملاً الأصل (٢ إلى ٢٠٠)',obj.InstanceCount if obj else 3,2,200)
        if not ok:return None
        default=obj.StepVector if obj else App.Vector(200,0,0);values=[]
        for axis,value in zip(('X','Y','Z'),(default.x,default.y,default.z)):
            text,ok=Inputs.getText(self,'خطوة التكرار','إزاحة '+axis+' بين النسخ، بوحدة طول',text=format(value,'.12g')+' mm')
            if not ok:return None
            values.append(length(text))
        return count,App.Vector(*values)
    def pattern(self):
        from .patterns import create
        obj=self.selected();values=self.pattern_values()
        if values:self.select(create(self.panel.doc(),obj,*values))
    def edit_pattern(self):
        from .patterns import update,LinearPattern
        obj=self.selected()
        if not isinstance(getattr(obj,'Proxy',None),LinearPattern):raise ValueError('Select a linked linear pattern')
        values=self.pattern_values(obj)
        if values:update(self.panel.doc(),obj,*values);self.select(obj)
    def revolve_values(self,obj=None):
        from .precision import scalar
        angle,ok=Inputs.getText(self,'دوران هندسي','زاوية الدوران بالدرجات، أكبر من ٠ وحتى ٣٦٠',text=format(float(obj.Angle) if obj else 360,'.12g'))
        if not ok:return None
        base=obj.Base if obj else App.Vector();axis=obj.Axis if obj else App.Vector(0,1,0);groups=[]
        for label,vector,parser in [('نقطة المحور',base,length),('اتجاه المحور بلا وحدات',axis,scalar)]:
            values=[]
            for name,value in zip(('X','Y','Z'),(vector.x,vector.y,vector.z)):
                text,ok=Inputs.getText(self,'دوران هندسي',label+' '+name,text=format(value,'.12g'))
                if not ok:return None
                values.append(parser(text))
            groups.append(App.Vector(*values))
        return groups[0],groups[1],scalar(angle)
    def revolve(self):
        from .revolutions import create
        source=self.selected();values=self.revolve_values()
        if values:self.select(create(self.panel.doc(),source,*values))
    def edit_revolve(self):
        from .revolutions import update
        obj=self.selected()
        if obj.TypeId!='Part::Revolution':raise ValueError('Select a native profile revolution')
        values=self.revolve_values(obj)
        if values:update(self.panel.doc(),obj,*values);self.select(obj)
    def native_part(self):
        self.panel.hybrid.stop();Gui.activateWorkbench('PartWorkbench');self.panel.hide()

    def target(self,title,filter):
        import os
        path,_=QtWidgets.QFileDialog.getSaveFileName(Gui.getMainWindow(),title,'',filter)
        if not path:return None
        if os.path.exists(path) and Messages.question(self,'ملف موجود','استبدال الملف؟',Messages.Yes|Messages.No)!=Messages.Yes:return None
        return path
    def step_export(self):
        from .interchange import export_step
        objects=Gui.Selection.getSelection();path=self.target('تصدير هندسة STEP، بدون شجرة الميزات','STEP (*.step)')
        if path:
            export_step(self.panel.doc(),objects,path);self.panel.status.setText('تم تصدير STEP والتحقق بإعادة قراءته، هندسة فقط بدون تاريخ التعديلات')
    def step_import(self):
        from .interchange import import_step
        path,_=QtWidgets.QFileDialog.getOpenFileName(Gui.getMainWindow(),'استيراد هندسة STEP','','STEP (*.step *.stp)')
        if path:self.select(import_step(self.panel.doc(),path))
    def dxf_export(self):
        from .interchange import export_dxf
        objects=Gui.Selection.getSelection();path=self.target('تصدير مقطع XY كـ DXF','DXF (*.dxf)')
        if path:
            export_dxf(self.panel.doc(),objects,path);self.panel.status.setText('تم تصدير هندسة المقطع DXF، بدون ضمان طبقات أو أبعاد أو تاريخ التعديلات')
