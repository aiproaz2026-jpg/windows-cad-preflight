# SPDX-License-Identifier: GPL-3.0-or-later
"""One editable integration project, entirely illustrative, no design sizing."""
import math
import FreeCAD as App
import Part
from .core import PipeRoute,Device
from .domain import QuarterElbow,add_terminal,add_terminal_wire,netlist
from .mechanical import make_assembly_example


def create_project(name='IntegratedPilot'):
    d=App.newDocument(name)
    d.UndoMode=1
    d.addObject('App::FeaturePython','ProjectInfo')
    d.ProjectInfo.addProperty('App::PropertyString','Purpose','Project')
    d.ProjectInfo.Purpose='Illustrative integration pilot; not an execution design'
    make_assembly_example(d)
    group=d.addObject('App::DocumentObjectGroup','PipingSystem')
    group.Label='مسار مواسير بكوع هندسي'
    a=d.addObject('PartDesign::FeaturePython','InletPipe')
    PipeRoute(a,[App.Vector(0,0,200),App.Vector(350,0,200)],100,5)
    elbow=d.addObject('PartDesign::FeaturePython','RouteElbow')
    QuarterElbow(elbow,150,100,5)
    # Local elbow starts (R,0), tangent +Y; rotate -90 so tangent starts +X.
    elbow.Placement=App.Placement(App.Vector(350,150,200),App.Rotation(App.Vector(0,0,1),-90))
    b=d.addObject('PartDesign::FeaturePython','OutletPipe')
    PipeRoute(b,[App.Vector(500,150,200),App.Vector(500,600,200)],100,5)
    for obj in (a,elbow,b):group.addObject(obj)
    electrical=d.addObject('App::DocumentObjectGroup','ElectricalSystem')
    electrical.Label='أطراف وتوصيلات المحرك'
    panel=d.addObject('PartDesign::FeaturePython','Panel')
    motor=d.addObject('PartDesign::FeaturePython','Motor')
    Device(panel,'P1',App.Vector(0,-300,0))
    Device(motor,'M1',App.Vector(500,-300,0))
    motor.TerminalSide='Left'
    motor.addProperty('App::PropertyLink','MechanicalReference','Coordination')
    motor.MechanicalReference=d.ShaftInstance
    for terminal in ('L1','L2','L3'):add_terminal(panel,terminal)
    for terminal in ('U1','V1','W1'):add_terminal(motor,terminal)
    for n,(x,y) in enumerate(zip(panel.Terminals,motor.Terminals),1):
        wire=add_terminal_wire(d,panel,x,motor,y,'W'+str(n))
        wire.SchematicOffset=0
        electrical.addObject(wire)
    electrical.addObject(panel);electrical.addObject(motor)
    d.recompute()
    if App.GuiUp:
        for o in (a,b,elbow):o.ViewObject.ShapeColor=(0.05,0.68,0.64)
        for o in (panel,motor):o.ViewObject.LineColor=(1.0,0.65,0.15)
    return d


def validate_project(d):
    """Geometry continuity and cross-domain references, not pressure/electrical design."""
    placement=d.RouteElbow.Placement
    radius=d.RouteElbow.BendRadius.Value
    start=placement.multVec(App.Vector(radius,0,0))
    end=placement.multVec(App.Vector(0,radius,0))
    if (d.InletPipe.Route[-1]-start).Length>1e-6 or (d.OutletPipe.Route[0]-end).Length>1e-6:
        raise ValueError('Piping centerline endpoint mismatch')
    shapes=[d.InletPipe.Shape,d.RouteElbow.Shape,d.OutletPipe.Shape]
    if any(s.isNull() or not s.isValid() for s in shapes):raise ValueError('Invalid piping geometry')
    # Distances prove contact, not catalog compliance or robust route auto-fitting.
    for x,y in zip(shapes,shapes[1:]):
        if x.distToShape(y)[0]>1e-5:raise ValueError('Piping gap')
        if x.common(y).Volume>1e-4:raise ValueError('Piping solid overlap')
    if d.Motor.MechanicalReference!=d.ShaftInstance:raise ValueError('Missing mechanical coordination')
    connections=netlist(d)
    return {'centerline_mm':sum(o.CenterlineLength.Value for o in (d.InletPipe,d.RouteElbow,d.OutletPipe)),
            'connections':connections,'geometry_contacts_checked':True,'design_calculations':False}


def update_piping(d,inlet_length,outlet_length,bend_radius,outer_diameter,wall_thickness):
    """Change the example route coherently. Millimetres, no engineering sizing."""
    from .core import positive
    inlet,outlet,r,od,t=[positive(v,n) for v,n in zip(
        (inlet_length,outlet_length,bend_radius,outer_diameter,wall_thickness),
        ('inlet','outlet','radius','diameter','wall'))]
    if t>=od/2 or r<=od/2:raise ValueError('Require wall < OD/2 and bend radius > OD/2')
    d.openTransaction('Update coordinated piping')
    try:
        d.InletPipe.Route=[App.Vector(0,0,200),App.Vector(inlet,0,200)]
        d.RouteElbow.BendRadius=r
        d.RouteElbow.Placement=App.Placement(App.Vector(inlet,r,200),App.Rotation(App.Vector(0,0,1),-90))
        d.OutletPipe.Route=[App.Vector(inlet+r,r,200),App.Vector(inlet+r,r+outlet,200)]
        for obj in (d.InletPipe,d.RouteElbow,d.OutletPipe):
            obj.OuterDiameter=od
            obj.WallThickness=t
        d.recompute()
        report=validate_project(d)
        d.commitTransaction()
        return report
    except Exception:
        d.abortTransaction()
        d.recompute()
        raise
