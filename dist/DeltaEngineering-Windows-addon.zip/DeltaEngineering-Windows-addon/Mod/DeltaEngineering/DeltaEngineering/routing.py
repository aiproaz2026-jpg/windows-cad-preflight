# SPDX-License-Identifier: GPL-3.0-or-later
"""Editable orthogonal centerline with actual radius-trimmed hollow elbows.
Pure geometry only: no fitting standards, pressure rating or design calculations.
"""
import math
import FreeCAD as App
import Part
from .core import positive


def rounded_route(points,radius,diameter,wall):
    r=positive(radius,'Bend radius');od=positive(diameter,'Diameter');t=positive(wall,'Wall')
    if r<=od/2 or t>=od/2:raise ValueError('Require radius > OD/2 and wall < OD/2')
    if len(points)<2:raise ValueError('Need two or more points')
    dirs=[];lengths=[]
    for a,b in zip(points,points[1:]):
        v=b-a
        lengths.append(positive(v.Length,'Segment length'))
        v.normalize();dirs.append(v)
    for a,b in zip(dirs,dirs[1:]):
        if abs(a.dot(b))>1e-6:raise ValueError('Only 90-degree bends supported')
    for i,length in enumerate(lengths):
        trim=r*(int(i>0)+int(i<len(lengths)-1))
        if length<=trim+1e-6:raise ValueError('Segment too short for bend radius')
    pieces=[];total=0
    for i,(a,b) in enumerate(zip(points,points[1:])):
        direction=dirs[i]
        start=a+direction*r if i>0 else a
        end=b-direction*r if i<len(lengths)-1 else b
        size=(end-start).Length
        pieces.append(Part.makeCylinder(od/2,size,start,direction).cut(Part.makeCylinder(od/2-t,size,start,direction)))
        total+=size
        if i<len(lengths)-1:
            vertex=b;incoming=direction;outgoing=dirs[i+1]
            center=vertex-incoming*r+outgoing*r
            arc_start=vertex-incoming*r
            arc_end=vertex+outgoing*r
            radial=(arc_start-center)+(arc_end-center)
            radial.normalize()
            mid=center+radial*r
            spine=Part.Wire(Part.Arc(arc_start,mid,arc_end).toShape())
            def sweep(rad):
                profile=Part.Wire(Part.makeCircle(rad,arc_start,incoming))
                return spine.makePipeShell([profile],True,True)
            pieces.append(sweep(od/2).cut(sweep(od/2-t)))
            total+=math.pi*r/2
    for i,first in enumerate(pieces):
        for j in range(i+2,len(pieces)):
            if first.common(pieces[j]).Volume>1e-4:
                raise ValueError('Route has overlapping nonadjacent geometry')
    return Part.makeCompound(pieces),total,len(dirs)-1


class RoutedSystem:
    def __init__(self,obj,points,radius=150,diameter=100,wall=5):
        obj.addProperty('App::PropertyVectorList','Vertices','Route')
        obj.addProperty('App::PropertyLink','SourcePath','Route')
        for prop in ('BendRadius','OuterDiameter','WallThickness'):
            obj.addProperty('App::PropertyLength',prop,'Route')
        obj.addProperty('App::PropertyLength','CenterlineLength','Quantities')
        obj.addProperty('App::PropertyInteger','ElbowCount','Quantities')
        obj.addProperty('App::PropertyString','Validation','Status')
        obj.Vertices=points
        obj.BendRadius,obj.OuterDiameter,obj.WallThickness=radius,diameter,wall
        for prop in ('CenterlineLength','ElbowCount','Validation'):obj.setEditorMode(prop,1)
        obj.Proxy=self
        if App.GuiUp:obj.ViewObject.Proxy=0
    def execute(self,obj):
        try:
            points=obj.Vertices
            if obj.SourcePath:
                from .documents import require_root_frame
                require_root_frame(obj.SourcePath,'Custom routed piping')
                wires=obj.SourcePath.Shape.Wires
                if len(wires)!=1 or wires[0].isClosed():raise ValueError('Select one open polygonal wire')
                points=[v.Point for v in wires[0].OrderedVertexes]
                if len(wires[0].Edges)!=len(points)-1:raise ValueError('Non-polygonal source')
                if any('Line' not in type(edge.Curve).__name__ for edge in wires[0].Edges):raise ValueError('Straight source segments required')
            shape,length,count=rounded_route(points,obj.BendRadius.Value,obj.OuterDiameter.Value,obj.WallThickness.Value)
            obj.Shape=shape;obj.CenterlineLength=length;obj.ElbowCount=count
            obj.Validation='Geometric orthogonal route; catalog/design checks not performed'
        except (ValueError,RuntimeError) as exc:
            obj.Shape=Part.Shape();obj.CenterlineLength=0;obj.ElbowCount=0
            obj.Validation=str(exc)
