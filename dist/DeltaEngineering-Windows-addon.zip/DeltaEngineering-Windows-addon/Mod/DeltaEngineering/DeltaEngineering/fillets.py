# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded native constant-radius fillets with explicit edge selection and drift refusal."""
import json,math
import FreeCAD as App


def signature(shape):
    # Ordered geometry signature. Any source change requires reselecting edges,
    # not silently applying historical indices to a different edge.
    import hashlib
    return hashlib.sha256(shape.exportBrepToString().encode('utf-8')).hexdigest()


def source_check(doc,source):
    from .documents import require_root_frame
    if source.Document!=doc:raise ValueError('Select the active document source')
    require_root_frame(source,'Native edge fillet')
    if not hasattr(source,'Shape') or source.Shape.isNull() or not source.Shape.isValid() or len(source.Shape.Solids)!=1:raise ValueError('Fillet requires one valid source solid')


def validate(obj):
    if not obj.Base:raise ValueError('Fillet source missing')
    source_check(obj.Document,obj.Base)
    if signature(obj.Base.Shape)!=obj.DeltaFilletSourceSignature:raise ValueError('Fillet source changed. Reselect source edges and recreate fillet; old edge indices are not trusted')
    if 'Invalid' in obj.State or 'Error' in obj.State or obj.Shape.isNull() or not obj.Shape.isValid() or len(obj.Shape.Solids)!=1:raise ValueError('Native fillet failed; reduce radius or select other edges')
    return True


def radius_value(value):
    from .precision import length
    radius=length(value) if isinstance(value,str) else float(value)
    if not math.isfinite(radius) or radius<=1e-7:raise ValueError('Fillet radius must be finite and positive')
    return radius


def create(doc,source,edge_names,radius):
    from .validation import valid_document
    valid_document(doc);source_check(doc,source);radius=radius_value(radius)
    indices=[]
    for name in edge_names:
        if not name.startswith('Edge') or not name[4:].isdigit():raise ValueError('Select explicit source edges only')
        number=int(name[4:])
        if not 1<=number<=len(source.Shape.Edges) or number in indices:raise ValueError('Invalid or duplicate source edge')
        indices.append(number)
    if not 1<=len(indices)<=32:raise ValueError('Select 1 through 32 edges on one solid')
    doc.openTransaction('Native constant radius edge fillet')
    try:
        obj=doc.addObject('Part::Fillet','EdgeFillet');obj.Label='تدوير حواف بنصف قطر ثابت';obj.Base=source
        obj.addProperty('App::PropertyString','DeltaFilletSourceSignature','DeltaSafety');obj.DeltaFilletSourceSignature=signature(source.Shape);obj.setEditorMode('DeltaFilletSourceSignature',1)
        obj.Edges=[(i,radius,radius) for i in indices];doc.recompute();validate(obj)
        from .documents import add_to
        add_to(doc,'MechanicalSystem',obj)
        if App.GuiUp:source.Visibility=False;obj.ViewObject.ShapeColor=(0.72,0.75,0.8)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def update(doc,obj,radius):
    if obj.Document!=doc or obj.TypeId!='Part::Fillet' or not hasattr(obj,'DeltaFilletSourceSignature'):raise ValueError('Select a Delta native edge fillet')
    validate(obj);radius=radius_value(radius);doc.openTransaction('Edit constant fillet radius')
    try:
        obj.Edges=[(i,radius,radius) for i,a,b in obj.Edges];doc.recompute();validate(obj);doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
