# SPDX-License-Identifier: GPL-3.0-or-later
"""Validated native Part boolean features with retained source links."""
import FreeCAD as App


def boolean(doc,base,tool,operation='cut'):
    if operation not in ('cut','fuse','common'):raise ValueError('Unknown solid operation')
    if base==tool or base.Document!=doc or tool.Document!=doc:raise ValueError('Select two different solids in this document')
    from .documents import require_root_frame
    for obj in (base,tool):
        require_root_frame(obj,'Custom boolean command')
        if not hasattr(obj,'Shape') or not obj.Shape.isValid() or len(obj.Shape.Solids)!=1:raise ValueError('Each source must contain one valid solid')
    common=base.Shape.common(tool.Shape)
    if common.Volume<=1e-7:raise ValueError('Solids must overlap in volume')
    doc.openTransaction('Native '+operation+' solids')
    try:
        kind={'cut':'Part::Cut','fuse':'Part::Fuse','common':'Part::Common'}[operation]
        obj=doc.addObject(kind,'BooleanFeature');obj.Base=base;obj.Tool=tool;obj.Refine=True
        doc.recompute()
        if obj.Shape.isNull() or not obj.Shape.isValid() or len(obj.Shape.Solids)!=1:raise ValueError('Operation must produce one valid nonempty solid')
        from .documents import add_to
        add_to(doc,'MechanicalSystem',obj)
        if App.GuiUp:
            base.Visibility=False;tool.Visibility=False;obj.ViewObject.ShapeColor=(0.72,0.75,0.8)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise
