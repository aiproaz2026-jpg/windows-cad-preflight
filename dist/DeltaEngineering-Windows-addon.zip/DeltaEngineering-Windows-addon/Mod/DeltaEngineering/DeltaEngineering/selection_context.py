from .arabic import message
from .arabic_qt import Messages,Inputs
# SPDX-License-Identifier: GPL-3.0-or-later
"""Selection inspection without silent field overwrites or heuristic source choice."""
import FreeCAD as App,FreeCADGui as Gui
from PySide import QtCore,QtWidgets


def direct_sources(obj):
    sources=[]
    for prop in ('Profile','SourcePath','Base','Tool','PortSource','PatternSource','Source'):
        value=getattr(obj,prop,None)
        if value and hasattr(value,'Document') and value.Document==obj.Document:
            if value not in [o for _,o in sources]:sources.append((prop,value))
    return sources


class SelectionContext(QtWidgets.QWidget):
    def __init__(self,panel,layout):
        super().__init__();self.panel=panel;box=QtWidgets.QVBoxLayout(self);box.setContentsMargins(6,4,6,0)
        self.summary=QtWidgets.QLabel('لا يوجد تحديد');self.summary.setTextFormat(QtCore.Qt.PlainText);self.summary.setWordWrap(True);box.addWidget(self.summary)
        row=QtWidgets.QHBoxLayout();box.addLayout(row)
        self.load_button=QtWidgets.QPushButton('تحميل خصائص المحدد');self.load_button.clicked.connect(lambda:panel.safe(self.load));row.addWidget(self.load_button)
        self.source_button=QtWidgets.QPushButton('اختيار مصدر التعديل');self.source_button.clicked.connect(lambda:panel.safe(self.source));row.addWidget(self.source_button)
        self.summary.setToolTip('التحديد لا يستبدل إدخالك. تحميل الخصائص ينقل القيم فقط، ولا يعدّل النموذج.')
        layout.insertWidget(0,self)
        self.observer=SelectionObserver(self);Gui.Selection.addObserver(self.observer)
        self.timer=QtCore.QTimer(self);self.timer.setSingleShot(True);self.timer.timeout.connect(self.refresh);self.refresh()
    def refresh_later(self):self.timer.start(0)
    def refresh(self):
        selected=Gui.Selection.getSelection();self.load_button.setEnabled(len(selected)==1);self.source_button.setEnabled(len(selected)==1 and bool(direct_sources(selected[0])))
        self.summary.setText('المحدد: '+', '.join(o.Label for o in selected) if selected else 'لا يوجد تحديد | اختر من النموذج أو الرسم')
    def selected(self):
        selected=Gui.Selection.getSelection()
        if len(selected)!=1 or selected[0].Document!=App.ActiveDocument:raise ValueError('Select one object in the active document')
        return selected[0]
    def load(self):
        obj=self.selected();p=self.panel;fields=p.profiles.fields
        def put(key,value):fields[key].setText(format(float(value),'.12g')+' mm')
        if hasattr(obj,'PortSource') or (hasattr(obj,'OuterDiameter') and hasattr(obj,'WallThickness')):
            p.tubes.load_object(obj);p.tabs.setCurrentIndex(3);return
        if hasattr(obj,'Points'):
            p.remember(obj);p.load();p.tabs.setCurrentIndex(0);return
        if obj.isDerivedFrom('Sketcher::SketchObject'):
            values={c.Name:obj.getDatum(c.Name).Value for c in obj.Constraints if c.Name}
            if 'Width' in values and 'Depth' in values:
                put('width',values['Width']);put('depth',values['Depth'])
            elif 'OuterRadius' in values and 'InnerRadius' in values:
                put('radius',values['OuterRadius']);put('inner',values['InnerRadius'])
            p.profiles.category.setCurrentIndex(2)
        elif hasattr(obj,'FirstAngle') and hasattr(obj,'Radius'):
            for key,value in zip(('x','y','z'),(obj.Placement.Base.x,obj.Placement.Base.y,obj.Placement.Base.z)):put(key,value)
            put('radius',obj.Radius.Value);p.profiles.category.setCurrentIndex(0)
        elif getattr(obj,'Proxy',None) and obj.Proxy.__class__.__module__=='DeltaEngineering.profiles':
            put('height',obj.Height.Value);p.profiles.category.setCurrentIndex(1)
        else:raise ValueError('No custom parameter loader for this object. Use native properties or select its source')
        p.tabs.setCurrentIndex(2);p.status.setText('تم تحميل القيم فقط. لا تتغير الهندسة إلا عند ضغط تحديث.')
    def source(self):
        sources=direct_sources(self.selected())
        if not sources:raise ValueError('Object has no direct editable source link')
        if len(sources)==1:obj=sources[0][1]
        else:
            from .arabic import source_role
            choices=[source_role(prop)+' : '+obj.Label for prop,obj in sources]
            name,ok=Inputs.getItem(self,'اختيار مصدر التعديل','اختر المصدر المطلوب',choices,0,False)
            if not ok:return
            obj=sources[choices.index(name)][1]
        Gui.Selection.clearSelection();Gui.Selection.addSelection(obj);self.refresh()
        self.panel.status.setText('تم تحديد المصدر: '+obj.Label+' | حمّل خصائصه أو افتح محرره الأصلي')


class SelectionObserver:
    def __init__(self,context):self.context=context
    def addSelection(self,*args):self.context.refresh_later()
    def removeSelection(self,*args):self.context.refresh_later()
    def clearSelection(self,*args):self.context.refresh_later()
    def setSelection(self,*args):self.context.refresh_later()
