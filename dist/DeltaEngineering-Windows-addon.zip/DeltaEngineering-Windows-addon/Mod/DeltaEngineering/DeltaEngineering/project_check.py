# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only bounded technical preflight, never engineering approval."""
import math
from .documents import model_objects,world_shape,require_root_frame,ancestor_placement


def inspect(doc):
    doc.recompute();issues=[]
    def add(level,obj,message):
        issues.append({'level':level,'object':obj.Name if obj else '', 'label':obj.Label if obj else '', 'message':message})
    for obj in doc.Objects:
        try:
            if 'Invalid' in obj.State or 'Error' in obj.State:add('ERROR',obj,'Native feature has unresolved errors')
            if obj.isDerivedFrom('Sketcher::SketchObject') and (obj.ConflictingConstraints or obj.RedundantConstraints or obj.MalformedConstraints):add('ERROR',obj,'Sketch constraints conflict or are malformed/redundant')
            if hasattr(obj,'Validation') and hasattr(obj,'Shape') and (obj.Shape.isNull() or not obj.Shape.isValid()):add('ERROR',obj,'Invalid parametric geometry: '+obj.Validation)
            if obj.TypeId=='Part::Revolution':
                from .revolutions import parameters,validate
                if not obj.Source:raise ValueError('Native revolution source missing')
                parameters(obj.Source,obj.Base,obj.Axis,float(obj.Angle));validate(obj)
            if getattr(obj,'PatternSource',None):require_root_frame(obj.PatternSource,'Pattern source')
            if getattr(obj,'SourcePath',None):require_root_frame(obj.SourcePath,'Routed piping source')
            if getattr(obj,'Profile',None) and getattr(obj,'Proxy',None) and obj.Proxy.__class__.__module__=='DeltaEngineering.profiles':require_root_frame(obj.Profile,'Extrusion source')
            if obj.TypeId in ('Part::Cut','Part::Fuse','Part::Common'):
                for source in (obj.Base,obj.Tool):
                    if source:require_root_frame(source,'Boolean source')
            if hasattr(obj,'LinkedGeometry'):
                for entry in obj.LinkedGeometry:
                    if entry and entry[0]:require_root_frame(entry[0],'Dimension source')
            if hasattr(obj,'DeviceType') or hasattr(obj,'SourceDevice'):
                placement=ancestor_placement(obj).multiply(obj.Placement)
                if placement.Base.Length>1e-7 or abs(placement.Rotation.Angle)>1e-7:add('ERROR',obj,'Electrical objects use Position in a shared frame. Reset object/container Placement')
            if hasattr(obj,'PortSource'):
                source=obj.PortSource
                if not source:add('ERROR',obj,'Port source missing')
                else:
                    parents=[p for p in source.InListRecursive if p.isDerivedFrom('App::Part')]
                    if set(parents)!=set(obj.PlacementParents):add('ERROR',obj,'Port source hierarchy changed; recreate generated leg')
                if any(p.isDerivedFrom('App::Part') for p in obj.InListRecursive):add('ERROR',obj,'Generated port legs must stay outside Part containers')
            if getattr(obj,'DimensionPreset',''):
                from .tube_library import status
                if status(obj).startswith('CUSTOM'):add('NOTE',obj,'OD/wall differ from stored nominal preset, custom geometry')
        except (ValueError,RuntimeError,AttributeError) as exc:add('ERROR',obj,str(exc))
    graph=None
    try:
        from .connectivity import inspect as inspect_connectivity
        graph=inspect_connectivity(doc)
        if graph['unwired']:add('NOTE',None,str(len(graph['unwired']))+' terminals have no explicit wire, not necessarily a design fault')
        if graph['duplicate_pair_wires']:add('NOTE',None,'Repeated terminal-pair wires: '+', '.join(graph['duplicate_pair_wires']))
    except (ValueError,AttributeError) as exc:add('ERROR',None,'Electrical graph: '+str(exc))
    models=model_objects(doc);volumes=[]
    for obj in models:
        try:
            shape=world_shape(obj)
            if shape.isNull() or not shape.isValid():add('ERROR',obj,'Visible geometry is invalid')
            else:volumes.append({'object':obj.Name,'solid_count':len(shape.Solids),'volume_mm3':shape.Volume})
        except (ValueError,RuntimeError) as exc:add('ERROR',obj,str(exc))
    return {'scope':'Bounded technical preflight only, not engineering approval. No complete collision, stress, pressure, electrical safety, standards or Windows-release check.',
            'error_count':sum(i['level']=='ERROR' for i in issues),'issues':issues,'visible_model_objects':len(models),
            'geometry':volumes,'logical_nets':len(graph['nets']) if graph else None}
