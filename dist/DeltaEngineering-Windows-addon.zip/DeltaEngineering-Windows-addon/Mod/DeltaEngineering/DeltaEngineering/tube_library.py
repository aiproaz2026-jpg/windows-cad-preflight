# SPDX-License-Identifier: GPL-3.0-or-later
"""Small source-cited nominal tube geometry presets. Not a product/rating library."""
import FreeCAD as App

SOURCE='https://www.wheatland.com/wp-content/uploads/2017/12/Schedule-40-Submittal-Sheet.pdf'
REVISION='WFS-121824'
# Factual nominal mm dimensions only; original prose, artwork and CAD assets not copied.
ROWS=[('1',33.4,3.38),('1 1/4',42.2,3.56),('1 1/2',48.3,3.68),('2',60.3,3.91),('2 1/2',73.0,5.16),('3',88.9,5.49),('3 1/2',101.6,5.74),('4',114.3,6.02)]
PRESETS={n:{'nps':n,'od_mm':od,'wall_mm':wall,'source':SOURCE,'revision':REVISION,'family':'Nominal Schedule 40 tube dimensions'} for n,od,wall in ROWS}


def record(obj,preset):
    for key in ('DimensionPreset','DimensionSource','DimensionRevision','DimensionScope'):
        if not hasattr(obj,key):obj.addProperty('App::PropertyString',key,'Dimensional provenance')
    obj.DimensionPreset='NPS '+preset['nps']+' / Sch 40'
    obj.DimensionSource=preset['source'];obj.DimensionRevision=preset['revision']
    obj.DimensionScope='Nominal OD/wall only. No material, rating, tolerances, approvals, fitting or design compliance inherited.'
    for key in ('PresetOD','PresetWall'):
        if not hasattr(obj,key):obj.addProperty('App::PropertyLength',key,'Dimensional provenance')
    obj.PresetOD=preset['od_mm'];obj.PresetWall=preset['wall_mm']
    for key in ('DimensionPreset','DimensionSource','DimensionRevision','DimensionScope','PresetOD','PresetWall'):obj.setEditorMode(key,1)


def status(obj):
    if not getattr(obj,'DimensionPreset',''):return 'Custom dimensions; no cited preset'
    matches=abs(obj.OuterDiameter.Value-obj.PresetOD.Value)<1e-7 and abs(obj.WallThickness.Value-obj.PresetWall.Value)<1e-7
    return ('Nominal OD/wall match cited preset; no rating or design validation' if matches else 'CUSTOM MODIFIED: OD/wall no longer match recorded preset')


def apply(doc,obj,key,radius=None):
    if obj.Document!=doc or not hasattr(obj,'OuterDiameter') or not hasattr(obj,'WallThickness'):raise ValueError('Select one pipe or routed system in the active document')
    if hasattr(obj,'PortSource'):raise ValueError('Tube leg dimensions follow its tee source. Select PortSource to change size')
    preset=PRESETS[key]
    doc.openTransaction('Apply cited nominal tube dimensions')
    try:
        obj.OuterDiameter=preset['od_mm'];obj.WallThickness=preset['wall_mm']
        if radius is not None:
            if not hasattr(obj,'BendRadius'):raise ValueError('Selected object has no bend radius')
            obj.BendRadius=radius
        record(obj,preset);doc.recompute()
        if obj.Shape.isNull() or not obj.Shape.isValid():raise ValueError(obj.Validation)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def route(doc,path,key,radius):
    if path.Document!=doc:raise ValueError('Select a path in the active document')
    from .routing import RoutedSystem
    from .documents import add_to
    p=PRESETS[key]
    doc.openTransaction('Route with cited tube dimensions')
    try:
        obj=doc.addObject('PartDesign::FeaturePython','CatalogRoute');RoutedSystem(obj,[],radius,p['od_mm'],p['wall_mm']);obj.SourcePath=path
        record(obj,p);add_to(doc,'PipingSystem',obj);doc.recompute()
        if obj.Shape.isNull() or not obj.Shape.isValid():raise ValueError(obj.Validation)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise
