# SPDX-License-Identifier: GPL-3.0-or-later
"""Refuse stale cached geometry when a native feature is invalid."""
def valid_document(doc):
    doc.recompute()
    for obj in doc.Objects:
        from .documents import require_root_frame
        if obj.TypeId=='Part::Fillet' and hasattr(obj,'DeltaFilletSourceSignature'):
            from .fillets import validate as validate_fillet
            validate_fillet(obj)
        if obj.TypeId=='Part::Revolution':
            from .revolutions import parameters,validate
            if not obj.Source:raise ValueError('Native revolution source missing')
            parameters(obj.Source,obj.Base,obj.Axis,float(obj.Angle));validate(obj)
        if getattr(obj,'PatternSource',None):require_root_frame(obj.PatternSource,'Pattern source')
        if getattr(obj,'SourcePath',None):require_root_frame(obj.SourcePath,'Dependent routed piping')
        if getattr(obj,'Profile',None) and getattr(obj,'Proxy',None) and obj.Proxy.__class__.__module__=='DeltaEngineering.profiles':require_root_frame(obj.Profile,'Dependent extrusion')
        if obj.TypeId in ('Part::Cut','Part::Fuse','Part::Common'):
            for source in (obj.Base,obj.Tool):
                if source:require_root_frame(source,'Boolean source validation')
        if hasattr(obj,'LinkedGeometry'):
            for entry in obj.LinkedGeometry:
                if entry and entry[0]:require_root_frame(entry[0],'Linked dimension validation')
        if hasattr(obj,'DeviceType') or hasattr(obj,'SourceDevice'):
            from .documents import ancestor_placement
            import FreeCAD as App
            placement=ancestor_placement(obj).multiply(obj.Placement)
            if placement.Base.Length>1e-7 or abs(placement.Rotation.Angle)>1e-7:
                raise ValueError('Electrical schematic uses Position coordinates only; reset object/container Placement: '+obj.Label)
        if hasattr(obj,'PortSource'):
            if any(p.isDerivedFrom('App::Part') for p in obj.InListRecursive):raise ValueError('Generated legs must remain outside Part containers: '+obj.Label)
            source=obj.PortSource
            if not source or source.Shape.isNull():raise ValueError('Invalid port source: '+obj.Label)
            parents=[p for p in source.InListRecursive if p.isDerivedFrom('App::Part')]
            if set(parents)!=set(obj.PlacementParents):raise ValueError('Recreate port legs after source hierarchy edits: '+obj.Label)
            if obj.Shape.isNull():raise ValueError('Invalid connected leg: '+obj.Label+' / '+obj.Validation)
        if 'Invalid' in obj.State or 'Error' in obj.State:
            raise ValueError('Invalid model feature: '+obj.Label+' / '+obj.getStatusString())
        if obj.isDerivedFrom('Sketcher::SketchObject'):
            if obj.ConflictingConstraints or obj.RedundantConstraints or obj.MalformedConstraints:
                raise ValueError('Invalid sketch constraints: '+obj.Label)
