from .arabic import message
from .arabic_qt import Messages,Inputs
# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded plain-text coordinate exchange. Data only, never evaluated as code."""
import csv,io
from .precision import xyz
from .drafting import checked_points

MAX_ROWS=10000
MAX_BYTES=2_000_000


def parse(text):
    if len(text.encode('utf-8'))>MAX_BYTES:raise ValueError('Coordinate text exceeds 2 MB limit')
    rows=[]
    for line,row in enumerate(csv.reader(io.StringIO(text)),1):
        if not row or not any(value.strip() for value in row):continue
        if not rows and [v.strip().lower() for v in row]==['x','y','z']:continue
        if len(row)!=3:raise ValueError('Line '+str(line)+': expected X,Y,Z using comma separators')
        try:point=xyz([value.strip() for value in row])
        except (ValueError,RuntimeError) as exc:raise ValueError('Line '+str(line)+': invalid length values') from exc
        rows.append(point)
        if len(rows)>MAX_ROWS:raise ValueError('Coordinate list exceeds 10000-point limit')
    return checked_points(rows)


def serialize(points):
    checked_points(points)
    if len(points)>MAX_ROWS:raise ValueError('Coordinate list exceeds 10000-point limit')
    stream=io.StringIO(newline='');writer=csv.writer(stream,lineterminator='\n');writer.writerow(['X','Y','Z'])
    for point in points:writer.writerow([format(v,'.12g')+' mm' for v in (point.x,point.y,point.z)])
    return stream.getvalue()


def load_text(panel,text):
    points=parse(text)
    if panel.table.rowCount():
        from PySide import QtWidgets
        answer=Messages.question(panel,'استبدال جدول الإدخال','سيتم استبدال نقاط الجدول غير المحفوظة فقط، دون تعديل النموذج. هل تريد المتابعة؟',Messages.Yes|Messages.No)
        if answer!=Messages.Yes:return
    # All parsing/validation completes before replacing the draft buffer. Existing
    # native path geometry remains untouched until explicit Save changes.
    from PySide import QtWidgets
    panel.hybrid.stop();panel.table.blockSignals(True)
    try:
        panel.table.setRowCount(len(points))
        for row,point in enumerate(points):
            for col,value in enumerate((point.x,point.y,point.z)):panel.table.setItem(row,col,QtWidgets.QTableWidgetItem(format(value,'.12g')))
    finally:panel.table.blockSignals(False)
    panel.status.setText('تم تحميل '+str(len(points))+' نقطة إلى الجدول فقط. الرسم الحالي لم يتغير؛ ارسم أو احفظ التعديل صراحة.')
