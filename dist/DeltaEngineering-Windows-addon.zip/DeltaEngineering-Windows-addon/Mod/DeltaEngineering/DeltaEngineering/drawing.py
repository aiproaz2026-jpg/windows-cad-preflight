# SPDX-License-Identifier: GPL-3.0-or-later
import os
import FreeCAD as App


def add_drawing(d):
    """Native editable A3 sheet with two model-linked projections, illustrative only."""
    if App.GuiUp:
        import FreeCADGui as Gui
        Gui.activateWorkbench('TechDrawWorkbench')
    if d.getObject('ProjectDrawing'):
        return d.ProjectDrawing
    page=d.addObject('TechDraw::DrawPage','ProjectDrawing')
    page.Label='لوحة المشروع التجريبي'
    template=d.addObject('TechDraw::DrawSVGTemplate','ProjectTemplate')
    template.Template=os.path.join(os.path.dirname(__file__),'templates','A3-pilot.svg')
    page.Template=template
    if App.GuiUp:
        template.ViewObject.Visibility=True
        page.ViewObject.ShowFrames=False
    frame=d.addObject('TechDraw::DrawViewSymbol','SheetFrame')
    frame.Symbol=open(os.path.join(os.path.dirname(__file__),'templates','A3-pilot.svg'),encoding='utf-8').read()
    page.addView(frame)
    frame.X,frame.Y=210,148.5
    sources=[d.InletPipe,d.RouteElbow,d.OutletPipe,d.BaseInstance,d.ShaftInstance]
    top=d.addObject('TechDraw::DrawViewPart','TopProjection')
    page.addView(top)
    top.Source=sources
    top.Direction=App.Vector(0,0,1)
    top.ScaleType='Custom'
    top.Scale=0.10
    top.X,top.Y=120,160
    iso=d.addObject('TechDraw::DrawViewPart','IsoProjection')
    page.addView(iso)
    iso.Source=sources
    iso.Direction=App.Vector(1,-1,1)
    iso.ScaleType='Custom'
    iso.Scale=0.10
    iso.X,iso.Y=295,160
    d.recompute()
    return page


def add_electrical_drawing(d):
    from .domain import netlist
    rows=netlist(d)
    page=d.addObject('TechDraw::DrawPage','ElectricalDrawing')
    page.Label='لوحة التوصيل التجريبية'
    template=d.addObject('TechDraw::DrawSVGTemplate','ElectricalTemplate')
    template.Template=os.path.join(os.path.dirname(__file__),'templates','A3-pilot.svg')
    page.Template=template
    frame=d.addObject('TechDraw::DrawViewSymbol','ElectricalFrame')
    svg=open(os.path.join(os.path.dirname(__file__),'templates','A3-pilot.svg'),encoding='utf-8').read()
    svg=svg.replace('الوحدة mm | مسقط علوي ومجسم | مقياس اسمي 0.10','توصيل منطقي فقط | ليس تصميم أسلاك أو مسار كابلات فعلي').replace('مسقط علوي','توصيلات الأطراف').replace('مسقط مجسم','قائمة التوصيل')
    frame.Symbol=svg
    page.addView(frame);frame.X,frame.Y=210,148.5
    view=d.addObject('TechDraw::DrawViewPart','CircuitProjection')
    page.addView(view)
    view.Source=[o for o in d.ElectricalSystem.Group if hasattr(o,'Shape')]
    view.Direction=App.Vector(0,0,1)
    view.ScaleType='Custom';view.Scale=0.25
    view.X,view.Y=115,160
    text=d.addObject('TechDraw::DrawViewAnnotation','NetlistText')
    text.Text=[r['wire']+' : '+r['source']['device']+':'+r['source']['terminal']+' -> '+r['target']['device']+':'+r['target']['terminal'] for r in rows]
    page.addView(text)
    text.X,text.Y=285,170
    text.TextSize=4
    # Native annotations identify symbols; terminal identities remain explicit in netlist.
    for name,x,device in [('PanelTag',52.5,d.Panel),('MotorTag',177.5,d.Motor)]:
        tag=d.addObject('TechDraw::DrawViewAnnotation',name)
        tag.Text=[device.Tag]
        tag.TextSize=4
        page.addView(tag)
        tag.X,tag.Y=x,185
    d.recompute()
    return page


def refresh_sheets(d):
    from .domain import netlist
    if d.getObject('PanelTag'):d.PanelTag.Text=[d.Panel.Tag]
    if d.getObject('MotorTag'):d.MotorTag.Text=[d.Motor.Tag]
    if d.getObject('NetlistText'):
        d.NetlistText.Text=[r['wire']+' : '+r['source']['device']+':'+r['source']['terminal']+' -> '+r['target']['device']+':'+r['target']['terminal'] for r in netlist(d)]
    d.recompute()
