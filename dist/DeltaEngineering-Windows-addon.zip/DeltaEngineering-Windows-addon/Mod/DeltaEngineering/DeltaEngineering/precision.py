# SPDX-License-Identifier: GPL-3.0-or-later
"""Precise planar drafting helpers. Coordinates are millimetres, angles degrees."""
import math,re
import FreeCAD as App


DIGITS=str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫−','01234567890123456789.-')
UNITS={'':'mm','mm':'mm','cm':'cm','m':'m','in':'in','ft':'ft','um':'um','µm':'um','μm':'um','مم':'mm','سم':'cm','م':'m','بوصة':'in','قدم':'ft'}
NUMBER=r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?'


def numeric_text(text):
    return str(text).strip().translate(DIGITS)


def scalar(text):
    value=numeric_text(text)
    if not re.fullmatch(NUMBER,value):raise ValueError('Use one finite number without formulas or separators')
    result=float(value)
    if not math.isfinite(result):raise ValueError('Number must be finite')
    return result


def length(text):
    value=numeric_text(text)
    match=re.fullmatch('('+NUMBER+r')\s*([^0-9\s]*)',value)
    if not match or match.group(2) not in UNITS:raise ValueError('Use one length value with mm/cm/m/in/ft or مم/سم/م/بوصة/قدم')
    number=scalar(match.group(1));unit=UNITS[match.group(2)]
    result=float(App.Units.Quantity(str(number)+' '+unit).Value)
    if not math.isfinite(result) or abs(result)>1e9:raise ValueError('Coordinate outside finite drafting range')
    return result


def xyz(values,base=None):
    p=App.Vector(*(length(v) for v in values))
    return p+(base or App.Vector())


def polar(base,distance,angle):
    distance=length(distance);angle=scalar(angle)
    if distance<=1e-7 or not math.isfinite(angle):raise ValueError('Length must be positive and angle finite')
    r=math.radians(angle%360)
    return base+App.Vector(distance*math.cos(r),distance*math.sin(r),0)


def snap(point,base=None,grid=0,ortho=False,candidates=(),tolerance=10):
    p=App.Vector(point)
    axis=None
    if ortho and base is not None:
        axis='x' if abs(p.x-base.x)>=abs(p.y-base.y) else 'y'
        if axis=='x':p.y=base.y
        else:p.x=base.x
    # Endpoint/midpoint snaps only win when compatible with the work plane/ortho.
    eligible=[]
    for candidate,kind in candidates:
        if abs(candidate.z-p.z)>1e-6:continue
        if axis=='x' and abs(candidate.y-base.y)>1e-6:continue
        if axis=='y' and abs(candidate.x-base.x)>1e-6:continue
        dist=(candidate-p).Length
        if dist<=tolerance:eligible.append((dist,candidate,kind))
    if eligible:
        _,p,kind=min(eligible,key=lambda e:e[0]);return App.Vector(p),kind
    if grid>0:
        if axis!='y':p.x=round(p.x/grid)*grid
        if axis!='x':p.y=round(p.y/grid)*grid
        return p,'grid'
    return p,'ortho' if axis else 'free'


def candidates(doc,include_midpoints=True,limit=20000):
    from .documents import world_shape
    result=[]
    for obj in doc.Objects:
        if not hasattr(obj,'Shape') or not getattr(obj.ViewObject,'Visibility',False):continue
        if obj.isDerivedFrom('App::DocumentObjectGroup'):continue
        # A hidden assembly/Body must not contribute invisible snap targets.
        if any(hasattr(parent,'ViewObject') and not parent.ViewObject.Visibility for parent in obj.InListRecursive if parent.isDerivedFrom('App::Part') or parent.isDerivedFrom('PartDesign::Body')):continue
        shape=world_shape(obj)
        for vertex in shape.Vertexes:
            result.append((vertex.Point,'endpoint'))
            if len(result)>limit:raise ValueError('Too many snap candidates; hide unrelated geometry')
        if include_midpoints:
            for edge in shape.Edges:
                if 'Line' in type(edge.Curve).__name__:
                    result.append((edge.valueAt((edge.FirstParameter+edge.LastParameter)/2),'midpoint'))
                    if len(result)>limit:raise ValueError('Too many snap candidates; hide unrelated geometry')
    return result
