from .arabic import message,snap_mode
# SPDX-License-Identifier: GPL-3.0-or-later
"""Hybrid numeric/viewport drafting controller for the shared path table."""
from PySide import QtWidgets,QtCore
import FreeCAD as App,FreeCADGui as Gui
from . import precision

class HybridInput:
    def __init__(self,panel,layout):
        self.observer=DocumentObserver(self)
        App.addDocumentObserver(self.observer)
        self.panel=panel;self.view=None;self.handles=[];self.node=None;self.points_node=None;self.doc_name=None;self.snap_points=[]
        self.guard=QtCore.QTimer(panel);self.guard.setInterval(150);self.guard.timeout.connect(self.check_document)
        box=QtWidgets.QGroupBox('إدخال دقيق ورسم يدوي | مستوى XY');layout.addWidget(box)
        form=QtWidgets.QFormLayout(box)
        self.mode=QtWidgets.QComboBox();self.mode.addItems(['إحداثيات مطلقة X Y Z','إزاحة نسبية ΔX ΔY ΔZ','طول وزاوية من آخر نقطة'])
        form.addRow('طريقة الإدخال',self.mode)
        fields=QtWidgets.QWidget();row=QtWidgets.QHBoxLayout(fields);row.setContentsMargins(0,0,0,0)
        fields.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.values=[]
        for name in ('X / ΔX / L','Y / ΔY / °','Z / ΔZ'):
            edit=QtWidgets.QLineEdit('0');edit.setPlaceholderText(name);edit.setToolTip(name);edit.setLayoutDirection(QtCore.Qt.LeftToRight);row.addWidget(edit);self.values.append(edit)
        form.addRow(QtWidgets.QLabel('من اليسار: X/طول، Y/زاوية، Z'))
        form.addRow(fields)
        for label,fn in [('إضافة نقطة دقيقة',self.append),('استبدال الصف المحدد',self.replace),('نقل كل النقاط بالإزاحة XYZ',self.translate),('تدوير حول أول نقطة، الزاوية بالوسط',self.rotate)]:
            button=QtWidgets.QPushButton(label);button.clicked.connect(lambda checked=False,f=fn:panel.safe(f));form.addRow(button)
        self.grid=QtWidgets.QDoubleSpinBox();self.grid.setRange(0,1e6);self.grid.setValue(10);self.grid.setSuffix(' mm');form.addRow('شبكة الالتقاط (٠ للإيقاف)',self.grid)
        self.ortho=QtWidgets.QCheckBox('تعامد X/Y');self.ends=QtWidgets.QCheckBox('التقاط نهاية / منتصف خط');self.ends.setChecked(True)
        options=QtWidgets.QWidget();r=QtWidgets.QHBoxLayout(options);r.setContentsMargins(0,0,0,0);r.addWidget(self.ortho);r.addWidget(self.ends);form.addRow(options)
        self.z=QtWidgets.QDoubleSpinBox();self.z.setRange(-1e9,1e9);self.z.setDecimals(3);form.addRow('مستوى Z (مم)',self.z)
        for label,fn in [('بدء التقاط نقاط، يكمل الجدول',self.start),('إنهاء الالتقاط ورسم المسار',self.finish),('إلغاء الالتقاط مع إبقاء الجدول',self.stop),('تراجع آخر نقطة بالجدول',self.back)]:
            b=QtWidgets.QPushButton(label);b.clicked.connect(lambda checked=False,f=fn:panel.safe(f));form.addRow(b)
        panel.visibilityChanged.connect(lambda visible:self.stop() if not visible else None)
        panel.table.itemChanged.connect(lambda *args:self.preview())
    def base(self):
        points=self.panel.points();return points[-1] if points else App.Vector(0,0,self.z.value())
    def value(self):
        values=[v.text() for v in self.values];mode=self.mode.currentIndex()
        if mode==0:return precision.xyz(values)
        if mode==1:return precision.xyz(values,self.base())
        if abs(precision.length(values[2]))>1e-9:raise ValueError('Polar input is planar; third field must be zero')
        return precision.polar(self.base(),values[0],values[1])
    def set_row(self,row,p):
        self.panel.table.blockSignals(True)
        for col,v in enumerate((p.x,p.y,p.z)):self.panel.table.setItem(row,col,QtWidgets.QTableWidgetItem(format(v,'.12g')))
        self.panel.table.blockSignals(False);self.preview()
    def append_point(self,p):
        points=self.panel.points()
        if points and (p-points[-1]).Length<1e-7:raise ValueError('Point duplicates the last point')
        row=self.panel.table.rowCount();self.panel.table.insertRow(row);self.set_row(row,p)
        self.panel.status.setText('نقاط الجدول: '+str(row+1)+' | احفظ التعديل أو ارسم مساراً جديداً')
    def append(self):self.append_point(self.value())
    def replace(self):
        row=self.panel.table.currentRow()
        if row<0:raise ValueError('Select a table row first')
        self.set_row(row,self.value())
    def translate(self):
        offset=precision.xyz([v.text() for v in self.values]);points=self.panel.points()
        for i,p in enumerate(points):self.set_row(i,p+offset)
    def rotate(self):
        points=self.panel.points()
        if not points:raise ValueError('Add points first')
        angle=precision.scalar(self.values[1].text())
        if not __import__('math').isfinite(angle):raise ValueError('Angle must be finite')
        rotation=App.Rotation(App.Vector(0,0,1),angle);origin=points[0]
        for i,p in enumerate(points):self.set_row(i,origin+rotation.multVec(p-origin))
    def back(self):
        if self.panel.table.rowCount():self.panel.table.removeRow(self.panel.table.rowCount()-1)
        self.preview()
    def check_document(self):
        if self.view and (not App.ActiveDocument or App.ActiveDocument.Name!=self.doc_name):self.stop()
    def start(self):
        if self.view:self.stop()
        d=self.panel.doc();self.doc_name=d.Name;self.view=Gui.activeDocument().activeView()
        self.view.setCameraType('Orthographic');self.view.viewTop()
        self.snap_points=precision.candidates(d) if self.ends.isChecked() else []
        from pivy import coin
        self.node=coin.SoSeparator();color=coin.SoBaseColor();color.rgb=(0.95,0.45,0.05);style=coin.SoDrawStyle();style.lineWidth=3
        self.points_node=coin.SoCoordinate3();self.line=coin.SoLineSet()
        for n in (color,style,self.points_node,self.line):self.node.addChild(n)
        self.view.getSceneGraph().addChild(self.node)
        for event in ('SoMouseButtonEvent','SoLocation2Event','SoKeyboardEvent'):
            self.handles.append((event,self.view.addEventCallback(event,self.event)))
        self.guard.start();self.preview();self.panel.status.setText('انقر نقاطاً على مستوى XY. Enter ينهي، Backspace يتراجع، Esc يلغي الالتقاط. الرسم لا يعدّل النموذج حتى الحفظ.')
    def preview(self,point=None):
        if not self.points_node:return
        try:
            points=self.panel.points()
            if point is not None:points=points+[point]
            self.points_node.point.setValues(0,len(points),[(p.x,p.y,p.z) for p in points]);self.line.numVertices.setValue(len(points))
        except (ValueError,RuntimeError):pass
    def point_at(self,position):
        # Intersect the view ray with the fixed XY plane; do not trust a picked face depth.
        from pivy import coin
        width,height=self.view.getSize()
        if min(width,height)<2:raise ValueError('Viewport is not ready')
        volume=self.view.getCameraNode().getViewVolume(float(width)/height)
        ray=volume.projectPointToLine(coin.SbVec2f(float(position[0])/width,float(position[1])/height))
        origin=ray[0];vector=ray[1]-ray[0]
        p=App.Vector(*origin.getValue());direction=App.Vector(*vector.getValue())
        if abs(direction.z)<1e-8:raise ValueError('View is parallel to XY plane; restart point capture')
        p=p+direction*((self.z.value()-p.z)/direction.z)
        points=self.panel.points();base=points[-1] if points else None
        tolerance=abs(float(self.view.getCameraNode().height.getValue()))*8/height
        return precision.snap(p,base,self.grid.value(),self.ortho.isChecked(),self.snap_points if self.ends.isChecked() else [],tolerance)
    def event(self,event):
        if not self.view:return
        if not App.ActiveDocument or App.ActiveDocument.Name!=self.doc_name:
            QtCore.QTimer.singleShot(0,self.stop);self.panel.status.setText('تم إيقاف الالتقاط لتغيير المستند');return
        try:
            kind=event['Type']
            if kind=='SoKeyboardEvent' and event.get('State')=='DOWN':
                key=event.get('Key','')
                if key=='ESCAPE':QtCore.QTimer.singleShot(0,self.stop)
                elif key in ('RETURN','ENTER'):QtCore.QTimer.singleShot(0,lambda:self.panel.safe(self.finish))
                elif key=='BACKSPACE':self.back()
            elif kind=='SoLocation2Event':
                point,mode=self.point_at(event['Position']);self.preview(point);self.panel.status.setText('%s | X %.3f Y %.3f Z %.3f mm'%(snap_mode(mode),point.x,point.y,point.z))
            elif kind=='SoMouseButtonEvent' and event.get('State')=='DOWN' and event.get('Button')=='BUTTON1':
                point,mode=self.point_at(event['Position']);self.append_point(point)
        except Exception as exc:self.panel.status.setText(message(exc))
    def finish(self):
        self.stop();self.panel.create()
    def stop(self):
        self.guard.stop()
        if self.view:
            for event,handle in self.handles:
                try:self.view.removeEventCallback(event,handle)
                except (RuntimeError,ReferenceError,AttributeError):pass
            if self.node:
                try:self.view.getSceneGraph().removeChild(self.node)
                except (RuntimeError,ReferenceError,AttributeError):pass
        self.handles=[];self.view=None;self.node=None;self.points_node=None


class DocumentObserver:
    def __init__(self,controller):self.controller=controller
    def slotDeleteDocument(self,doc):
        if doc.Name==self.controller.doc_name:self.controller.stop()
    def slotDeletedDocument(self,doc):
        if doc.Name==self.controller.doc_name:self.controller.stop()
    def slotActivateDocument(self,doc):
        if self.controller.view and doc.Name!=self.controller.doc_name:self.controller.stop()
