# SPDX-License-Identifier: GPL-3.0-or-later
"""Arabic presentation boundary. Stored values and technical identifiers stay unchanged."""
import re

# Exact messages/fragments owned by Delta, not upstream FreeCAD translations.
PAIRS = '''must be finite and positive|يجب أن تكون القيمة محدودة وموجبة. أدخل قيمة أكبر من صفر
Activate the target document|فعّل المستند المطلوب من علامة تبويبه ثم أعد المحاولة
Add points first|أضف نقاطاً إلى الجدول أولاً
Angle must be finite|أدخل زاوية رقمية محدودة
At least two points required|أدخل نقطتين مختلفتين على الأقل
Axis crosses profile bounding box; this bounded workflow requires a profile on one side|المحور يقطع صندوق حدود المقطع. انقل المحور خارج المقطع أو إلى حدّه، مع بقاء المقطع على جانب واحد
Cannot connect a terminal to itself|لا يمكن توصيل الطرف بنفسه. اختر طرفاً آخر
Cannot create continuation page|تعذر إنشاء صفحة تكميلية. تحقق من مجلد الحفظ وأعد المحاولة
Cannot start PDF writer|تعذر بدء كتابة PDF. اختر مسار حفظ متاحاً وتحقق من صلاحية الكتابة
Center must be finite|أدخل إحداثيات مركز رقمية محدودة
Choose a STEP file|اختر ملف STEP
Choose an explicit illustrative symbol template|اختر قالباً توضيحياً من قائمة الرموز أولاً
Choose an explicit nominal size first|اختر مقاساً اسمياً من القائمة أولاً
Choose at most one subelement per selection entry|اختر عنصراً فرعياً واحداً لكل إدخال تحديد
Choose two different paths|اختر مسارين مختلفين
Close the current native editor first|أغلق محرر العنصر الأصلي المفتوح ثم أعد المحاولة
Closed path needs three points|المسار المغلق يحتاج إلى ثلاث نقاط على الأقل
Coincident vertices|النقطتان متطابقتان. اختر نقطتين مختلفتين
Connection row exceeds supported 4000-character safety limit|صف التوصيل يتجاوز حد ٤٠٠٠ حرف. قصّر معرّفات الرموز والأطراف والأسلاك
Connection row is too large for one page|صف التوصيل أكبر من الصفحة. قصّر معرّفات الرموز والأطراف والأسلاك
Consecutive points must differ|النقاط المتتالية متطابقة. احذف النقطة المكررة أو غيّر إحداثياتها
Coordinate list exceeds 10000-point limit|القائمة تتجاوز حد ١٠٠٠٠ نقطة. قسّم الإدخال إلى مسارات أصغر
Coordinate outside finite drafting range|الإحداثي خارج مجال الرسم. أدخل قيمة محدودة لا تتجاوز مليار مم بالقيمة المطلقة
Coordinate text exceeds 2 MB limit|النص يتجاوز حد ٢ ميجابايت. قلّل عدد الصفوف
Coordinates must be finite|أدخل إحداثيات رقمية محدودة
DXF command accepts planar wire geometry, not solids or dimensions|إخراج DXF يقبل خطوطاً مستوية فقط، لا المصمتات أو الأبعاد. حدد مساراً مستوياً
DXF does not support transformed parent containers; export root XY wires only|إخراج DXF لا يدعم تحويل الحاوية الأم. استخدم مساراً على XY في جذر المستند
DXF export is empty|لا توجد هندسة قابلة للإخراج إلى DXF. حدد مساراً مستوياً
DXF readback contains no geometry|فشل التحقق من DXF: الملف المعاد فتحه بلا هندسة. لم يُعتمد الإخراج
DXF readback geometric mismatch|فشل التحقق الهندسي من DXF. لم يُعتمد الإخراج
Dangling terminal connection:|مرجع طرف مفقود في التوصيل. أصلح الأطراف أو احذف السلك المعطّل:
Degenerate projection|المسقط منعدم المساحة. اختر اتجاه عرض آخر أو هندسة صالحة
Destination directory does not exist|مجلد الحفظ غير موجود. اختر مجلداً موجوداً
Device has connected wires|الرمز متصل بأسلاك. افصلها أو وافق صراحة على حذفها مع الرمز
Device tag must be nonempty and unique|أدخل معرّف رمز غير فارغ وغير مستخدم
Device tags must be nonempty and unique|معرّفات الرموز يجب أن تكون غير فارغة ومختلفة. راجع الرموز المكررة
Device terminals must be nonempty and unique:|أسماء الأطراف يجب أن تكون غير فارغة ومختلفة داخل الرمز:
Devices must belong to the same document|اختر رمزين من المستند نفسه
Dimension offset must be finite|أدخل إزاحة رقمية محدودة لخط البعد
Dimension source belongs to a different document|مصدر البعد في مستند آخر. فعّل مستنده وحدده من جديد
Dimensioned PDF currently supports XY-plane paths only|إخراج الرسم بالأبعاد يدعم حالياً المسارات على مستوى XY فقط
Dimensions must be positive|أدخل أبعاداً أكبر من صفر
Each source must contain one valid solid|كل مصدر يجب أن يحتوي على مصمت صالح واحد. راجع التحديد
Electrical schematic uses Position coordinates only; reset object/container Placement:|الرسم الكهربائي يستخدم إحداثيات Position فقط. أعد Placement للعنصر وحاويته إلى الوضع المحايد:
Empty or degenerate projection|المسقط فارغ أو منعدم المساحة. راجع الهندسة واتجاه المسقط
Extrusion is not one valid solid|البروز لا ينتج مصمتاً صالحاً واحداً. راجع غلق المقطع وارتفاع البروز
File must contain valid STEP solids|الملف يجب أن يحتوي على مصمتات STEP صالحة
Fillet radius must be finite and positive|أدخل نصف قطر تدوير حافة محدوداً وأكبر من صفر
Fillet requires one valid source solid|تدوير الحواف يحتاج إلى مصمت مصدر صالح واحد
Fillet source changed. Reselect source edges and recreate fillet; old edge indices are not trusted|تغيّر مصدر تدوير الحواف. أعد تحديد حواف المصدر وأنشئ التدوير من جديد، ولا تعتمد على أرقام الحواف القديمة
Fillet source missing|مصدر تدوير الحواف مفقود. حدد المصدر وأنشئ التدوير من جديد
Generated legs must remain outside Part containers:|الأفرع المولدة يجب أن تبقى في جذر المستند خارج حاويات Part:
Generated legs must stay at document root, outside Part containers|ضع الأفرع المولدة في جذر المستند، خارج حاويات Part
Height must be positive|أدخل ارتفاعاً أكبر من صفر
Instance count must be an integer|أدخل عدداً صحيحاً للنسخ
Invalid PDF|ملف PDF غير صالح. تحقق من الإخراج قبل استخدامه
Invalid connected leg:|فرع متصل غير صالح. راجع مصدره وطوله:
Invalid downstream geometry:|هندسة عنصر تابع غير صالحة. راجع تعديل المصدر:
Invalid explicit port index|رقم المنفذ غير صالح. اختر منفذاً من القائمة
Invalid model feature:|عنصر النموذج غير صالح. أصلح أخطاءه قبل الإخراج:
Invalid model:|النموذج غير صالح. أصلح الخطأ التالي قبل الإخراج:
Invalid native solid feature:|عملية المصمت الأصلية غير صالحة. راجع المصدر والمعلمات:
Invalid object:|العنصر غير صالح. راجع خصائصه:
Invalid or duplicate source edge|حافة المصدر غير صالحة أو مكررة. أعد تحديد الحواف
Invalid piping geometry|هندسة المواسير غير صالحة. راجع الأقطار والأطوال ونصف قطر الكوع
Invalid planar dimension|البعد المستوي غير صالح. راجع نقطتيه ومستوى الرسم
Invalid port source:|مصدر المنفذ غير صالح. راجع هندسة الوصلة:
Invalid separate-solid pattern|تكرار المصمتات غير صالح. راجع المصدر وعدد النسخ والمسافة
Invalid sketch constraints:|قيود المقطع غير صالحة. افتح محرر القيود وأصلح التعارض:
Invalid sketch geometry|هندسة المقطع غير صالحة. راجع القيود والغلق
Invalid source geometry|هندسة المصدر غير صالحة. أصلح المصدر أولاً
Invalid tube leg|فرع الماسورة غير صالح. راجع الوصلة المصدر وطول الفرع
Invalid vertex indices|أرقام النقاط غير صالحة. اختر نقطتين موجودتين ومختلفتين
Length must be positive and angle finite|أدخل طولاً أكبر من صفر وزاوية رقمية محدودة
Measure geometry in one document only|اختر عناصر القياس من مستند واحد فقط
Missing dimensional source|مصدر المقاس مفقود. أعد تحديد عنصر المصدر
Missing mechanical coordination|عناصر المثال الميكانيكي مفقودة. أعد إنشاء المثال أو استخدم مشروعك المستقل
Missing profile in this document|المقطع المصدر غير موجود في هذا المستند
Native fillet failed; reduce radius or select other edges|تعذر تدوير الحواف. قلّل نصف القطر أو اختر حواف أخرى
Native revolution reports an invalid state|الدوران الأصلي غير صالح. راجع المقطع والمحور والزاوية
Native revolution source missing|المقطع المصدر للدوران مفقود. أعد تحديده
Native sketch solver reports conflicting, redundant or malformed constraints|محلل المقطع أبلغ عن قيود متعارضة أو زائدة أو معطلة. افتح محرر المقطع وأصلحها
Need two or more points|أدخل نقطتين مختلفتين على الأقل
No custom parameter loader for this object. Use native properties or select its source|لا توجد حقول دلتا لهذا العنصر. استخدم خصائصه الأصلية أو حدد مصدره
No drawable model or electrical objects|لا توجد عناصر نموذج أو كهرباء قابلة للرسم. أظهر العناصر المطلوبة أولاً
No model geometry to export|لا توجد هندسة نموذج قابلة للإخراج. أظهر عناصر صالحة
Non-polygonal source|المصدر ليس مساراً مكوّناً من قطع مستقيمة. اختر مساراً مناسباً
Number must be finite|أدخل رقماً محدوداً، لا قيمة لانهائية
Object has no direct editable source link|العنصر لا يحتوي على رابط مصدر قابل للتحرير مباشرة
Only 90-degree bends supported|المسار يدعم أكواع ٩٠ درجة فقط. عدّل اتجاه القطع
Only XY planar geometry is supported by this command|هذه الأداة تدعم هندسة مستوية على XY فقط
Only whole objects, vertices, edges or faces supported|اختر جسماً كاملاً أو نقطة أو حافة أو وجهاً فقط
Operation must produce one valid nonempty solid|العملية يجب أن تنتج مصمتاً صالحاً واحداً وغير فارغ. راجع المصدر والأداة
PDF export failed validation|فشل التحقق من PDF. لا تستخدم الملف قبل مراجعة سبب الفشل
PDF export unexpectedly empty|ملف PDF فارغ على غير المتوقع. راجع العناصر المرئية
PDF output failed|تعذر إخراج PDF. راجع مسار الحفظ وصلاحياته والهندسة
Path belongs to a different document|المسار في مستند آخر. فعّل مستنده أولاً
Path edit rejected:|رُفض تعديل المسار. لم يُعتمد التعديل:
Pattern copy bounding boxes may touch/overlap; increase spacing|صناديق حدود النسخ قد تتلامس أو تتداخل. زد مسافة التكرار
Pattern instance count must be 2 through 200|عدد نسخ التكرار يجب أن يكون من ٢ إلى ٢٠٠
Pattern needs one valid source solid|التكرار يحتاج إلى مصمت مصدر صالح واحد
Pattern source missing|مصدر التكرار مفقود. حدد مصمتاً وأنشئ التكرار من جديد
Piping centerline endpoint mismatch|نهايات خطوط مراكز المواسير غير متطابقة. راجع اتصال المسار
Piping gap|يوجد فراغ بين أجزاء المواسير. راجع الأطوال ونقاط الاتصال
Piping solid overlap|مصمتات المواسير متداخلة. راجع الأبعاد والمسار
Point duplicates the last point|النقطة تطابق آخر نقطة. أدخل نقطة مختلفة
Polar input is planar; third field must be zero|إدخال الطول والزاوية مستوٍ. اجعل الحقل الثالث صفراً
Port source missing or invalid|مصدر المنفذ مفقود أو غير صالح. أصلح الوصلة المصدر
Profile contains unresolved native errors|المقطع يحتوي على أخطاء أصلية لم تُحل. افتح محرره وأصلحها
Profile must be planar|المقطع يجب أن يكون مستوياً
Profile must form one valid planar face, with optional nested holes|المقطع يجب أن يكوّن وجهاً مستوياً صالحاً واحداً، ويمكن أن يحتوي على فتحات داخلية
Projection SVG failed to render|تعذر رسم المسقط المتجهي. راجع الهندسة ثم أعد الإخراج
Projection direction must be finite and nonzero|اختر اتجاه مسقط محدداً وغير صفري
Projection renderer failed|تعذر حساب المسقط. راجع الهندسة واتجاه العرض
Radius must be positive|أدخل نصف قطر أكبر من صفر
Recreate port legs after source hierarchy edits:|تغيّرت حاويات مصدر المنافذ. أعد إنشاء الأفرع المولدة:
Rectangle dimensions must be positive|أدخل عرض وطول مستطيل أكبر من صفر
Remove linked dimensions before changing vertex count|احذف الأبعاد المرتبطة قبل تغيير عدد نقاط المسار
Require 0 < inner radius < outer radius|يجب أن يكون نصف القطر الداخلي أكبر من صفر وأصغر من الخارجي
Require radius > OD/2 and wall < OD/2|اجعل نصف قطر الكوع أكبر من نصف القطر الخارجي، وسمك الجدار أصغر من نصف القطر الخارجي
Require wall < OD/2 and bend radius > OD/2|اجعل سمك الجدار أصغر من نصف القطر الخارجي، ونصف قطر الكوع أكبر منه
Require wall < OD/2, run > 2*OD, branch > OD|اجعل سمك الجدار أصغر من نصف القطر الخارجي، وطول الوصلة أكبر من ضعفي القطر، وطول الفرع أكبر من القطر
Reserved group name is already used:|اسم مجموعة النظام محجوز ومستخدم لعنصر آخر. أعد تسمية العنصر المتعارض:
Revolution angle must be above zero and at most 360 degrees|أدخل زاوية دوران أكبر من صفر ولا تتجاوز ٣٦٠ درجة
Revolution axis must lie in profile plane|محور الدوران يجب أن يقع في مستوى المقطع
Revolution must produce one valid solid|الدوران يجب أن ينتج مصمتاً صالحاً واحداً. راجع المحور والمقطع
Route has overlapping nonadjacent geometry|يوجد تداخل بين أجزاء غير متجاورة من المسار. غيّر المسار أو الأبعاد
Route needs at least two points|المسار يحتاج إلى نقطتين مختلفتين على الأقل
STEP export accepts valid selected solid geometry in this document|إخراج STEP يقبل مصمتات صالحة محددة من هذا المستند
STEP roundtrip volume mismatch|حجم STEP المعاد فتحه لا يطابق المصدر. لم يُعتمد الإخراج
STEP world-coordinate bounds mismatch|حدود STEP في الإحداثيات العالمية لا تطابق المصدر. لم يُعتمد الإخراج
Scale denominator must be positive|أدخل مقام مقياس أكبر من صفر
Segment too short for bend radius|القطعة أقصر من مساحة الكوع المطلوبة. زد طولها أو قلّل نصف قطر الكوع
Select 1 through 32 edges on one solid|حدد من حافة واحدة إلى ٣٢ حافة على مصمت واحد
Select Top, Front or Right orthographic view|اختر المسقط العلوي أو الأمامي أو الأيمن من القائمة
Select a Delta native edge fillet|حدد عنصر تدوير حواف أنشأته أداة دلتا
Select a Delta native fillet|حدد عنصر تدوير حواف أنشأته أداة دلتا
Select a generated port leg in this document|حدد فرع منفذ مولداً في هذا المستند
Select a generic tee in this document|حدد وصلة تفرع هندسية في هذا المستند
Select a linked extrusion and positive height|حدد بروزاً مرتبطاً وأدخل ارتفاعاً أكبر من صفر
Select a linked linear pattern|حدد تكراراً خطياً مرتبطاً
Select a native Draft circle in this document|حدد دائرة Draft أصلية في هذا المستند
Select a native profile revolution|حدد دوران مقطع أصلياً
Select a native ring sketch in this document|حدد مقطع حلقة أصلياً في هذا المستند
Select a native sketch|حدد مقطع Sketcher أصلياً
Select a native sketch in this document|حدد مقطع Sketcher أصلياً في هذا المستند
Select a path in the active document|حدد مساراً في المستند النشط
Select a planar profile, not a solid|حدد مقطعاً مستوياً، لا مصمتاً
Select a planar source in active document|حدد مصدراً مستوياً في المستند النشط
Select a port-bearing generic tee in this document|حدد وصلة تفرع هندسية ذات منافذ في هذا المستند
Select a table row first|حدد صفاً في الجدول أولاً
Select a terminal device in this document and explicit side|حدد رمزاً ذا أطراف في هذا المستند واختر جهة الأطراف
Select an editable Draft path|حدد مسار Draft قابلاً للتحرير
Select an object in the active document|حدد عنصراً في المستند النشط
Select base solid first, then tool solid|حدد المصمت الأساسي أولاً ثم مصمت الأداة
Select closed valid planar profile wires|حدد حدود مقطع مغلقة ومستوية وصالحة
Select distinct geometry targets|اختر هدفين هندسيين مختلفين
Select exactly one path or pipe system|حدد مساراً واحداً أو نظام مواسير واحداً فقط
Select exactly one profile or extrusion|حدد مقطعاً واحداً أو بروزاً واحداً فقط
Select explicit edges on one solid|حدد حوافاً صراحة على مصمت واحد
Select explicit source edges only|حدد حواف المصدر صراحة فقط
Select in the active document|حدد عناصر من المستند النشط
Select model geometry|حدد هندسة النموذج أولاً
Select one object in the active document|حدد عنصراً واحداً في المستند النشط
Select one open polygonal wire|حدد مساراً مفتوحاً واحداً مكوّناً من قطع مستقيمة
Select one or more solid objects|حدد مصمتاً واحداً أو أكثر
Select one or two geometry targets, including two subelements of one object|حدد هدفاً هندسياً واحداً أو هدفين، ويمكن اختيار عنصرين فرعيين من الجسم نفسه
Select one pipe or routed system in the active document|حدد ماسورة واحدة أو نظام مواسير واحداً في المستند النشط
Select planar wire geometry|حدد مساراً خطياً مستوياً
Select source in active document|حدد المصدر في المستند النشط
Select source in the active document|حدد المصدر في المستند النشط
Select the active document source|حدد المصدر من المستند النشط
Select two different solids in this document|حدد مصمتين مختلفين في هذا المستند
Selected geometry is invalid:|الهندسة المحددة غير صالحة. راجع المصدر:
Selected object has no bend radius|العنصر المحدد لا يملك نصف قطر كوع. اختر كوعاً أو نظام مواسير
Self-connected terminal in wire:|سلك متصل بالطرف نفسه. اختر طرفاً آخر:
Sketch dimensions must be positive|أبعاد المقطع يجب أن تكون أكبر من صفر
Sketch must contain Width and Depth constraints|المقطع يحتاج إلى قيدي Width وDepth. استخدم قالب المستطيل المقيّد
Sketch needs OuterRadius and InnerRadius named constraints|المقطع يحتاج إلى قيدي OuterRadius وInnerRadius. استخدم قالب الحلقة المقيّدة
Solids must overlap in volume|المصمتان لا يتداخلان حجمياً. عدّل موضعهما قبل العملية
Source reparented: recreate port leg after hierarchy edits|تغيّرت حاوية المصدر. أعد إنشاء فرع المنفذ بعد تعديل الحاويات
Straight source segments required|المصدر يجب أن يتكوّن من قطع مستقيمة فقط
Tee must be one valid hollow solid|وصلة التفرع يجب أن تكون مصمتاً مجوفاً صالحاً واحداً
Terminal has connected wires|الطرف متصل بأسلاك. افصلها أو وافق صراحة على حذفها
Terminal layout must contain every existing name exactly once, no rename/add/delete|أدرج كل اسم طرف حالي مرة واحدة فقط. لا تضف أو تحذف أو تغيّر الأسماء من أداة الترتيب
Terminal must be nonempty and unique on device|أدخل اسم طرف غير فارغ وغير مستخدم داخل الرمز
Terminal name must be new, nonempty and unique|أدخل اسم طرف جديداً وغير فارغ وغير مكرر
This port already has a generated leg|هذا المنفذ له فرع مولد بالفعل. حدد الفرع لتعديل طوله
Too many snap candidates; hide unrelated geometry|أهداف الالتقاط كثيرة. أخفِ الهندسة غير المطلوبة ثم أعد الالتقاط
Tube leg dimensions follow its tee source. Select PortSource to change size|مقاس الفرع يتبع الوصلة المصدر. اختر مصدر المنفذ لتغيير المقاس
Unknown orthographic view|المسقط غير معروف. اختر من قائمة المساقط
Unknown solid operation|عملية المصمت غير معروفة. اختر أداة من لوحة تحرير المصمتات
Unknown terminal|الطرف غير موجود. حدّث قائمة الأطراف وحدده من جديد
Use a finite nonzero step vector|أدخل إزاحة تكرار رقمية محدودة وغير صفرية
Use a finite route offset in this document|حدد سلكاً من هذا المستند وأدخل إزاحة رقمية محدودة
Use a profile in this document and positive height|اختر مقطعاً من هذا المستند وأدخل ارتفاعاً أكبر من صفر
Use a unique nonempty device tag|أدخل معرّف رمز غير فارغ وغير مكرر
Use finite axis base and a nonzero axis direction|أدخل إحداثيات محور محدودة واتجاهاً غير صفري
Use finite center coordinates and positive radius|أدخل مركزاً رقمياً محدوداً ونصف قطر أكبر من صفر
Use finite coordinates in the active document|أدخل إحداثيات محدودة لعنصر من المستند النشط
Use one finite number without formulas or separators|أدخل رقماً واحداً محدوداً دون معادلات أو فواصل آلاف
Use one length value with mm/cm/m/in/ft or مم/سم/م/بوصة/قدم|أدخل قيمة طول واحدة بوحدة مم أو سم أو م أو بوصة أو قدم. لا تستخدم معادلات أو فواصل آلاف
View exceeds A3 drawing area at this scale; choose a larger denominator|المسقط يتجاوز مساحة ورقة A3 بهذا المقياس. زد مقام المقياس لتصغير الرسم
View is parallel to XY plane; restart point capture|اتجاه العرض موازٍ لمستوى XY. أعد بدء الالتقاط من المسقط العلوي
Viewport is not ready|نافذة الرسم غير جاهزة. افتح عرضاً للمستند ثم أعد المحاولة
Wall must be less than radius|سمك الجدار يجب أن يكون أصغر من نصف القطر الخارجي
Wall thickness must be less than radius|سمك الجدار يجب أن يكون أصغر من نصف القطر الخارجي
Wire identifier must be nonempty and unique|أدخل معرّف سلك غير فارغ وغير مستخدم
Wire identifiers must be nonempty and unique|معرّفات الأسلاك يجب أن تكون غير فارغة ومختلفة
Wire references a non-device terminal|السلك يشير إلى عنصر ليس رمزاً ذا أطراف. أعد التوصيل
Native feature has unresolved errors|العملية الأصلية تحتوي على أخطاء. افتح خصائصها وأصلح الخطأ قبل الإخراج
Sketch constraints conflict or are malformed/redundant|قيود المقطع متعارضة أو زائدة أو معطلة. افتح محرر المقطع وأصلحها
Invalid parametric geometry:|الهندسة البارامترية غير صالحة. راجع الأبعاد:
Electrical objects use Position in a shared frame. Reset object/container Placement|عناصر الكهرباء تستخدم Position في إطار مشترك. أعد Placement للعنصر والحاوية إلى الوضع المحايد
Port source missing|مصدر المنفذ مفقود. أعد تحديد الوصلة المصدر
Port source hierarchy changed; recreate generated leg|تغيّرت حاويات مصدر المنفذ. أعد إنشاء الفرع المولد
Generated port legs must stay outside Part containers|الأفرع المولدة يجب أن تبقى خارج حاويات Part
OD/wall differ from stored nominal preset, custom geometry|القطر أو السمك يختلف عن المقاس الاسمي المحفوظ. الهندسة الآن مخصصة
Repeated terminal-pair wires:|توجد أسلاك مكررة بين الطرفين نفسيهما. راجعها:
Electrical graph:|مراجع التوصيل الكهربائي:
Visible geometry is invalid|هندسة مرئية غير صالحة. أصلح العنصر قبل الإخراج
Valid route; fittings not generated|مسار صالح هندسياً، لم تُولّد وصلات
Geometric orthogonal route; catalog/design checks not performed|مسار متعامد هندسي فقط، لم تُفحص الكتالوجات أو صلاحية التصميم
Geometric 90-degree elbow; no catalog rating|كوع هندسي ٩٠ درجة، بلا تصنيف كتالوج
Missing device|رمز التوصيل مفقود. أعد اختيار طرفي السلك
Coincident devices|موضعا الرمزين متطابقان. حرّك أحدهما
Wire offset must be finite|أدخل إزاحة سلك رقمية محدودة
Logical connection only|توصيل منطقي فقط، دون حسابات كهربائية
'''
MESSAGES=dict(line.split('|',1) for line in PAIRS.strip().splitlines())
MESSAGES.update({
 'Custom dimensions; no cited preset':'أبعاد مخصصة، لا يوجد مقاس اسمي موثق',
 'Nominal OD/wall match cited preset; no rating or design validation':'القطر والسمك يطابقان المقاس الاسمي الموثق. لا يوجد تصنيف ضغط أو اعتماد تصميم',
 'CUSTOM MODIFIED: OD/wall no longer match recorded preset':'أبعاد معدّلة: القطر أو السمك لا يطابقان المقاس الاسمي المسجل',
 'Whole object':'الجسم كاملاً',
 'Invalid parametric geometry: ':'الهندسة البارامترية غير صالحة. راجع الأبعاد: ',
})
FIELD_NAMES={'Outer diameter':'القطر الخارجي','Wall thickness':'سمك الجدار','Segment length':'طول القطعة','Diameter':'القطر','Wall':'سمك الجدار','Run length':'طول الوصلة','Branch length':'طول الفرع','Length':'الطول','Bend radius':'نصف قطر الكوع'}


def message(value):
    """Translate owned validation prose, keeping object names/paths untouched."""
    text=str(value)
    if text.startswith('تعذر إكمال العملية.'):return text
    if text in MESSAGES:return MESSAGES[text]
    # Dynamic messages have known prefixes. Never translate arbitrary embedded IDs.
    for key in sorted(MESSAGES,key=len,reverse=True):
        if text.startswith(key):
            rest=text[len(key):]
            translated=message(rest.lstrip()) if rest.strip() and any(rest.lstrip().startswith(k) for k in MESSAGES) else rest
            return MESSAGES[key]+translated
    m=re.fullmatch(r'Line (\d+): expected X,Y,Z using comma separators',text)
    if m:return 'السطر '+m[1]+': أدخل X,Y,Z مفصولة بفواصل إنجليزية'
    m=re.fullmatch(r'Line (\d+): invalid length values',text)
    if m:return 'السطر '+m[1]+': قيم الطول غير صالحة. استخدم رقماً ووحدة طول لكل إحداثي'
    m=re.fullmatch(r'(\d+) terminals have no explicit wire, not necessarily a design fault',text)
    if m:return m[1]+' أطراف بلا سلك صريح. هذه ملاحظة وليست بالضرورة خطأ تصميم'
    suffix=': parent Part/Body containers are not supported by this custom command; use root-frame sources'
    if text.endswith(suffix):return 'هذه الأداة لا تدعم مصدراً داخل حاوية Part أو Body. استخدم مصدراً في جذر المستند. المصدر: '+text[:-len(suffix)]
    suffix=' must be finite and positive'
    if text.endswith(suffix):return 'أدخل قيمة محدودة وأكبر من صفر للحقل: '+FIELD_NAMES.get(text[:-len(suffix)],text[:-len(suffix)])
    if any('\u0600'<=c<='\u06ff' for c in text):return text
    return 'تعذر إكمال العملية. راجع التحديد والقيم وحالة المصدر ثم أعد المحاولة. احتفظ بالتفصيل التقني عند طلب المساعدة:\n'+text


def level(value):return {'ERROR':'خطأ','NOTE':'ملاحظة','WARNING':'تنبيه'}.get(value,value)
def snap_mode(value):return {'endpoint':'نهاية','midpoint':'منتصف خط','grid':'شبكة','ortho':'تعامد','free':'حر'}.get(value,value)
def source_role(value):return {'Profile':'المقطع','SourcePath':'مسار المصدر','Base':'المصمت الأساسي','Tool':'مصمت الأداة','PortSource':'مصدر المنفذ','PatternSource':'مصدر التكرار','Source':'المصدر'}.get(value,value)
