"""Delta Engineering integration milestone. GPL-3.0-or-later.
Uses the user's FreeCAD runtime. Not a certified design/calculation tool.
All lengths are millimetres. Electrical connectivity is logical only.
"""
import math
import FreeCAD as App
import Part


def positive(value, name):
    n = float(value)
    if not math.isfinite(n) or n <= 0:
        raise ValueError(name + ' must be finite and positive')
    return n


class PipeRoute:
    def __init__(self, obj, points, outer=100, wall=5):
        obj.addProperty('App::PropertyVectorList', 'Route', 'Piping')
        obj.addProperty('App::PropertyLength', 'OuterDiameter', 'Piping')
        obj.addProperty('App::PropertyLength', 'WallThickness', 'Piping')
        obj.addProperty('App::PropertyLength', 'CenterlineLength', 'Quantities')
        obj.addProperty('App::PropertyString', 'Validation', 'Status')
        obj.Route = points
        obj.OuterDiameter = outer
        obj.WallThickness = wall
        obj.setEditorMode('CenterlineLength', 1)
        obj.setEditorMode('Validation', 1)
        obj.Proxy = self
        if App.GuiUp:
            obj.ViewObject.Proxy = 0

    def execute(self, obj):
        try:
            diameter = positive(obj.OuterDiameter.Value, 'Outer diameter')
            wall = positive(obj.WallThickness.Value, 'Wall thickness')
            if 2 * wall >= diameter:
                raise ValueError('Wall thickness must be less than radius')
            points = obj.Route
            if len(points) < 2:
                raise ValueError('Route needs at least two points')
            segments, length = [], 0.0
            for a, b in zip(points, points[1:]):
                vec = b - a
                size = positive(vec.Length, 'Segment length')
                segments.append(Part.makeCylinder(diameter/2, size, a, vec).cut(
                    Part.makeCylinder(diameter/2-wall, size, a, vec)))
                length += size
            # Separate tubes meet at route vertices. Elbow fittings are NOT generated.
            obj.Shape = Part.makeCompound(segments)
            obj.CenterlineLength = length
            obj.Validation = 'Valid route; fittings not generated'
        except (ValueError, RuntimeError) as exc:
            obj.Shape = Part.Shape()
            obj.CenterlineLength = 0
            obj.Validation = str(exc)


class Device:
    def __init__(self, obj, tag, position):
        obj.addProperty('App::PropertyString', 'Tag', 'Electrical')
        obj.addProperty('App::PropertyVector', 'Position', 'Electrical')
        obj.addProperty('App::PropertyString', 'DeviceType', 'Electrical')
        obj.addProperty('App::PropertyEnumeration','TerminalSide','Electrical')
        obj.TerminalSide=['Right','Left']
        obj.Tag, obj.Position, obj.DeviceType = tag, position, 'Generic schematic symbol'
        obj.Proxy = self
        if App.GuiUp:
            obj.ViewObject.Proxy = 0

    def execute(self, obj):
        p = obj.Position
        outline = Part.makePolygon([p+App.Vector(-60,-40,0),p+App.Vector(60,-40,0),
                    p+App.Vector(60,40,0),p+App.Vector(-60,40,0),p+App.Vector(-60,-40,0)])
        terminals=getattr(obj,'Terminals',[])
        circles=[Part.makeCircle(3,terminal_position(obj,name)) for name in terminals]
        if hasattr(obj,'SymbolTemplate') and obj.SymbolTemplate!='Generic block':
            from .symbols import outline as typed_outline
            shapes=typed_outline(obj)+circles
            for name in terminals:
                endpoint=terminal_position(obj,name)
                # Leaders are schematic only, not contacts or pin-order claims.
                y=endpoint.y-p.y;sign=-1 if obj.TerminalSide=='Left' else 1
                extent=35
                if obj.SymbolTemplate=='Motor concept':extent=math.sqrt(max(0,35*35-y*y))
                elif obj.SymbolTemplate=='Coil concept':extent=28
                elif obj.SymbolTemplate=='Earth concept':extent=0
                anchor=p+App.Vector(sign*extent,y,0)
                shapes.append(Part.makeLine(anchor,endpoint))
            obj.Shape=Part.makeCompound(shapes)
        else:obj.Shape=Part.makeCompound([outline]+circles) if circles else outline


def terminal_position(device,name):
    terminals=list(getattr(device,'Terminals',[]))
    if name not in terminals:raise ValueError('Unknown terminal: '+name)
    index=terminals.index(name)
    y=30-60*(index+1)/(len(terminals)+1)
    side=-1 if getattr(device,'TerminalSide','Right')=='Left' else 1
    return device.Position+App.Vector(side*60,y,0)



class Connection:
    def __init__(self, obj, start, end, wire_id):
        obj.addProperty('App::PropertyLink', 'SourceDevice', 'Electrical')
        obj.addProperty('App::PropertyLink', 'TargetDevice', 'Electrical')
        obj.addProperty('App::PropertyString', 'WireId', 'Electrical')
        obj.addProperty('App::PropertyString', 'Validation', 'Status')
        obj.addProperty('App::PropertyDistance', 'SchematicOffset', 'Electrical')
        obj.SourceDevice, obj.TargetDevice, obj.WireId = start, end, wire_id
        obj.setEditorMode('Validation', 1)
        obj.Proxy = self
        if App.GuiUp:
            obj.ViewObject.Proxy = 0

    def execute(self, obj):
        if not obj.SourceDevice or not obj.TargetDevice:
            obj.Shape = Part.Shape()
            obj.Validation = 'Missing device'
            return
        if hasattr(obj,'SourceTerminal'):
            try:
                a=terminal_position(obj.SourceDevice,obj.SourceTerminal)
                b=terminal_position(obj.TargetDevice,obj.TargetTerminal)
            except ValueError as exc:
                obj.Shape=Part.Shape();obj.Validation=str(exc);return
        else:
            a, b = obj.SourceDevice.Position, obj.TargetDevice.Position
            if (b-a).Length < 1e-6:
                obj.Shape=Part.Shape();obj.Validation='Coincident devices';return
            direction=b-a
            direction.normalize()
            a,b=a+direction*60,b-direction*60
        offset=obj.SchematicOffset.Value
        if abs(offset)>1e-9:
            if not math.isfinite(offset):
                obj.Shape=Part.Shape();obj.Validation='Wire offset must be finite';return
            source_sign=-1 if obj.SourceDevice.TerminalSide=='Left' else 1
            target_sign=-1 if obj.TargetDevice.TerminalSide=='Left' else 1
            start=a+App.Vector(source_sign*20,0,0);end=b+App.Vector(target_sign*20,0,0)
            level=(a.y+b.y)/2+offset
            points=[a,start,App.Vector(start.x,level,a.z),App.Vector(end.x,level,a.z),App.Vector(end.x,level,b.z),end,b]
            clean=[points[0]]
            for point in points[1:]:
                if (point-clean[-1]).Length>1e-7:clean.append(point)
            obj.Shape=Part.makePolygon(clean)
        else:
            obj.Shape = Part.makePolygon([a, App.Vector(b.x,a.y,a.z), b]) if abs(a.y-b.y)>1e-6 and abs(a.x-b.x)>1e-6 else Part.makeLine(a,b)
        obj.Validation = 'Logical connection only'


def create_demo(name='Delta_Illustrative'):
    """Reversible illustrative test case, not a statement of the user's design."""
    import Sketcher
    doc = App.newDocument(name)
    doc.UndoMode = 1
    root = doc.addObject('App::Part', 'Mechanical')
    root.Label = 'الميكانيكا | Mechanical'
    body = doc.addObject('PartDesign::Body', 'BaseBody')
    root.addObject(body)
    sketch = doc.addObject('Sketcher::SketchObject', 'BaseSketch')
    body.addObject(sketch)
    # Native constrained circle and native Pad, not a mesh or frozen illustration.
    sketch.addGeometry(Part.Circle(App.Vector(0,0,0),App.Vector(0,0,1),120),False)
    sketch.addConstraint(Sketcher.Constraint('Coincident',0,3,-1,1))
    sketch.addConstraint(Sketcher.Constraint('Radius',0,120))
    pad = body.newObject('PartDesign::Pad', 'BasePad')
    pad.Label = 'قاعدة ميكانيكية تجريبية'
    pad.Profile, pad.Length = sketch, 40
    piping = doc.addObject('App::DocumentObjectGroup', 'Piping')
    piping.Label = 'المواسير | Piping'
    pipe = doc.addObject('PartDesign::FeaturePython', 'PipeRoute')
    pipe.Label = 'مسار مواسير تجريبي'
    PipeRoute(pipe,[App.Vector(0,0,100),App.Vector(500,0,100),App.Vector(500,400,100)])
    piping.addObject(pipe)
    electrical = doc.addObject('App::DocumentObjectGroup', 'Electrical')
    electrical.Label = 'الكهرباء | Electrical'
    a = doc.addObject('PartDesign::FeaturePython', 'PanelSymbol')
    b = doc.addObject('PartDesign::FeaturePython', 'MotorSymbol')
    a.Label, b.Label = 'لوحة تجريبية P1', 'محرك تجريبي M1'
    Device(a, 'P1', App.Vector(0,-350,0))
    Device(b, 'M1', App.Vector(500,-350,0))
    wire = doc.addObject('PartDesign::FeaturePython', 'Wire')
    wire.Label = 'توصيل منطقي W1'
    Connection(wire,a,b,'W1')
    for o in (a,b,wire): electrical.addObject(o)
    doc.recompute()
    if App.GuiUp:
        sketch.Visibility = False
        pad.ViewObject.ShapeColor = (0.64,0.69,0.78)
        pipe.ViewObject.ShapeColor = (0.05,0.68,0.64)
        for o in (a,b,wire):
            o.ViewObject.LineColor = (1.0,0.65,0.15)
            o.ViewObject.LineWidth = 3
    return doc


def quantities(doc):
    return [{'name':o.Name,'label':o.Label,'length_mm':o.CenterlineLength.Value,
             'outer_diameter_mm':o.OuterDiameter.Value,'status':o.Validation}
            for o in doc.Objects if hasattr(o,'CenterlineLength')]
