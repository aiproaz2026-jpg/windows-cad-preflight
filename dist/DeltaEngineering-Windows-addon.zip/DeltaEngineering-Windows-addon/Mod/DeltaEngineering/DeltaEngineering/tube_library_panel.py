from .arabic import message
from .arabic_qt import Messages,Inputs
# SPDX-License-Identifier: GPL-3.0-or-later
from PySide import QtWidgets,QtCore
import FreeCADGui as Gui
from . import tube_library as library
from .precision import length

class TubeLibraryPanel(QtWidgets.QWidget):
    def __init__(self,panel):
        super().__init__();self.panel=panel;form=QtWidgets.QFormLayout(self);form.setAlignment(QtCore.Qt.AlignTop)
        note=QtWidgets.QLabel('مقاسات اسمية فقط، ليست مكتبة منتجات معتمدة. المصدر يحدد القطر والسمك ولا يمنح النموذج تصنيف ضغط أو مادة أو اعتماداً. نصف قطر الكوع إدخال مستقل، وليس مقاس كوع من الكتالوج.')
        note.setWordWrap(True);form.addRow(note)
        self.size=QtWidgets.QComboBox();self.size.addItems(list(library.PRESETS));form.addRow('NPS / Sch 40',self.size)
        self.info=QtWidgets.QLabel();self.info.setWordWrap(True);form.addRow(self.info)
        self.radius=QtWidgets.QLineEdit('150 mm');self.radius.setLayoutDirection(QtCore.Qt.LeftToRight);form.addRow('نصف قطر الكوع الهندسي',self.radius)
        for text,fn in [('مسار مواسير من المحدد بالمقاس الاسمي',self.create),('تطبيق المقاس على المواسير المحددة',self.apply),('فحص تطابق المقاس المسجل',self.check)]:
            b=QtWidgets.QPushButton(text);b.clicked.connect(lambda checked=False,f=fn:panel.safe(f));form.addRow(b)
        self.run=QtWidgets.QLineEdit('400 mm');self.branch=QtWidgets.QLineEdit('200 mm')
        for edit in (self.run,self.branch):edit.setLayoutDirection(QtCore.Qt.LeftToRight)
        form.addRow('طول مسار T العام',self.run);form.addRow('طول الفرع من المنتصف',self.branch)
        for text,fn in [('إنشاء T هندسية عامة، ليست قطعة كتالوج',self.tee),('تعديل أطوال T المحددة',self.edit_tee)]:
            b=QtWidgets.QPushButton(text);b.clicked.connect(lambda checked=False,f=fn:panel.safe(f));form.addRow(b)
        self.port=QtWidgets.QComboBox();self.port.addItems(['1 / -X','2 / +X','3 / +Y'])
        self.leg=QtWidgets.QLineEdit('300 mm');self.leg.setLayoutDirection(QtCore.Qt.LeftToRight)
        form.addRow('منفذ T المحلي',self.port);form.addRow('طول امتداد مرتبط',self.leg)
        for text,fn in [('إضافة ماسورة مرتبطة بمنفذ T المحدد',self.attach_port),('تعديل طول الامتداد المحدد',self.edit_leg)]:
            b=QtWidgets.QPushButton(text);b.clicked.connect(lambda checked=False,f=fn:panel.safe(f));form.addRow(b)
        source=QtWidgets.QLabel('<a href="'+library.SOURCE+'">مصدر الأبعاد: Wheatland / '+library.REVISION+'</a>');source.setOpenExternalLinks(False);source.setWordWrap(True);source.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse);form.addRow(source)
        self.size.currentIndexChanged.connect(self.refresh);self.refresh()
    def refresh(self):
        if self.size.currentIndex()<0:return
        p=library.PRESETS[self.preset_key()];self.info.setText('قطر خارجي: '+str(p['od_mm'])+' mm | سمك اسمي: '+str(p['wall_mm'])+' mm')
    def selected(self):
        selected=Gui.Selection.getSelection()
        if len(selected)!=1:raise ValueError('Select exactly one path or pipe system')
        return selected[0]
    def create(self):
        obj=library.route(self.panel.doc(),self.selected(),self.preset_key(),length(self.radius.text()))
        self.panel.profiles.select(obj);self.panel.status.setText('تم إنشاء هندسة بمقاسات اسمية فقط. الكوع غير منسوب لكتالوج.')
    def apply(self):
        obj=self.selected();radius=length(self.radius.text()) if hasattr(obj,'BendRadius') else None
        library.apply(self.panel.doc(),obj,self.preset_key(),radius);self.panel.status.setText(message(library.status(obj)))
    def check(self):self.panel.status.setText(message(library.status(self.selected())))

    def tee(self):
        from .branches import create_tee
        obj=create_tee(self.panel.doc(),self.preset_key(),length(self.run.text()),length(self.branch.text()));self.panel.profiles.select(obj)
        self.panel.status.setText('T هندسية عامة، طول فرع من المنتصف. لا يوجد تصنيف ضغط أو اعتماد وصلات.')
    def edit_tee(self):
        from .branches import update_tee
        update_tee(self.panel.doc(),self.selected(),length(self.run.text()),length(self.branch.text()))

    def attach_port(self):
        from .port_connections import attach
        obj=attach(self.panel.doc(),self.selected(),self.port.currentIndex(),length(self.leg.text()));self.panel.profiles.select(obj)
        self.panel.status.setText('امتداد مرتبط بالموقع والقطر. دون تحقق تصادم أو لحام أو ضغط، وليست شبكة محلولة.')
    def edit_leg(self):
        from .port_connections import update_leg
        update_leg(self.panel.doc(),self.selected(),length(self.leg.text()))

    def load_object(self,obj):
        if obj.Document!=self.panel.doc():raise ValueError('Select an object in the active document')
        dimension_source=obj.PortSource if hasattr(obj,'PortSource') else obj
        if not dimension_source or not hasattr(dimension_source,'OuterDiameter'):raise ValueError('Missing dimensional source')
        matches=[key for key,p in library.PRESETS.items() if abs(p['od_mm']-dimension_source.OuterDiameter.Value)<1e-7 and abs(p['wall_mm']-dimension_source.WallThickness.Value)<1e-7]
        self.size.setCurrentIndex(self.size.findText(matches[0]) if matches else -1)
        if not matches:self.info.setText('أبعاد مخصصة: قطر خارجي '+str(dimension_source.OuterDiameter.Value)+' / سمك '+str(dimension_source.WallThickness.Value)+' mm. اختر مقاساً صراحة قبل تطبيقه.')
        if hasattr(obj,'RunLength'):
            self.run.setText(format(obj.RunLength.Value,'.12g')+' mm');self.branch.setText(format(obj.BranchLength.Value,'.12g')+' mm')
        if hasattr(obj,'BendRadius'):self.radius.setText(format(obj.BendRadius.Value,'.12g')+' mm')
        if hasattr(obj,'PortSource'):
            self.port.setCurrentIndex(obj.PortIndex);self.leg.setText(format(obj.LegLength.Value,'.12g')+' mm')
        self.panel.status.setText('تم تحميل القيم فقط، لم يتغير النموذج. '+('مطابقة عددية للمقاس، ليست اعتماداً.' if matches else 'أبعاد مخصصة، لا يوجد مقاس اسمي محدد.'))

    def preset_key(self):
        key=self.size.currentText()
        if key not in library.PRESETS:raise ValueError('Choose an explicit nominal size first')
        return key
