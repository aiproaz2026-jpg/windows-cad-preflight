# SPDX-License-Identifier: GPL-3.0-or-later
"""Native editable planar profiles and source-linked linear extrusion."""
import math
import FreeCAD as App,Part
from .precision import length


def circle(doc,center,radius):
    import Draft
    radius=length(radius)
    if radius<=1e-7:raise ValueError('Radius must be positive')
    if not all(math.isfinite(v) for v in (center.x,center.y,center.z)):raise ValueError('Center must be finite')
    if App.ActiveDocument!=doc:raise ValueError('Activate the target document')
    doc.openTransaction('Create editable circle')
    try:
        obj=Draft.make_circle(radius,placement=App.Placement(center,App.Rotation()),face=False)
        obj.Label='دائرة قابلة للتعديل'
        from .documents import add_to
        add_to(doc,'DrawingSystem',obj);doc.recompute();doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def profile_face(source):
    from .documents import require_root_frame
    require_root_frame(source,'Custom profile extrusion')
    if 'Invalid' in source.State:raise ValueError('Profile contains unresolved native errors')
    if source.Shape.Solids:raise ValueError('Select a planar profile, not a solid')
    wires=source.Shape.Wires
    if not wires or any(not w.isClosed() or not w.isValid() for w in wires):raise ValueError('Select closed valid planar profile wires')
    face=Part.makeFace(wires,'Part::FaceMakerBullseye')
    if len(face.Faces)!=1 or not face.isValid() or face.Area<1e-8:
        raise ValueError('Profile must form one valid planar face, with optional nested holes')
    face=face.Faces[0]
    if 'Plane' not in type(face.Surface).__name__:raise ValueError('Profile must be planar')
    return face


class Extrusion:
    def __init__(self,obj,source,height):
        obj.addProperty('App::PropertyLink','Profile','Geometry');obj.Profile=source
        obj.addProperty('App::PropertyLength','Height','Geometry');obj.Height=height
        obj.addProperty('App::PropertyString','Validation','Status');obj.setEditorMode('Validation',1)
        obj.Proxy=self
        if App.GuiUp:obj.ViewObject.Proxy=0
    def execute(self,obj):
        try:
            if not obj.Profile or obj.Profile.Document!=obj.Document:raise ValueError('Missing profile in this document')
            h=length(obj.Height.Value)
            if h<=1e-7:raise ValueError('Height must be positive')
            face=profile_face(obj.Profile);normal=face.normalAt(0,0)
            # Stable positive normal for XY profiles, independent of vertex winding.
            if normal.z<0:normal=-normal
            shape=face.extrude(normal*h)
            if not shape.isValid() or len(shape.Solids)!=1:raise ValueError('Extrusion is not one valid solid')
            obj.Shape=shape;obj.Validation='Valid geometric extrusion; no material or design checks'
        except (ValueError,RuntimeError) as exc:
            obj.Shape=Part.Shape();obj.Validation=str(exc)


def extrude(doc,source,height):
    height=length(height)
    if source.Document!=doc or height<=1e-7:raise ValueError('Use a profile in this document and positive height')
    profile_face(source)
    doc.openTransaction('Extrude selected profile')
    try:
        obj=doc.addObject('PartDesign::FeaturePython','ProfileExtrusion');Extrusion(obj,source,height)
        from .documents import add_to
        add_to(doc,'MechanicalSystem',obj);doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        if App.GuiUp:obj.ViewObject.ShapeColor=(0.72,0.75,0.8)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def update_circle(doc,obj,center,radius):
    radius=length(radius)
    if obj.Document!=doc or not hasattr(obj,'Radius') or not hasattr(obj,'FirstAngle'):
        raise ValueError('Select a native Draft circle in this document')
    if radius<=1e-7 or not all(math.isfinite(v) for v in (center.x,center.y,center.z)):
        raise ValueError('Use finite center coordinates and positive radius')
    doc.openTransaction('Edit circle geometry')
    try:
        obj.Radius=radius;placement=obj.Placement;placement.Base=center;obj.Placement=placement;doc.recompute()
        for child in doc.Objects:
            if getattr(child,'Profile',None)==obj and child.Shape.isNull():raise ValueError(child.Validation)
        doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
