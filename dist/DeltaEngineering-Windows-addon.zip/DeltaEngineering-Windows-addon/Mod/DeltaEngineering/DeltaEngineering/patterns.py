# SPDX-License-Identifier: GPL-3.0-or-later
"""Source-linked geometric linear pattern, separate solids, not a BOM/assembly."""
import math
import FreeCAD as App,Part


class LinearPattern:
    def __init__(self,obj,source,count,step):
        obj.addProperty('App::PropertyLink','PatternSource','Pattern');obj.PatternSource=source
        obj.addProperty('App::PropertyInteger','InstanceCount','Pattern');obj.InstanceCount=count
        obj.addProperty('App::PropertyVector','StepVector','Pattern');obj.StepVector=step
        obj.addProperty('App::PropertyString','Validation','Status');obj.setEditorMode('Validation',1)
        obj.Proxy=self
        if App.GuiUp:obj.ViewObject.Proxy=0
    def execute(self,obj):
        try:
            source=obj.PatternSource
            if not source or source.Document!=obj.Document:raise ValueError('Pattern source missing')
            from .documents import require_root_frame
            require_root_frame(source,'Linear pattern source')
            if source.Shape.isNull() or not source.Shape.isValid() or len(source.Shape.Solids)!=1:raise ValueError('Pattern needs one valid source solid')
            count=obj.InstanceCount;step=obj.StepVector
            if not 2<=count<=200:raise ValueError('Pattern instance count must be 2 through 200')
            if not all(math.isfinite(v) for v in (step.x,step.y,step.z)) or step.Length<1e-7:raise ValueError('Use a finite nonzero step vector')
            copies=[]
            # Disallow any intersecting copy bounds, a conservative sufficient
            # clearance rule, not general collision classification.
            box=source.Shape.BoundBox
            for multiple in range(1,count):
                delta=step*multiple
                if all(abs(shift)<=extent+1e-6 for shift,extent in zip((delta.x,delta.y,delta.z),(box.XLength,box.YLength,box.ZLength))):
                    raise ValueError('Pattern copy bounding boxes may touch/overlap; increase spacing')
            for i in range(count):
                shape=source.Shape.copy();shape.translate(step*i);copies.append(shape)
            result=Part.makeCompound(copies)
            if not result.isValid() or len(result.Solids)!=count:raise ValueError('Invalid separate-solid pattern')
            obj.Shape=result;obj.Validation='Separate copied geometry only, not fused features, assembly links or BOM quantities. Conservative box clearance.'
        except (ValueError,RuntimeError) as exc:obj.Shape=Part.Shape();obj.Validation=str(exc)


def create(doc,source,count,step):
    if source.Document!=doc:raise ValueError('Select source in active document')
    if isinstance(count,bool) or int(count)!=count:raise ValueError('Instance count must be an integer')
    doc.openTransaction('Create linked linear geometric pattern')
    try:
        obj=doc.addObject('PartDesign::FeaturePython','LinearPattern');obj.Label='تكرار خطي هندسي'
        LinearPattern(obj,source,int(count),step)
        from .documents import add_to
        add_to(doc,'MechanicalSystem',obj);doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        if App.GuiUp:source.Visibility=False;obj.ViewObject.ShapeColor=(0.72,0.75,0.8)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def update(doc,obj,count,step):
    if obj.Document!=doc or not isinstance(getattr(obj,'Proxy',None),LinearPattern):raise ValueError('Select a linked linear pattern')
    if isinstance(count,bool) or int(count)!=count:raise ValueError('Instance count must be an integer')
    doc.openTransaction('Edit linear geometric pattern')
    try:
        obj.InstanceCount=int(count);obj.StepVector=step;doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
