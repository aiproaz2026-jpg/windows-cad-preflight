from .arabic import message
from .arabic_qt import Messages,Inputs
# SPDX-License-Identifier: GPL-3.0-or-later
from PySide import QtCore,QtWidgets
import FreeCAD as App,FreeCADGui as Gui
from .drafting import make_path,update_path,linked_dimension


class DraftingPanel(QtWidgets.QDockWidget):
    def __init__(self):
        super().__init__('الرسم والأبعاد | مليمتر',Gui.getMainWindow())
        self.setObjectName('DeltaDraftingPanel');self.setLayoutDirection(QtCore.Qt.RightToLeft)
        shell=QtWidgets.QWidget();self.setWidget(shell);outer=QtWidgets.QVBoxLayout(shell);outer.setContentsMargins(0,0,0,0)
        tabs=QtWidgets.QTabWidget();outer.addWidget(tabs)
        area=QtWidgets.QWidget();tabs.addTab(area,'الجدول والأبعاد');layout=QtWidgets.QVBoxLayout(area)
        info=QtWidgets.QLabel('أدخل نقاط المسار، ثم ارسمه أو عدّل المسار المحدد. بعد ذلك يمكن تحويله لمواسير. الأبعاد مرتبطة بترتيب نقاط الرسم.')
        info.setWordWrap(True);layout.addWidget(info)
        self.table=QtWidgets.QTableWidget(3,3);self.table.setHorizontalHeaderLabels(['X (mm)','Y (mm)','Z (mm)'])
        self.table.setLayoutDirection(QtCore.Qt.LeftToRight)
        for row,point in enumerate(((0,0,0),(800,0,0),(800,900,0))):
            for col,value in enumerate(point):self.table.setItem(row,col,QtWidgets.QTableWidgetItem(str(value)))
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        layout.addWidget(self.table)
        self.closed=QtWidgets.QCheckBox('مسار مغلق');layout.addWidget(self.closed)
        grid=QtWidgets.QGridLayout();layout.addLayout(grid)
        actions=[('إضافة نقطة',self.add_row),('حذف نقطة',self.remove_row),('رسم مسار جديد',self.create),('تحميل المسار المحدد',self.load),('حفظ تعديل المسار',self.update),('تحويل المسار لمواسير',self.pipe),('لصق إحداثيات نصية',self.paste_points),('نسخ إحداثيات الجدول',self.copy_points)]
        for i,(label,fn) in enumerate(actions):
            b=QtWidgets.QPushButton(label);b.clicked.connect(lambda checked=False,callback=fn:self.safe(callback));grid.addWidget(b,i//2,i%2)
        form=QtWidgets.QFormLayout();layout.addLayout(form)
        self.start=QtWidgets.QSpinBox();self.end=QtWidgets.QSpinBox()
        for spin in (self.start,self.end):spin.setRange(1,10000)
        self.end.setValue(2)
        self.offset=QtWidgets.QDoubleSpinBox();self.offset.setRange(-1000000,1000000);self.offset.setValue(120)
        form.addRow('نقطة بداية البعد (١ = الأولى)',self.start);form.addRow('نقطة نهاية البعد',self.end);form.addRow('إزاحة خط البعد (مم)',self.offset)
        form.setRowWrapPolicy(QtWidgets.QFormLayout.WrapLongRows)
        b=QtWidgets.QPushButton('إضافة بعد مرتبط');b.clicked.connect(lambda:self.safe(self.dimension));layout.addWidget(b)
        b=QtWidgets.QPushButton('إخراج الرسم والأبعاد PDF');b.clicked.connect(lambda:self.safe(self.export));layout.addWidget(b)
        self.status=QtWidgets.QLabel('جاهز للرسم');self.status.setWordWrap(True);outer.addWidget(self.status)
        self.setMinimumWidth(350);self.setMaximumWidth(440)
        self.status.setTextFormat(QtCore.Qt.PlainText)
        self.path_name=None;self.doc_name=None
        from .hybrid import HybridInput
        hybrid_area=QtWidgets.QWidget();hybrid_layout=QtWidgets.QVBoxLayout(hybrid_area)
        self.hybrid=HybridInput(self,hybrid_layout);hybrid_layout.addStretch()
        tabs.addTab(hybrid_area,'يدوي ودقيق');self.tabs=tabs
        from .profile_panel import ProfilePanel
        self.profiles=ProfilePanel(self);scroll=QtWidgets.QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.profiles);tabs.addTab(scroll,'مقاطع وأجزاء')
        from .selection_context import SelectionContext
        self.selection_context=SelectionContext(self,outer)
        from .tube_library_panel import TubeLibraryPanel
        self.tubes=TubeLibraryPanel(self);tabs.addTab(self.tubes,'مقاسات مواسير')
    def paste_points(self):
        from .coordinate_text import load_text
        text,ok=Inputs.getMultiLineText(self,'إحداثيات نصية','صف لكل نقطة: X,Y,Z بوحدات طول. العنوان X,Y,Z اختياري. يستبدل الجدول فقط ولا يعدّل الرسم.')
        if ok:load_text(self,text)
    def copy_points(self):
        from .coordinate_text import serialize
        QtWidgets.QApplication.clipboard().setText(serialize(self.points()));self.status.setText('تم نسخ إحداثيات الجدول بوحدة mm. لا يتم تعديل الرسم.')
    def safe(self,fn):
        try:fn()
        except Exception as exc:self.status.setText('لم يتم التعديل: '+message(exc));Messages.warning(self,'تعذر الرسم',message(exc))
    def doc(self):
        d=App.ActiveDocument or App.newDocument('DrawingProject');d.UndoMode=1;return d
    def points(self):
        result=[]
        for row in range(self.table.rowCount()):
            values=[]
            for col in range(3):
                item=self.table.item(row,col)
                if not item:raise ValueError('أكمل كل الإحداثيات')
                from .precision import length
                values.append(length(item.text()))
            result.append(App.Vector(*values))
        return result
    def add_row(self):
        row=self.table.rowCount();self.table.insertRow(row)
        for col in range(3):self.table.setItem(row,col,QtWidgets.QTableWidgetItem('0'))
    def remove_row(self):
        row=self.table.currentRow()
        if row<0:row=self.table.rowCount()-1
        if row>=0:self.table.removeRow(row)
    def selected(self):
        selected=Gui.Selection.getSelection()
        if len(selected)==1 and hasattr(selected[0],'Points'):return selected[0]
        d=App.ActiveDocument
        if d and d.Name==self.doc_name and self.path_name:
            obj=d.getObject(self.path_name)
            if obj:return obj
        raise ValueError('حدد مسار Draft واحداً أو حمّله أولاً')
    def remember(self,obj):
        self.path_name=obj.Name;self.doc_name=obj.Document.Name
        Gui.Selection.clearSelection();Gui.Selection.addSelection(obj)
    def create(self):
        obj=make_path(self.doc(),self.points(),self.closed.isChecked());self.remember(obj)
        self.status.setText('تم إنشاء المسار: '+obj.Label)
        Gui.activeDocument().activeView().viewTop();Gui.activeDocument().activeView().fitAll()
    def load(self):
        obj=self.selected();self.remember(obj);self.table.setRowCount(len(obj.Points))
        for row,p in enumerate(obj.Points):
            for col,value in enumerate((p.x,p.y,p.z)):self.table.setItem(row,col,QtWidgets.QTableWidgetItem(str(value)))
        self.closed.setChecked(obj.Closed);self.status.setText('تم تحميل المسار للتعديل')
    def update(self):
        obj=self.selected()
        if bool(obj.Closed)!=self.closed.isChecked():raise ValueError('تغيير حالة الغلق غير متاح لهذا التعديل، ارسم مساراً جديداً')
        update_path(self.doc(),obj,self.points());self.remember(obj)
        self.status.setText('تم تحديث المسار والأبعاد والتوابع المرتبطة')
        Gui.activeDocument().activeView().fitAll()
    def dimension(self):
        obj=self.selected();dim=linked_dimension(self.doc(),obj,self.start.value()-1,self.end.value()-1,self.offset.value())
        if App.GuiUp:dim.ViewObject.FontSize=30
        self.remember(obj);self.status.setText('البعد الحالي: '+str(dim.Distance))
        Gui.activeDocument().activeView().fitAll()
    def export(self):
        import os
        from .drafting import export_dimensioned
        obj=self.selected()
        path,_=QtWidgets.QFileDialog.getSaveFileName(self,'إخراج الرسم والأبعاد','','PDF (*.pdf)')
        if not path:return
        if os.path.exists(path):
            if Messages.question(self,'ملف موجود','استبدال الملف؟',Messages.Yes|Messages.No)!=Messages.Yes:return
        report=export_dimensioned(self.doc(),obj,path)
        self.status.setText('تم إخراج الرسم مع '+str(report['dimensions'])+' أبعاد. الإخراج ملائم للصفحة وليس بمقياس معتمد.')
    def pipe(self):
        obj=self.selected();self.remember(obj);Gui.runCommand('Delta_RouteFromPath')


def show_panel():
    panel=Gui.getMainWindow().findChild(QtWidgets.QDockWidget,'DeltaDraftingPanel')
    if panel:panel.show();panel.raise_();return panel
    panel=DraftingPanel();Gui.getMainWindow().addDockWidget(QtCore.Qt.RightDockWidgetArea,panel);panel.show();Gui.getMainWindow().resizeDocks([panel],[400],QtCore.Qt.Horizontal);return panel
