# SPDX-License-Identifier: GPL-3.0-or-later
"""Native Sketcher solver workflows, not a replacement geometry solver."""
import FreeCAD as App,Part,Sketcher
from .precision import length


def validate(sketch):
    if sketch.solve()!=0 or sketch.ConflictingConstraints or sketch.RedundantConstraints or sketch.MalformedConstraints:
        raise ValueError('Native sketch solver reports conflicting, redundant or malformed constraints')
    if not sketch.Shape.isValid():raise ValueError('Invalid sketch geometry')
    return sketch.FullyConstrained


def rectangle(doc,width,depth):
    width=length(width);depth=length(depth)
    if min(width,depth)<=1e-7:raise ValueError('Sketch dimensions must be positive')
    doc.openTransaction('Native constrained rectangle')
    try:
        s=doc.addObject('Sketcher::SketchObject','ConstrainedProfile');s.Label='مستطيل بقيود هندسية أصلية'
        p=[App.Vector(),App.Vector(width,0,0),App.Vector(width,depth,0),App.Vector(0,depth,0)]
        for a,b in zip(p,p[1:]+p[:1]):s.addGeometry(Part.LineSegment(a,b),False)
        for i in range(4):s.addConstraint(Sketcher.Constraint('Coincident',i,2,(i+1)%4,1))
        for i in (0,2):s.addConstraint(Sketcher.Constraint('Horizontal',i))
        for i in (1,3):s.addConstraint(Sketcher.Constraint('Vertical',i))
        s.addConstraint(Sketcher.Constraint('Coincident',0,1,-1,1))
        for name,index,value in [('Width',0,width),('Depth',1,depth)]:
            c=s.addConstraint(Sketcher.Constraint('Distance',index,value));s.renameConstraint(c,name)
        from .documents import add_to
        add_to(doc,'DrawingSystem',s);doc.recompute();validate(s);doc.commitTransaction();return s
    except Exception:doc.abortTransaction();doc.recompute();raise


def update_rectangle(doc,s,width,depth):
    if s.Document!=doc or not s.isDerivedFrom('Sketcher::SketchObject'):raise ValueError('Select a native sketch in this document')
    width=length(width);depth=length(depth)
    if min(width,depth)<=1e-7:raise ValueError('Dimensions must be positive')
    # Named constraints identify the template without relying on sketch object names.
    names={c.Name for c in s.Constraints}
    if not {'Width','Depth'}.issubset(names):raise ValueError('Sketch must contain Width and Depth constraints')
    doc.openTransaction('Edit native sketch dimensions')
    try:
        s.setDatum('Width',App.Units.Quantity(str(width)+' mm'));s.setDatum('Depth',App.Units.Quantity(str(depth)+' mm'))
        doc.recompute();validate(s)
        for obj in doc.Objects:
            if getattr(obj,'Profile',None)==s and obj.Shape.isNull():raise ValueError(obj.Validation)
        doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise


def annulus(doc,outer,inner):
    outer=length(outer);inner=length(inner)
    if not 0<inner<outer:raise ValueError('Require 0 < inner radius < outer radius')
    doc.openTransaction('Native constrained ring profile')
    try:
        s=doc.addObject('Sketcher::SketchObject','ConstrainedRing');s.Label='مقطع حلقي بقيود أصلية'
        for radius,name in ((outer,'OuterRadius'),(inner,'InnerRadius')):
            i=s.addGeometry(Part.Circle(App.Vector(),App.Vector(0,0,1),radius),False)
            s.addConstraint(Sketcher.Constraint('Coincident',i,3,-1,1))
            c=s.addConstraint(Sketcher.Constraint('Radius',i,radius));s.renameConstraint(c,name)
        from .documents import add_to
        add_to(doc,'DrawingSystem',s);doc.recompute();validate(s);doc.commitTransaction();return s
    except Exception:doc.abortTransaction();doc.recompute();raise


def update_annulus(doc,sketch,outer,inner):
    if sketch.Document!=doc or not sketch.isDerivedFrom('Sketcher::SketchObject'):raise ValueError('Select a native ring sketch in this document')
    outer=length(outer);inner=length(inner)
    if not 0<inner<outer:raise ValueError('Require 0 < inner radius < outer radius')
    if not {'OuterRadius','InnerRadius'}.issubset({c.Name for c in sketch.Constraints}):raise ValueError('Sketch needs OuterRadius and InnerRadius named constraints')
    doc.openTransaction('Edit native ring radii')
    try:
        # Expand outside first or contract inside first to avoid a transient
        # crossed pair while maintaining the final annulus intent.
        if outer>sketch.getDatum('OuterRadius').Value:order=[('OuterRadius',outer),('InnerRadius',inner)]
        else:order=[('InnerRadius',inner),('OuterRadius',outer)]
        for name,value in order:sketch.setDatum(name,App.Units.Quantity(str(value)+' mm'))
        doc.recompute();validate(sketch)
        from .validation import valid_document
        valid_document(doc)
        for obj in doc.Objects:
            if hasattr(obj,'Validation') and hasattr(obj,'Shape') and obj.Shape.isNull():raise ValueError('Invalid downstream geometry: '+obj.Label+' / '+obj.Validation)
        doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
