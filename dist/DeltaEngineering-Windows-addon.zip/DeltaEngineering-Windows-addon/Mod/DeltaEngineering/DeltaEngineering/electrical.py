# SPDX-License-Identifier: GPL-3.0-or-later
"""Atomic electrical graph edits. Generic symbols, not engineering design checks."""
import FreeCAD as App
from .domain import netlist,add_terminal_wire


def wires_for(doc,device,terminal=None):
    return [o for o in doc.Objects if hasattr(o,'SourceTerminal') and
            ((o.SourceDevice==device and (terminal is None or o.SourceTerminal==terminal)) or
             (o.TargetDevice==device and (terminal is None or o.TargetTerminal==terminal)))]


def _transaction(doc,label,fn):
    doc.openTransaction(label)
    try:
        result=fn()
        doc.recompute()
        netlist(doc)
        for obj in doc.Objects:
            if hasattr(obj,'SourceTerminal') and obj.Shape.isNull():raise ValueError(obj.Validation)
        doc.commitTransaction()
        return result
    except Exception:
        doc.abortTransaction();doc.recompute();raise


def rename_device(doc,device,tag):
    tag=tag.strip()
    if not tag or any(o!=device and getattr(o,'Tag',None)==tag for o in doc.Objects):
        raise ValueError('Device tag must be nonempty and unique')
    def action():
        device.Tag=tag;device.Label=tag
    return _transaction(doc,'Rename electrical device',action)


def rename_terminal(doc,device,old,new):
    new=new.strip()
    if old not in device.Terminals or not new or new in device.Terminals:
        raise ValueError('Terminal name must be new, nonempty and unique')
    def action():
        device.Terminals=[new if n==old else n for n in device.Terminals]
        for wire in wires_for(doc,device,old):
            if wire.SourceDevice==device and wire.SourceTerminal==old:wire.SourceTerminal=new
            if wire.TargetDevice==device and wire.TargetTerminal==old:wire.TargetTerminal=new
    return _transaction(doc,'Rename electrical terminal',action)


def remove_terminal(doc,device,name,cascade=False):
    if name not in device.Terminals:raise ValueError('Unknown terminal')
    attached=wires_for(doc,device,name)
    if attached and not cascade:raise ValueError('Terminal has connected wires')
    def action():
        for wire in attached:doc.removeObject(wire.Name)
        device.Terminals=[n for n in device.Terminals if n!=name]
    return _transaction(doc,'Remove electrical terminal',action)


def remove_device(doc,device,cascade=False):
    attached=wires_for(doc,device)
    if attached and not cascade:raise ValueError('Device has connected wires')
    def action():
        for wire in attached:doc.removeObject(wire.Name)
        doc.removeObject(device.Name)
    return _transaction(doc,'Remove electrical device',action)


def append_terminal(doc,device,name):
    from .domain import add_terminal
    return _transaction(doc,'Add electrical terminal',lambda:add_terminal(device,name.strip()))


def rename_wire(doc,wire,name):
    name=name.strip()
    if not name or any(o!=wire and getattr(o,'WireId',None)==name for o in doc.Objects):
        raise ValueError('Wire identifier must be nonempty and unique')
    return _transaction(doc,'Rename wire',lambda:setattr(wire,'WireId',name))


def disconnect(doc,wire):
    return _transaction(doc,'Disconnect wire',lambda:doc.removeObject(wire.Name))


def move_device(doc,device,position):
    import math
    if device.Document!=doc or not all(math.isfinite(v) for v in (position.x,position.y,position.z)):
        raise ValueError('Use finite coordinates in the active document')
    def action():
        device.Position=position
    return _transaction(doc,'Move electrical device',action)


def wire_offset(doc,wire,offset):
    import math
    offset=float(offset)
    if wire.Document!=doc or not math.isfinite(offset):raise ValueError('Use a finite route offset in this document')
    return _transaction(doc,'Set orthogonal wire route',lambda:setattr(wire,'SchematicOffset',offset))


def terminal_layout(doc,device,names,side):
    """Reorder named schematic terminals without changing graph identities."""
    if device.Document!=doc or not hasattr(device,'Terminals') or side not in ('Left','Right'):raise ValueError('Select a terminal device in this document and explicit side')
    names=list(names);existing=list(device.Terminals)
    if len(names)!=len(existing) or len(set(names))!=len(names) or set(names)!=set(existing):raise ValueError('Terminal layout must contain every existing name exactly once, no rename/add/delete')
    def action():device.Terminals=names;device.TerminalSide=side
    return _transaction(doc,'Reorder schematic terminal positions',action)
