# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only exact-kernel selection measurement, no drawing annotations or tolerance claim."""
import math
import FreeCAD as App


def shape_for(entry):
    obj=entry.Object
    if not obj or not hasattr(obj,'Shape') or obj.Shape.isNull():raise ValueError('Select model geometry')
    from .documents import ancestor_placement,world_shape
    names=list(entry.SubElementNames)
    if len(names)>1:raise ValueError('Choose at most one subelement per selection entry')
    if not names:return obj,world_shape(obj),'Object'
    name=names[0]
    # Resolve via native API; never evaluate a label or user text as code.
    if not any(name.startswith(prefix) and name[len(prefix):].isdigit() for prefix in ('Vertex','Edge','Face')):raise ValueError('Only whole objects, vertices, edges or faces supported')
    shape=obj.Shape.getElement(name).copy()
    # Native getElement retains Shape's local object placement in this runtime.
    shape.Placement=ancestor_placement(obj).multiply(shape.Placement)
    return obj,shape,name


def inspect(entries):
    # Native selection groups multiple subelements of one object in one entry.
    # Treat each explicit subelement as a target, never measure the whole parent.
    from types import SimpleNamespace
    targets=[]
    for entry in entries:
        names=list(entry.SubElementNames)
        for name in names or (None,):
            targets.append(SimpleNamespace(Object=entry.Object,SubElementNames=[name] if name else []))
    if not 1<=len(targets)<=2:raise ValueError('Select one or two geometry targets, including two subelements of one object')
    identities=[(entry.Object.Name,tuple(entry.SubElementNames)) for entry in targets if entry.Object]
    if len(set(identities))!=len(identities):raise ValueError('Select distinct geometry targets')
    entries=targets
    from .validation import valid_document
    documents={entry.Object.Document for entry in entries if entry.Object}
    if len(documents)!=1:raise ValueError('Measure geometry in one document only')
    for doc in documents:valid_document(doc)
    selected=[shape_for(entry) for entry in entries];rows=[]
    for obj,shape,name in selected:
        if not shape.isValid():raise ValueError('Selected geometry is invalid: '+obj.Label)
        box=shape.optimalBoundingBox(False,False)
        item={'object':obj.Name,'label':obj.Label,'selection':name,'shape_type':shape.ShapeType,
              'bounds_mm':{'min':[box.XMin,box.YMin,box.ZMin],'max':[box.XMax,box.YMax,box.ZMax]},
              'length_mm':shape.Length,'area_mm2':shape.Area,'volume_mm3':shape.Volume,'solid_count':len(shape.Solids)}
        if shape.ShapeType=='Vertex':item['point_mm']=[shape.Point.x,shape.Point.y,shape.Point.z]
        if shape.ShapeType=='Edge' and hasattr(shape.Curve,'Radius'):item['radius_mm']=shape.Curve.Radius
        rows.append(item)
    distance=None;angle=None;face_angle=None
    if len(selected)==2:
        first,second=selected[0][1],selected[1][1];distance=float(first.distToShape(second)[0])
        if first.ShapeType==second.ShapeType=='Edge' and all('Line' in type(shape.Curve).__name__ for shape in (first,second)):
            a=first.Vertexes[-1].Point-first.Vertexes[0].Point;b=second.Vertexes[-1].Point-second.Vertexes[0].Point
            if min(a.Length,b.Length)>1e-9:angle=math.degrees(math.acos(max(-1,min(1,abs(a.dot(b)/(a.Length*b.Length))))))
        if first.ShapeType==second.ShapeType=='Face' and all(type(shape.Surface).__name__=='Plane' for shape in (first,second)):
            a=first.normalAt(0,0);b=second.normalAt(0,0)
            face_angle=math.degrees(math.acos(max(-1,min(1,abs(a.dot(b)/(a.Length*b.Length))))))
    return {'items':rows,'minimum_distance_mm':distance,'unoriented_line_angle_degrees':angle,'unoriented_planar_face_angle_degrees':face_angle,
            'scope':'Read-only kernel geometry values. Distance is minimum separation, not center distance, fit, tolerance, wall thickness or engineering acceptance. Angles are acute/unoriented for two straight edges or two planar faces only. No persistent drawing dimension is created.'}
