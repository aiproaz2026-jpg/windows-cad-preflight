# SPDX-License-Identifier: GPL-3.0-or-later
"""Generic hollow tee geometry. No catalog fitting dimensions or rating."""
import FreeCAD as App,Part
from .core import positive


class GeometricTee:
    def __init__(self,obj,diameter,wall,run,branch):
        for key in ('OuterDiameter','WallThickness','RunLength','BranchLength'):
            obj.addProperty('App::PropertyLength',key,'Geometry')
        obj.OuterDiameter=diameter;obj.WallThickness=wall;obj.RunLength=run;obj.BranchLength=branch
        obj.addProperty('App::PropertyVectorList','PortCenters','Connections')
        obj.addProperty('App::PropertyVectorList','PortDirections','Connections')
        obj.addProperty('App::PropertyLength','CenterlineLength','Quantities')
        obj.addProperty('App::PropertyString','Validation','Status')
        for key in ('PortCenters','PortDirections','CenterlineLength','Validation'):obj.setEditorMode(key,1)
        obj.Proxy=self
        if App.GuiUp:obj.ViewObject.Proxy=0
    def execute(self,obj):
        try:
            od=positive(obj.OuterDiameter.Value,'Diameter');wall=positive(obj.WallThickness.Value,'Wall')
            run=positive(obj.RunLength.Value,'Run length');branch=positive(obj.BranchLength.Value,'Branch length')
            if wall>=od/2 or run<=2*od or branch<=od:raise ValueError('Require wall < OD/2, run > 2*OD, branch > OD')
            start=App.Vector(-run/2,0,0);origin=App.Vector();x=App.Vector(1,0,0);y=App.Vector(0,1,0)
            outer=Part.makeCylinder(od/2,run,start,x).fuse(Part.makeCylinder(od/2,branch,origin,y))
            bore=Part.makeCylinder(od/2-wall,run+2,start-App.Vector(1,0,0),x).fuse(Part.makeCylinder(od/2-wall,branch+1,origin,y))
            shape=outer.cut(bore).removeSplitter()
            if not shape.isValid() or len(shape.Solids)!=1:raise ValueError('Tee must be one valid hollow solid')
            obj.Shape=shape;obj.PortCenters=[start,App.Vector(run/2,0,0),App.Vector(0,branch,0)]
            obj.PortDirections=[App.Vector(-1,0,0),x,y];obj.CenterlineLength=run+branch
            obj.Validation='Generic intersecting-tube tee only. No catalog face-to-face, weld, stress, loss or pressure checks.'
        except (ValueError,RuntimeError) as exc:
            obj.Shape=Part.Shape();obj.PortCenters=[];obj.PortDirections=[];obj.CenterlineLength=0;obj.Validation=str(exc)


def create_tee(doc,key,run,branch):
    from .tube_library import PRESETS,record
    from .documents import add_to
    p=PRESETS[key]
    doc.openTransaction('Generic tee with cited tube dimensions')
    try:
        obj=doc.addObject('PartDesign::FeaturePython','GeometricTee');obj.Label='وصلة T هندسية عامة'
        GeometricTee(obj,p['od_mm'],p['wall_mm'],run,branch);record(obj,p);add_to(doc,'PipingSystem',obj);doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        if App.GuiUp:obj.ViewObject.ShapeColor=(0.05,0.68,0.64)
        doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def update_tee(doc,obj,run,branch):
    if obj.Document!=doc or not isinstance(getattr(obj,'Proxy',None),GeometricTee):raise ValueError('Select a generic tee in this document')
    doc.openTransaction('Edit generic tee lengths')
    try:
        obj.RunLength=run;obj.BranchLength=branch;doc.recompute()
        if obj.Shape.isNull():raise ValueError(obj.Validation)
        doc.commitTransaction()
    except Exception:doc.abortTransaction();doc.recompute();raise
