# SPDX-License-Identifier: GPL-3.0-or-later
"""Native STEP geometry interchange, with isolated readback and safe replacement."""
import os,tempfile
import FreeCAD as App,Part,Import
from .export import path_for_python


def export_step(doc,objects,target):
    from .validation import valid_document
    valid_document(doc)
    if not objects:raise ValueError('Select one or more solid objects')
    for obj in objects:
        if obj.Document!=doc or not hasattr(obj,'Shape') or not obj.Shape.isValid() or not obj.Shape.Solids:
            raise ValueError('STEP export accepts valid selected solid geometry in this document')
    fd,temp=tempfile.mkstemp(suffix='.step',dir=os.path.dirname(os.path.abspath(target)));os.close(fd)
    try:
        from .documents import world_shape
        expected_shape=Part.makeCompound([world_shape(o) for o in objects])
        # Export world-coordinate copies in a disposable document. Original labels
        # are preserved, but native history is intentionally not a STEP promise.
        active=App.ActiveDocument.Name if App.ActiveDocument else None
        staging=App.newDocument('STEPStaging')
        try:
            copies=[]
            for original in objects:
                copy=staging.addObject('PartDesign::Feature','ExportItem');copy.Label=original.Label;copy.Shape=world_shape(original);copies.append(copy)
            staging.recompute();Import.export(copies,temp)
        finally:
            App.closeDocument(staging.Name)
            if active and App.getDocument(active):App.setActiveDocument(active)
        shape=Part.read(temp)
        expected=expected_shape.Volume
        if not shape.isValid() or abs(shape.Volume-expected)>max(1e-4,expected*1e-7):raise ValueError('STEP roundtrip volume mismatch')
        expected_bounds=expected_shape.optimalBoundingBox(False,False);actual_bounds=shape.optimalBoundingBox(False,False)
        for expected_value,actual_value in zip((expected_bounds.XMin,expected_bounds.YMin,expected_bounds.ZMin,expected_bounds.XMax,expected_bounds.YMax,expected_bounds.ZMax),(actual_bounds.XMin,actual_bounds.YMin,actual_bounds.ZMin,actual_bounds.XMax,actual_bounds.YMax,actual_bounds.ZMax)):
            if abs(expected_value-actual_value)>max(1e-4,abs(expected_value)*1e-7):raise ValueError('STEP world-coordinate bounds mismatch')
        os.replace(path_for_python(temp),path_for_python(target))
        return {'solid_count':len(shape.Solids),'volume_mm3':shape.Volume,'geometry_only':True}
    finally:
        if os.path.exists(path_for_python(temp)):os.remove(path_for_python(temp))


def import_step(doc,path):
    # Parse before opening a transaction. STEP does not preserve native feature history.
    if os.path.splitext(path)[1].lower() not in ('.step','.stp'):raise ValueError('Choose a STEP file')
    shape=Part.read(path)
    if shape.isNull() or not shape.isValid() or not shape.Solids:raise ValueError('File must contain valid STEP solids')
    doc.openTransaction('Import STEP solid geometry')
    try:
        obj=doc.addObject('PartDesign::Feature','ImportedSTEP');obj.Shape=shape;obj.Label=os.path.basename(path)
        from .documents import add_to
        add_to(doc,'MechanicalSystem',obj);doc.recompute();doc.commitTransaction();return obj
    except Exception:doc.abortTransaction();doc.recompute();raise


def export_dxf(doc,objects,target):
    from .validation import valid_document
    valid_document(doc)
    from .documents import ancestor_placement
    if not objects:raise ValueError('Select planar wire geometry')
    for obj in objects:
        placement=ancestor_placement(obj)
        if placement.Base.Length>1e-7 or abs(placement.Rotation.Angle)>1e-7:raise ValueError('DXF does not support transformed parent containers; export root XY wires only')
        if obj.Document!=doc or not hasattr(obj,'Shape') or obj.Shape.Solids or obj.Shape.isNull():raise ValueError('DXF command accepts planar wire geometry, not solids or dimensions')
        if obj.Shape.BoundBox.ZLength>1e-7 or abs(obj.Shape.BoundBox.ZMin)>1e-7:raise ValueError('Only XY planar geometry is supported by this command')
    fd,temp=tempfile.mkstemp(suffix='.dxf',dir=os.path.dirname(os.path.abspath(target)));os.close(fd)
    try:
        Import.writeDXFObject(objects,temp,14,False)
        if os.path.getsize(path_for_python(temp))<100:raise ValueError('DXF export is empty')
        # Native strict readback in a disposable document, no optional downloader.
        active=App.ActiveDocument.Name if App.ActiveDocument else None
        probe=App.newDocument('DXFValidation')
        try:
            Import.readDXF(temp,probe.Name,False)
            readback=[o.Shape for o in probe.Objects if hasattr(o,'Shape') and not o.isDerivedFrom('App::DocumentObjectGroup')]
            if not readback:raise ValueError('DXF readback contains no geometry')
            restored=Part.makeCompound(readback);source=Part.makeCompound([o.Shape for o in objects])
            source_box=source.optimalBoundingBox(False,False);restored_box=restored.optimalBoundingBox(False,False)
            for expected,actual in zip((source_box.XLength,source_box.YLength,source.Length),(restored_box.XLength,restored_box.YLength,restored.Length)):
                if abs(expected-actual)>max(1e-4,expected*1e-7):raise ValueError('DXF readback geometric mismatch '+str((expected,actual)))
        finally:
            App.closeDocument(probe.Name)
            if active and App.getDocument(active):App.setActiveDocument(active)
        os.replace(path_for_python(temp),path_for_python(target))
        return {'objects':len(objects),'geometry_only':True,'units':'mm'}
    finally:
        if os.path.exists(path_for_python(temp)):os.remove(path_for_python(temp))
