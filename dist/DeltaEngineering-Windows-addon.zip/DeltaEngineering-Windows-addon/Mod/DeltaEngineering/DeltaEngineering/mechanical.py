# SPDX-License-Identifier: GPL-3.0-or-later
import FreeCAD as App
import Part


def make_assembly_example(doc):
    """Native assembly plus component links; only base grounding, no mate solver claim."""
    import JointObject
    assembly=doc.addObject('Assembly::AssemblyObject','MechanicalAssembly')
    assembly.Label='تجميع ميكانيكي تجريبي'
    assembly.Type='Assembly'
    joints=assembly.newObject('Assembly::JointGroup','Joints')
    base=doc.addObject('Part::Box','AssemblyBase')
    base.Length,base.Width,base.Height=300,200,20
    base.Label='قاعدة التجميع'
    shaft=doc.addObject('Part::Cylinder','AssemblyShaft')
    shaft.Radius,shaft.Height=25,150
    shaft.Label='عمود تجريبي'
    link_base=assembly.newObject('App::Link','BaseInstance')
    link_base.setLink(base)
    link_shaft=assembly.newObject('App::Link','ShaftInstance')
    link_shaft.setLink(shaft)
    link_shaft.Placement.Base=App.Vector(150,100,20)
    grounded=joints.newObject('App::FeaturePython','GroundedBase')
    JointObject.GroundedJoint(grounded,link_base)
    doc.recompute()
    if App.GuiUp:
        base.Visibility=False
        shaft.Visibility=False
    return assembly
