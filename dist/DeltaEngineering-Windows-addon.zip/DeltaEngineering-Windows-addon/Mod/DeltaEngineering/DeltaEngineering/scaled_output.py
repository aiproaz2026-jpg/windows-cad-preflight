# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit-scale single-view drawing PDF. Reject overflow instead of auto fitting."""
import os,tempfile,math
import FreeCAD as App,Part,TechDraw
from PySide import QtGui,QtCore,QtSvg
from .export import path_for_python


VIEWS={'Top':('علوي',App.Vector(0,0,1)),'Front':('أمامي',App.Vector(0,-1,0)),'Right':('أيمن',App.Vector(1,0,0))}


def _page_shape(shape,view_name):
    """Independent fixed axes: Top X/Y; Front X/Z; Right Y/Z."""
    rotations={'Top':App.Rotation(),'Front':App.Rotation(App.Vector(1,0,0),-90),'Right':App.Rotation(App.Vector(1,1,1),-120)}
    if view_name not in rotations:raise ValueError('Unknown orthographic view')
    result=shape.copy()
    result.Placement=App.Placement(App.Vector(),rotations[view_name]).multiply(result.Placement)
    return result


def export_scaled(doc,target,denominator=1,direction=None,view_name=None):
    if view_name is not None:
        if view_name not in VIEWS:raise ValueError('Select Top, Front or Right orthographic view')
        direction=App.Vector(VIEWS[view_name][1])
    denominator=float(denominator)
    if not math.isfinite(denominator) or denominator<=0:raise ValueError('Scale denominator must be positive')
    from .documents import model_objects,world_shape
    from .validation import valid_document
    valid_document(doc);objects=model_objects(doc)
    if not objects:raise ValueError('No model geometry to export')
    for obj in doc.Objects:
        if hasattr(obj,'Validation') and hasattr(obj,'Shape') and obj.Shape.isNull():raise ValueError('Invalid model: '+obj.Label)
    shape=Part.makeCompound([world_shape(obj) for obj in objects]);direction=direction or App.Vector(0,0,1)
    if not all(math.isfinite(v) for v in (direction.x,direction.y,direction.z)) or direction.Length<1e-9:raise ValueError('Projection direction must be finite and nonzero')
    projection_direction=direction
    if view_name:
        shape=_page_shape(shape,view_name)
        projection_direction=App.Vector(0,0,1)
    parts=TechDraw.projectEx(shape,projection_direction);bounds=App.BoundBox()
    for part in parts:
        if not part.isNull():bounds.add(part.BoundBox)
    if not bounds.isValid() or min(bounds.XLength,bounds.YLength)<=1e-8:raise ValueError('Degenerate projection')
    # A3 landscape, no margins: 390 x 220 mm reserved drawing area.
    if bounds.XLength/denominator>390 or bounds.YLength/denominator>220:raise ValueError('View exceeds A3 drawing area at this scale; choose a larger denominator')
    content=TechDraw.projectToSVG(shape,projection_direction)
    content=content.replace('stroke-width="1.0"','stroke-width="'+str(0.25*denominator)+'"')
    svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s %s %s %s">%s</svg>'%(bounds.XMin,-bounds.YMax,bounds.XLength,bounds.YLength,content)
    fd,temp=tempfile.mkstemp(suffix='.pdf',dir=os.path.dirname(os.path.abspath(target)));os.close(fd)
    try:
        writer=QtGui.QPdfWriter(temp);writer.setResolution(254)
        writer.setPageSize(QtGui.QPageSize(QtGui.QPageSize.A3));writer.setPageOrientation(QtGui.QPageLayout.Landscape)
        writer.setPageMargins(QtCore.QMarginsF(0,0,0,0),QtGui.QPageLayout.Millimeter)
        painter=QtGui.QPainter(writer)
        try:
            painter.fillRect(0,0,writer.width(),writer.height(),QtGui.QColor('white'))
            painter.setPen(QtGui.QPen(QtGui.QColor('#182b40'),2));painter.drawRect(100,100,4000,2770)
            painter.setFont(QtGui.QFont('DejaVu Sans',14))
            painter.drawText(QtCore.QRectF(150,100,3900,180),int(QtCore.Qt.AlignRight),'إسقاط هندسي '+(VIEWS[view_name][0] if view_name else '')+' | مقياس 1:'+format(denominator,'g'))
            renderer=QtSvg.QSvgRenderer(QtCore.QByteArray(svg.encode()))
            if not renderer.isValid():raise ValueError('Projection renderer failed')
            # 254 DPI = 10 device units per physical millimetre.
            w=bounds.XLength/denominator*10;h=bounds.YLength/denominator*10
            renderer.render(painter,QtCore.QRectF(2100-w/2,1450-h/2,w,h))
            painter.setFont(QtGui.QFont('DejaVu Sans',9))
            painter.drawText(QtCore.QRectF(150,2620,3900,90),int(QtCore.Qt.AlignRight),'تحقق من الطباعة ١٠٠٪ دون ملاءمة. رسم تطوير هندسي، لا يمثل اعتماد تصميم أو مطابقة معيار.')
            painter.drawLine(200,2770,1200,2770)
            painter.drawLine(200,2740,200,2800);painter.drawLine(1200,2740,1200,2800)
            painter.drawText(QtCore.QRectF(200,2800,1800,60),int(QtCore.Qt.AlignLeft),'معايرة ورقية ١٠٠ مم | A3 420 x 297 mm')
        finally:painter.end()
        with open(path_for_python(temp),'rb') as f:
            if f.read(5)!=b'%PDF-':raise IOError('Invalid PDF')
        os.replace(path_for_python(temp),path_for_python(target))
    finally:
        if os.path.exists(path_for_python(temp)):os.remove(path_for_python(temp))
    return {'view':view_name or 'Custom direction','projection_direction':[direction.x,direction.y,direction.z],'scale_denominator':denominator,'projected_model_mm':[bounds.XLength,bounds.YLength],'paper_geometry_mm':[bounds.XLength/denominator,bounds.YLength/denominator],'paper_calibration_mm':100,'paper_size_mm':[420,297]}
