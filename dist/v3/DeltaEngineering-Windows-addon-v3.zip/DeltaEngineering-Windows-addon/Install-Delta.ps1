param([string]$Target = "$env:LOCALAPPDATA\Programs\DeltaEngineering", [switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$base = 'https://github.com/FreeCAD/FreeCAD/releases/download/1.1.4'
$name = 'FreeCAD_1.1.4-Windows-x86_64-py311-installer.exe'
$tmp = Join-Path $env:TEMP $name
Write-Host "Downloading official FreeCAD 1.1.4 (about 520 MB)..."
Invoke-WebRequest "$base/$name" -OutFile $tmp -UseBasicParsing
$want = (([string](Invoke-RestMethod "$base/$name-SHA256.txt")) -split '\s+')[0]
$got = (Get-FileHash $tmp -Algorithm SHA256).Hash
if ($got -ine $want) { throw "SHA256 mismatch: expected $want got $got" }
Write-Host "SHA256 verified. Installing to $Target ..."
$p = Start-Process $tmp -ArgumentList '/S', "/D=$Target" -Wait -PassThru
if ($p.ExitCode -ne 0) { throw "FreeCAD installer exit code $($p.ExitCode)" }
$exe = Get-ChildItem $Target -Recurse -Filter FreeCAD.exe -ErrorAction SilentlyContinue | Where-Object { $_.Directory.Name -eq 'bin' } | Select-Object -First 1
if (-not $exe) { throw "FreeCAD.exe not found after install" }
$Root = $exe.Directory.Parent.FullName
Write-Host "FreeCAD installed at $Root"
New-Item -ItemType Directory -Force "$Root\Mod" | Out-Null
Copy-Item "$PSScriptRoot\Mod\DeltaEngineering" "$Root\Mod\DeltaEngineering" -Recurse -Force
Copy-Item "$PSScriptRoot\LaunchDelta.FCMacro" "$Root\LaunchDelta.FCMacro" -Force
if (-not $NoShortcut) {
  $dir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
  $s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $dir 'Delta Engineering.lnk'))
  $s.TargetPath = $exe.FullName
  $s.Arguments = "`"$Root\LaunchDelta.FCMacro`""
  $s.WorkingDirectory = $Root
  $s.Save()
}
Write-Host "Done. Start 'Delta Engineering' from the Start Menu."
