#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Run GUI acceptance with explicit completion, fresh-error and log checks."""
import argparse,json,os,subprocess,tempfile,time
from pathlib import Path
from run_regression import ROOT,relocated_source


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--runtime',required=True);parser.add_argument('--suite',action='append');parser.add_argument('--timeout',type=int,default=20);parser.add_argument('--report',default='gui-acceptance.json',help='Report basename under evidence; use a distinct name for subsets');args=parser.parse_args()
    if Path(args.report).name!=args.report or not args.report.endswith('.json'):parser.error('Report must be a JSON basename')
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True);results=[]
    suites=args.suite or [p.name for p in sorted(ROOT.glob('*test.FCMacro'))]
    with tempfile.TemporaryDirectory(prefix='delta-gui-') as temp:
        for suite in suites:
            original=ROOT/suite
            if original.parent!=ROOT or not original.is_file():raise ValueError('Unknown root macro')
            marker=Path(temp)/(suite+'.success');macro=Path(temp)/suite
            before={p.name:(p.stat().st_mtime_ns,p.stat().st_size) for p in evidence.glob('*error.txt')}
            prelude='''import os,sys,traceback
_delta_original_exit=os._exit
def _delta_fail(kind,value,tb):
    os.write(2,(''.join(traceback.format_exception(kind,value,tb))).encode('utf-8','replace'))
    sys.stderr.flush()
    _delta_original_exit(1)
sys.excepthook=_delta_fail
def _delta_exit(code):
    if code==0:
        with open(MARKER,'w') as marker:marker.write('GUI_ACCEPTANCE_COMPLETED')
    sys.stdout.flush();sys.stderr.flush()
    _delta_original_exit(code)
os._exit=_delta_exit
'''.replace('MARKER',repr(str(marker)))
            source=relocated_source(original,ROOT)
            macro.write_text(prelude+'\n__file__='+repr(str(original))+'\n'+source,encoding='utf-8')
            start=time.monotonic();env=os.environ.copy();env['LANG']='C.UTF-8';env['LC_ALL']='C.UTF-8'
            try:
                proc=subprocess.run(['xvfb-run','-a','-s','-screen 0 1560x1050x24',str(Path(args.runtime).resolve()),str(macro)],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',timeout=args.timeout)
                output=proc.stdout;code=proc.returncode
            except subprocess.TimeoutExpired as exc:
                output=exc.stdout or b'';output=output.decode('utf-8','replace') if isinstance(output,bytes) else output;code=-1
            fresh=[p.name for p in evidence.glob('*error.txt') if before.get(p.name)!=(p.stat().st_mtime_ns,p.stat().st_size)]
            bad=any(text in output for text in ('Traceback (most recent call last)','Exception while processing file','AssertionError'))
            passed=code==0 and marker.is_file() and not fresh and not bad
            results.append({'suite':suite,'passed':passed,'completion_marker':marker.is_file(),'returncode':code,'fresh_error_files':fresh,'exception_diagnostic':bad,'seconds':round(time.monotonic()-start,3)})
            (evidence/'gui-acceptance-progress.json').write_text(json.dumps({'results':results},indent=2),encoding='utf-8')
            (evidence/(suite+'.gui.log')).write_text(output,encoding='utf-8');print(('PASS ' if passed else 'FAIL ')+suite,flush=True)
    report={'scope':'Linux GUI automation acceptance, not human usability, Windows or engineering approval','all_passed':all(row['passed'] for row in results),'results':results}
    (evidence/args.report).write_text(json.dumps(report,indent=2),encoding='utf-8');return 0 if report['all_passed'] else 1

if __name__=='__main__':raise SystemExit(main())
