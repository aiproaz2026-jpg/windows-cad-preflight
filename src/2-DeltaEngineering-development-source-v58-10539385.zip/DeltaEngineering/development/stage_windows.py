#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Assemble local-only Windows development candidate. Not a release approval."""
import argparse,hashlib,json,shutil,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime',required=True);p.add_argument('--runtime-archive',required=True);p.add_argument('--expected-sha256',required=True);p.add_argument('--output',required=True);args=p.parse_args()
 runtime=Path(args.runtime).resolve();archive=Path(args.runtime_archive).resolve();output=Path(args.output).resolve()
 if output.exists():raise ValueError('Output must not already exist')
 if sha(archive)!=args.expected_sha256.lower():raise ValueError('Runtime archive checksum mismatch')
 import inventory_runtime
 check=inventory_runtime.inventory(runtime)
 if not check['windows_x64_entrypoint_present']:raise ValueError('Expected actual Windows x64 runtime')
 for name in ('Ext/PySide','Mod','doc/LICENSE.html','doc/ThirdPartyLibraries.html','packages.txt'):
  if not (runtime/name).exists():raise ValueError('Required runtime material missing: '+name)
 output.mkdir(parents=True)
 # Independent copies, not hard links: no later source edits affect staged bytes.
 shutil.copytree(runtime,output/'runtime')
 module=output/'Mod/DeltaEngineering';module.mkdir(parents=True)
 for name in ('Init.py','InitGui.py'):shutil.copy2(ROOT/name,module/name)
 shutil.copytree(ROOT/'DeltaEngineering',module/'DeltaEngineering',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in ('LaunchDelta.cmd','LaunchDelta.FCMacro'):shutil.copy2(ROOT/name,output/name)
 licenses=output/'licenses';licenses.mkdir();shutil.copy2(ROOT/'COPYING',licenses/'DeltaEngineering-GPL-3.0.txt')
 (output/'DEVELOPMENT-NOT-RELEASED.txt').write_text('Development candidate only. Not Windows-tested. Full dependency redistribution/source obligations remain unreviewed. Do not distribute or use for engineering execution. Uses FreeCAD, available free of charge under LGPL2+. Original Delta module source is included. No claim of affiliation or approval by FreeCAD.\n')
 release=output/'release';release.mkdir();(release/'runtime-inventory.json').write_text(json.dumps(check,indent=2))
 manifest={f.relative_to(output).as_posix():sha(f) for f in sorted(output.rglob('*')) if f.is_file()}
 (release/'manifest.sha256.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps({'stage':str(output),'files':len(manifest),'runtime_archive_sha256':sha(archive),'release_ready':False,'windows_executed':False}))

if __name__=='__main__':main()
