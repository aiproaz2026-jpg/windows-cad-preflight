#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Local developer checks. Requires an existing FreeCAD command-line runtime."""
import argparse,ast,io,json,os,subprocess,sys,tempfile,time,tokenize
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SUITES={
 'acceptance.py':'PASSED 14 TESTS',
 'domain_acceptance.py':'DOMAIN_11_PASS',
 'drafting_acceptance.py':'DRAFTING_PASS',
 'electrical_acceptance.py':'ELECTRICAL_EDIT_PASS',
 'mechanical_acceptance.py':'MECHANICAL_7_PASS',
 'precision_acceptance.py':'PRECISION_PASS',
 'project_acceptance.py':'INTEGRATED_PROJECT_PASS',
 'routing_acceptance.py':'ROUTING_PASS',
 'port_connections.py':'PORT_CONNECTIONS_PASS',
 'symbols_acceptance.py':'SYMBOLS_PASS',
 'connectivity_acceptance.py':'CONNECTIVITY_PASS',
 'world_shape.py':'WORLD_SHAPE_PASS',
 'world_step.py':'WORLD_STEP_PASS',
 'frame_guards.py':'FRAME_GUARDS_PASS',
 'project_check.py':'PROJECT_CHECK_PASS',
 'coordinate_text.py':'COORDINATE_TEXT_PASS',
 'arabic_numeric.py':'ARABIC_NUMERIC_PASS',
 'ring_edit.py':'RING_EDIT_PASS',
 'projection_stroke.py':'PROJECTION_STROKE_PASS',
 'patterns.py':'PATTERNS_PASS',
 'revolutions.py':'REVOLUTIONS_PASS',
 'measurement.py':'MEASUREMENT_PASS',
 'terminal_layout.py':'TERMINAL_LAYOUT_PASS',
 'fillets.py':'FILLETS_PASS',
 'arabic_presentation.py':'ARABIC_PRESENTATION_PASS',
}


def relocated_source(path,root):
    """Rewrite only literal legacy fixture paths, never raw arbitrary shell text."""
    source=path.read_text(encoding='utf-8');tokens=[]
    for token in tokenize.generate_tokens(io.StringIO(source).readline):
        if token.type==tokenize.STRING:
            try:value=ast.literal_eval(token.string)
            except (SyntaxError,ValueError):value=None
            if isinstance(value,str) and '/tmp/cad-development' in value:
                token=token._replace(string=repr(value.replace('/tmp/cad-development',root.as_posix())))
        tokens.append(token)
    return tokenize.untokenize(tokens)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime',required=True,help='Path to FreeCADCmd, or AppRun with --apprun')
    parser.add_argument('--apprun',action='store_true',help='Invoke runtime with freecadcmd argument')
    parser.add_argument('--suite',action='append',choices=list(SUITES),help='Repeat to run a subset')
    parser.add_argument('--timeout',type=int,default=90,help='Per-suite seconds')
    args=parser.parse_args()
    runtime=Path(args.runtime).resolve()
    if not runtime.is_file():parser.error('The supplied runtime file does not exist')
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True)
    results=[]
    env=os.environ.copy();env['DELTA_DEV_ROOT']=str(ROOT);env['PYTHONPATH']=str(ROOT)+os.pathsep+env.get('PYTHONPATH','')
    # Scripts can fail while FreeCADCmd exits zero. Require their success marker,
    # fresh execution and absence of exception diagnostics as independent checks.
    with tempfile.TemporaryDirectory(prefix='delta-tests-') as temp:
        for name in args.suite or SUITES:
            original=ROOT/'tests'/name;run=Path(temp)/name
            body=relocated_source(original,ROOT)
            run.write_text('import sys\nsys.path.insert(0,'+repr(str(ROOT))+')\n__file__='+repr(str(original))+'\n'+body,encoding='utf-8')
            command=[str(runtime)]+(['freecadcmd'] if args.apprun else [])+[str(run)]
            start=time.monotonic()
            try:
                proc=subprocess.run(command,cwd=ROOT,env=env,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=args.timeout)
                output=proc.stdout
                passed=proc.returncode==0 and SUITES[name] in output and not any(s in output for s in ('Exception while processing file','Traceback (most recent call last)'))
                reason=None if passed else 'Missing success marker, nonzero exit, or exception diagnostic'
            except subprocess.TimeoutExpired as exc:
                output=(exc.stdout or b'');output=output.decode('utf-8','replace') if isinstance(output,bytes) else output
                passed=False;reason='Suite timed out'
            (evidence/(name+'.developer.log')).write_text(output,encoding='utf-8')
            results.append({'suite':name,'passed':passed,'seconds':round(time.monotonic()-start,3),'reason':reason})
            print(('PASS ' if passed else 'FAIL ')+name,flush=True)
    report={'scope':'Local developer regression only, not Windows release, UI or engineering certification','all_passed':all(row['passed'] for row in results),'results':results}
    (evidence/'developer-regression.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return 0 if report['all_passed'] else 1

if __name__=='__main__':raise SystemExit(main())
