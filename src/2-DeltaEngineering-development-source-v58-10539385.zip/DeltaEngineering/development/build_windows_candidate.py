#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Build an explicitly untested local setup candidate from an already assembled stage."""
import argparse,hashlib,json,os,subprocess,tempfile,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent


def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',required=True);p.add_argument('--compiler',required=True);p.add_argument('--nsis-data',required=True);p.add_argument('--output',required=True);p.add_argument('--report',required=True);args=p.parse_args()
 stage=Path(args.stage).resolve();output=Path(args.output).resolve()
 if output.exists():raise ValueError('Refuse to overwrite an existing candidate')
 if not (stage/'DEVELOPMENT-NOT-RELEASED.txt').is_file():raise ValueError('Development-only marker missing')
 # Uninstall deletes listed payload files only, never recursively removes user files.
 files=sorted(p for p in stage.rglob('*') if p.is_file())
 (stage/'release/installed-files.txt').write_text('\r\n'.join(p.relative_to(stage).as_posix().replace('/','\\') for p in files)+'\r\nrelease\\installed-files.txt\r\n',encoding='utf-8')
 manifest={p.relative_to(stage).as_posix():sha(p) for p in stage.rglob('*') if p.is_file() and p.name!='manifest.sha256.json'}
 (stage/'release/manifest.sha256.json').write_text(json.dumps(manifest,indent=2))
 with tempfile.TemporaryDirectory(prefix='delta-setup-build-') as temp:
  folder=Path(temp);payload=folder/'payload.zip'
  with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
   for path in sorted(stage.rglob('*')):
    if path.is_file():archive.write(path,path.relative_to(stage))
  digest=sha(payload);chunks=folder/'chunks';chunks.mkdir()
  with payload.open('rb') as f:
   index=0
   while True:
    block=f.read(32*1024*1024)
    if not block:break
    (chunks/('payload.'+format(index,'03d'))).write_bytes(block);index+=1
  (chunks/'payload.sha256').write_text(digest)
  command=[str(Path(args.compiler).resolve()),'-WX','-V3','-DSTAGE='+str(stage),'-DCHUNKS='+str(chunks),'-DSCRIPTDIR='+str(HERE),'-DOUTPUT_EXE='+str(output),str(HERE/'windows-development-chunks.nsi')]
  env=os.environ.copy();env['NSISDIR']=str(Path(args.nsis_data).resolve())
  proc=subprocess.run(command,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  Path(args.report+'.log').write_text(proc.stdout)
  if proc.returncode!=0 or not output.is_file():raise RuntimeError('Setup compiler failed; see build log')
  result={'scope':'Local cross-compiled candidate. Not Windows-executed, visually inspected, license-cleared or release-ready.','installer_bytes':output.stat().st_size,'installer_sha256':sha(output),'payload_sha256':digest,'internal_chunks':index,'windows_executed':False,'release_ready':False}
  Path(args.report).write_text(json.dumps(result,indent=2));print(json.dumps(result))

if __name__=='__main__':main()
