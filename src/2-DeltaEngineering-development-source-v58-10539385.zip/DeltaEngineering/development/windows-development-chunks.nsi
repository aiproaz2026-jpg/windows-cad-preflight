; SPDX-License-Identifier: GPL-3.0-or-later
; Local development installer candidate only. Requires Windows acceptance.
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "WinVer.nsh"
Name "Delta Engineering Development Candidate"
OutFile "${OUTPUT_EXE}"
InstallDir "$LOCALAPPDATA\DeltaEngineering-Development"
RequestExecutionLevel user
SetCompressor zlib
SetCompress off
SetDatablockOptimize off
CRCCheck force
!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "${STAGE}/DEVELOPMENT-NOT-RELEASED.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "Arabic"
Function .onInit
 ${IfNot} ${RunningX64}
 MessageBox MB_ICONSTOP "This development candidate requires x64 Windows."
 Abort
 ${EndIf}
 ${IfNot} ${AtLeastWin10}
 MessageBox MB_ICONSTOP "This runtime requires Windows 10 or later."
 Abort
 ${EndIf}
FunctionEnd
Function .onVerifyInstDir
 IfFileExists "$INSTDIR\*.*" 0 empty
 Abort
 empty:
FunctionEnd
Section "Development candidate"
 SetOutPath "$INSTDIR"
 InitPluginsDir
 SetOutPath "$PLUGINSDIR"
 File "${CHUNKS}/payload.*"
 File /oname=extract-payload.ps1 "${SCRIPTDIR}/extract-payload.ps1"
 ExecWait '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\extract-payload.ps1" -Destination "$INSTDIR"' $0
 StrCmp $0 0 extracted
 MessageBox MB_ICONSTOP "Development payload extraction failed. No shortcut was created."
 Abort
 extracted:
 SetOutPath "$INSTDIR"
 WriteUninstaller "$INSTDIR\Uninstall.exe"
 SetShellVarContext current
 CreateDirectory "$SMPROGRAMS\DeltaEngineering Development"
 CreateShortcut "$SMPROGRAMS\DeltaEngineering Development\Delta Engineering.lnk" "$INSTDIR\LaunchDelta.cmd"
 CreateShortcut "$SMPROGRAMS\DeltaEngineering Development\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DeltaEngineering-Development" "DisplayName" "Delta Engineering Development Candidate (UNTESTED)"
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DeltaEngineering-Development" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
SectionEnd
Section "Uninstall"
 SetShellVarContext current
 InitPluginsDir
 SetOutPath "$PLUGINSDIR"
 File /oname=remove-payload.ps1 "${SCRIPTDIR}/remove-payload.ps1"
 ExecWait '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\remove-payload.ps1" -Destination "$INSTDIR"' $0
 StrCmp $0 0 removed
 MessageBox MB_ICONSTOP "Development uninstall could not finish. User files have not been recursively removed."
 Abort
 removed:
 SetOutPath "$TEMP"
 Delete "$INSTDIR\Uninstall.exe"
 Delete "$SMPROGRAMS\DeltaEngineering Development\Delta Engineering.lnk"
 Delete "$SMPROGRAMS\DeltaEngineering Development\Uninstall.lnk"
 RMDir "$SMPROGRAMS\DeltaEngineering Development"
 DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DeltaEngineering-Development"
 RMDir "$INSTDIR"
SectionEnd
