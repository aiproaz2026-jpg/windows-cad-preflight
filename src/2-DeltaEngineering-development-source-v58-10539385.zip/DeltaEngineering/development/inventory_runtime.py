#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only local runtime inventory. Never downloads, installs or certifies licenses."""
import argparse,hashlib,json,struct
from pathlib import Path


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda:file.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def pe_machine(path):
    try:
        with path.open('rb') as file:
            if file.read(2)!=b'MZ':return None
            file.seek(60);offset=struct.unpack('<I',file.read(4))[0]
            if offset>path.stat().st_size-6:return None
            file.seek(offset)
            if file.read(4)!=b'PE\0\0':return None
            return struct.unpack('<H',file.read(2))[0]
    except (OSError,struct.error):return None


def inventory(root):
    root=root.resolve();records=[];licenses=[];packages=[]
    if not root.is_dir():raise ValueError('Runtime directory does not exist')
    for path in sorted(root.rglob('*')):
        if path.is_symlink():continue
        if not path.is_file():continue
        rel=path.relative_to(root).as_posix();lower=rel.lower();name=path.name.lower()
        if name.endswith(('.exe','.dll','.pyd','.so','.dylib')) or '.so.' in name or name in ('apprun','packages.txt','freecad','freecadcmd'):
            row={'path':rel,'bytes':path.stat().st_size,'sha256':digest(path)}
            if name.endswith(('.exe','.dll','.pyd')):row['pe_machine']=pe_machine(path)
            records.append(row)
        if any(token in name for token in ('license','licence','copying','copyright')) or '/licenses/' in lower:
            licenses.append({'path':rel,'bytes':path.stat().st_size,'sha256':digest(path)})
        if name=='packages.txt':packages=path.read_text(encoding='utf-8',errors='replace').splitlines()
    candidates=[r for r in records if r['path'].lower()=='bin/freecad.exe']
    x64=bool(candidates and candidates[0]['pe_machine']==0x8664)
    return {'scope':'Local static inventory only. File presence is not redistribution permission or Windows execution evidence.',
            'runtime_label':root.name,'windows_x64_entrypoint_present':x64,'binary_records':records,
            'license_file_records':licenses,'package_listing':packages,
            'release_ready':False,'remaining_gates':[
            'Obtain and independently verify official Windows x86_64 runtime archive and checksum',
            'Inventory actual Windows bundled binaries and all license notices; Linux package inventory is not a substitute',
            'Review redistribution obligations and corresponding source availability for every bundled component',
            'Build one application layout and locally compiled installer with explicit license/source material',
            'Test clean Windows installation, launch, Arabic/spaced paths, save/reopen, exports, uninstall, and medium-machine behavior',
            'Record actual Windows tests and keep release blocked until all required gates pass']}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--runtime',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
    result=inventory(Path(args.runtime));target=Path(args.output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(target),'windows_x64_entrypoint_present':result['windows_x64_entrypoint_present'],'binary_records':len(result['binary_records']),'license_file_records':len(result['license_file_records']),'release_ready':False}))

if __name__=='__main__':main()
