#!/usr/bin/env python3
"""Compare native files after removing only Authenticode table and PE checksum."""
from pathlib import Path
import json,hashlib,zipfile,tarfile,io
import zstandard,pefile
PROJECT=Path('/tmp/cad-development');BASE=Path('/tmp/cad-windows-inputs/dependency-license-inputs');RUNTIME=Path('/tmp/cad-windows-inputs/windows-runtime/FreeCAD_1.1.4-Windows-x86_64-py311')
report=json.loads((PROJECT/'evidence/windows-priority-file-provenance.json').read_text())

def normalized(data):
 pe=pefile.PE(data=data,fast_load=True)
 checksum=pe.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum')
 security=pe.OPTIONAL_HEADER.DATA_DIRECTORY[4];offset=security.get_file_offset();start=security.VirtualAddress;size=security.Size
 content=bytearray(data);content[checksum:checksum+4]=b'\0'*4;content[offset:offset+8]=b'\0'*8
 if start and size:
  if start+size>len(content):raise ValueError('Certificate table outside file')
  del content[start:start+size]
 return hashlib.sha256(content).hexdigest()

out=[]
for row in report['packages']:
 wanted={f['package_path']:f for f in row['files'] if f['status']=='same-name-different-bytes'}
 if not wanted:continue
 archive=next(iter(BASE.glob(row['package']+'-*.conda')),None) or next(iter(BASE.glob(row['package']+'-*.tar.bz2')),None)
 if not archive:continue
 z=None;reader=None
 try:
  if archive.suffix=='.conda':
   z=zipfile.ZipFile(archive);member=z.open(next(n for n in z.namelist() if n.startswith('pkg-')));reader=zstandard.ZstdDecompressor().stream_reader(member);tar=tarfile.open(fileobj=reader,mode='r|')
  else:tar=tarfile.open(archive,mode='r|bz2')
  for member in tar:
   if member.name not in wanted or not member.isfile():continue
   f=wanted[member.name];data=tar.extractfile(member).read()
   try:
    expected=normalized(data);matches=[p for p in f['runtime_same_filename'] if normalized((RUNTIME/p).read_bytes())==expected]
    out.append({'package':row['package'],'package_path':member.name,'normalized_match_runtime_paths':matches,'status':'differs-only-in-certificate-table-and-checksum' if matches else 'unresolved-byte-difference'})
   except Exception as e:out.append({'package':row['package'],'package_path':member.name,'error':str(e)})
  tar.close()
 finally:
  if reader:reader.close()
  if z:z.close()
result={'scope':'Static normalized-byte comparison, not signature authentication. Removes only PE checksum, security-directory pointer/length and certificate-table bytes. Equal remaining bytes do not validate signer or license compliance.','files':out,'total':len(out),'normalized_matches':sum(bool(x.get('normalized_match_runtime_paths')) for x in out),'license_compliance_complete':False}
(PROJECT/'evidence/windows-pe-signature-normalized-provenance.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='files'}))
