param([Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference = 'Stop'
try {
    $archive = Join-Path $PSScriptRoot 'payload.zip'
    $outStream = [IO.File]::Create($archive)
    try {
        Get-ChildItem -LiteralPath $PSScriptRoot -Filter 'payload.*' | Where-Object { $_.Name -match '^payload\.[0-9]{3}$' } | Sort-Object Name | ForEach-Object {
            $sourceStream = [IO.File]::OpenRead($_.FullName)
            try { $sourceStream.CopyTo($outStream) } finally { $sourceStream.Dispose() }
        }
    } finally { $outStream.Dispose() }
    $expected = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'payload.sha256') -Raw).Trim()
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $expected) { throw 'Payload checksum mismatch' }
    if ((Test-Path -LiteralPath $Destination) -and (Get-ChildItem -LiteralPath $Destination -Force)) { throw 'Destination must be empty' }
    Expand-Archive -LiteralPath $archive -DestinationPath $Destination
    $manifest = Get-Content -LiteralPath (Join-Path $Destination 'release\manifest.sha256.json') -Raw | ConvertFrom-Json
    $root = [IO.Path]::GetFullPath($Destination).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    foreach ($entry in $manifest.PSObject.Properties) {
        $full = [IO.Path]::GetFullPath((Join-Path $root $entry.Name))
        if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe manifest path' }
        if ((Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash -ne $entry.Value) { throw 'Installed file checksum mismatch' }
    }
    exit 0
} catch {
    Write-Error $_
    exit 1
}
