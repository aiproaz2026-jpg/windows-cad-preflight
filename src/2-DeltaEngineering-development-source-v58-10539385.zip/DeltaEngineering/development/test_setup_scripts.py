#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Small local PowerShell fixture, never native Windows acceptance."""
import argparse,json,hashlib,tempfile,zipfile,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--powershell',required=True);p.add_argument('--report',required=True);args=p.parse_args()
 results={}
 with tempfile.TemporaryDirectory(prefix='delta-setup-test-') as temp:
  root=Path(temp);scripts=root/'scripts';scripts.mkdir();payload=root/'payload';(payload/'release').mkdir(parents=True)
  for name in ('extract-payload.ps1','remove-payload.ps1'):shutil.copy2(HERE/name,scripts/name)
  for name in ('unchanged.txt','modified.txt'):(payload/name).write_text('original')
  manifest={p.relative_to(payload).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in payload.rglob('*') if p.is_file()};(payload/'release/manifest.sha256.json').write_text(json.dumps(manifest))
  with zipfile.ZipFile(root/'payload.zip','w') as z:
   for f in payload.rglob('*'):
    if f.is_file():z.write(f,f.relative_to(payload))
  data=(root/'payload.zip').read_bytes();(scripts/'payload.000').write_bytes(data[:100]);(scripts/'payload.001').write_bytes(data[100:]);(scripts/'payload.sha256').write_text(hashlib.sha256(data).hexdigest())
  dest=root/'installed'
  def run(script):return subprocess.run([args.powershell,'-NoProfile','-File',str(scripts/script),'-Destination',str(dest)],capture_output=True,text=True)
  proc=run('extract-payload.ps1');assert proc.returncode==0,proc.stderr;assert (dest/'unchanged.txt').read_text()=='original';results['chunk_reassembly_and_hash_checked_extraction']=True
  proc=run('extract-payload.ps1');assert proc.returncode!=0;results['nonempty_destination_refused']=True
  (dest/'modified.txt').write_text('user edit');(dest/'user-project.FCStd').write_text('preserve');proc=run('remove-payload.ps1');assert proc.returncode==0,proc.stderr
  assert not (dest/'unchanged.txt').exists() and (dest/'modified.txt').read_text()=='user edit' and (dest/'user-project.FCStd').read_text()=='preserve';results['modified_and_unlisted_files_survive_uninstall']=True
  shutil.rmtree(dest);(scripts/'payload.sha256').write_text('0'*64);proc=run('extract-payload.ps1');assert proc.returncode!=0 and not dest.exists();results['corrupt_payload_rejected_before_destination_creation']=True
  dest.mkdir();(dest/'release').mkdir();outside=root/'outside.txt';outside.write_text('preserve');(dest/'release/manifest.sha256.json').write_text(json.dumps({'../../outside.txt':hashlib.sha256(outside.read_bytes()).hexdigest()}));proc=run('remove-payload.ps1');assert proc.returncode!=0 and outside.read_text()=='preserve';results['uninstall_path_escape_refused']=True
 report={'scope':'Tiny fixtures run in supplied PowerShell on local Linux. Not Windows PowerShell 5.1, NSIS, UI, full-payload or native Windows acceptance.','all_passed':True,'results':results};Path(args.report).write_text(json.dumps(report,indent=2));print(json.dumps(report))

if __name__=='__main__':main()
