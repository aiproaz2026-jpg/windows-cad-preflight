param([Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($Destination).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$manifestPath = Join-Path $root 'release\manifest.sha256.json'
if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'Installed manifest missing' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
# Preflight every path before deleting anything. Modified/unlisted files survive.
$paths = @()
foreach ($entry in $manifest.PSObject.Properties) {
    $full = [IO.Path]::GetFullPath((Join-Path $root $entry.Name))
    if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe uninstall path' }
    $paths += [PSCustomObject]@{ Full = $full; Hash = $entry.Value }
}
foreach ($entry in $paths) {
    if ((Test-Path -LiteralPath $entry.Full -PathType Leaf) -and ((Get-FileHash -LiteralPath $entry.Full -Algorithm SHA256).Hash -eq $entry.Hash)) {
        Remove-Item -LiteralPath $entry.Full -Force
    }
}
Remove-Item -LiteralPath $manifestPath
# No recursive directory removal. User-created or modified files prevent deletion.
Get-ChildItem -LiteralPath $root -Directory -Recurse | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object {
    if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) { Remove-Item -LiteralPath $_.FullName }
}
exit 0
