#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Build a private local development source archive, never a Windows installer."""
import argparse,hashlib,json,shutil,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True);args=parser.parse_args()
    target=Path(args.output).resolve()
    if target.suffix!='.zip':parser.error('Output must be a .zip archive')
    files=set(json.loads((ROOT/'development/release-files.json').read_text(encoding='utf-8')))
    # Always rebuild the staging tree from canonical source, never stale copies.
    stage=ROOT/'package/Mod/DeltaEngineering'
    for f in (ROOT/'DeltaEngineering').rglob('*'):
        if not f.is_file() or '__pycache__' in f.parts:continue
        relative=f.relative_to(ROOT);destination=stage/relative;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,destination);files.add(destination.relative_to(ROOT).as_posix());files.add(relative.as_posix())
    for name in ('Init.py','InitGui.py'):
        shutil.copyfile(ROOT/name,stage/name);files.add((stage/name).relative_to(ROOT).as_posix());files.add(name)
    files.update(('development/build_source.py','development/release-files.json'))
    files.discard('MANIFEST.sha256.json')
    for name in files:
        path=ROOT/name
        if not path.resolve().is_relative_to(ROOT) or not path.is_file():raise ValueError('Missing/unsafe release path: '+name)
        if path.suffix in ('.log','.pyc') or '__pycache__' in path.parts:raise ValueError('Diagnostic/cache forbidden: '+name)
    manifest={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sorted(files)}
    (ROOT/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');files.add('MANIFEST.sha256.json')
    target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(files):archive.write(ROOT/name,'DeltaEngineering/'+name)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip():raise ValueError('Archive CRC verification failed')
        for name,digest in manifest.items():
            if hashlib.sha256(archive.read('DeltaEngineering/'+name)).hexdigest()!=digest:raise ValueError('Manifest verification failed: '+name)
    print(json.dumps({'archive':str(target),'files':len(files),'bytes':target.stat().st_size,'verified':True,'Windows_installer':False}))

if __name__=='__main__':main()
