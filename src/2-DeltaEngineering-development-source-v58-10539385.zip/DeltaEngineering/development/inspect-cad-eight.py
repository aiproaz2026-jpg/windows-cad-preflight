from pathlib import Path
import sys,json,tarfile,zipfile,hashlib
sys.path.insert(0,'/tmp/cad-license-python')
import pefile,zstandard
P=Path('/tmp/cad-development');B=Path('/tmp/cad-windows-inputs/dependency-license-inputs');R=Path('/tmp/cad-windows-inputs/windows-runtime/FreeCAD_1.1.4-Windows-x86_64-py311')
reports=json.loads((P/'evidence/windows-priority-file-provenance.json').read_text()); norm=json.loads((P/'evidence/windows-pe-signature-normalized-provenance.json').read_text());wanted={(x['package'],x['package_path']) for x in norm['files'] if x['status']=='unresolved-byte-difference'};out=[]
for row in reports['packages']:
 entries={f['package_path']:f for f in row['files'] if (row['package'],f['package_path']) in wanted}
 if not entries:continue
 archive=next(iter(B.glob(row['package']+'-*.conda')),None) or next(iter(B.glob(row['package']+'-*.tar.bz2')))
 if archive.suffix=='.conda':
  z=zipfile.ZipFile(archive);reader=zstandard.ZstdDecompressor().stream_reader(z.open(next(n for n in z.namelist() if n.startswith('pkg-'))));t=tarfile.open(fileobj=reader,mode='r|')
 else:t=tarfile.open(archive,mode='r|bz2')
 for m in t:
  if m.name not in entries:continue
  a=t.extractfile(m).read();pa=pefile.PE(data=a);matches=[]
  for rel in entries[m.name]['runtime_same_filename']:
   b=(R/rel).read_bytes();pb=pefile.PE(data=b)
   sect=[]
   for sa,sb in zip(pa.sections,pb.sections):
    da,db=sa.get_data(),sb.get_data();sect.append({'name':sa.Name.decode(errors='replace').rstrip('\0'),'same_name':sa.Name==sb.Name,'same_data':da==db,'package_bytes':len(da),'runtime_bytes':len(db)})
   oa=pa.get_overlay_data_start_offset() or len(a);ob=pb.get_overlay_data_start_offset() or len(b)
   sec_a=pa.OPTIONAL_HEADER.DATA_DIRECTORY[4];sec_b=pb.OPTIONAL_HEADER.DATA_DIRECTORY[4]
   # Keep the whole non-certificate file, but remove only linker-added zero
   # alignment bytes after the original EOF and before a certificate table.
   strip_a=a[:sec_a.VirtualAddress] if sec_a.VirtualAddress else a
   strip_b=b[:sec_b.VirtualAddress] if sec_b.VirtualAddress else b
   padding_equivalent=strip_a.rstrip(b'\0')==strip_b.rstrip(b'\0')
   ah=bytearray(strip_a);bh=bytearray(strip_b)
   for pe,raw in [(pa,ah),(pb,bh)]:
    c=pe.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum');s=pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].get_file_offset();raw[c:c+4]=bytes(4);raw[s:s+8]=bytes(8)
   trim_equivalent=ah.rstrip(b'\0')==bh.rstrip(b'\0')
   matches.append({'runtime_path':rel,'package_bytes':len(a),'runtime_bytes':len(b),'package_overlay_start':oa,'runtime_overlay_start':ob,'package_certificate':[sec_a.VirtualAddress,sec_a.Size],'runtime_certificate':[sec_b.VirtualAddress,sec_b.Size],'same_section_count':len(pa.sections)==len(pb.sections),'sections':sect,'normalized_and_trailing_zero_trim_equal':trim_equivalent,'package_noncertificate_bytes':len(strip_a),'runtime_noncertificate_bytes':len(strip_b),'zero_trim_removed_package_bytes':len(ah)-len(ah.rstrip(b'\0')),'zero_trim_removed_runtime_bytes':len(bh)-len(bh.rstrip(b'\0'))})
  out.append({'package':row['package'],'package_path':m.name,'comparisons':matches})
 t.close()
 if archive.suffix=='.conda':reader.close();z.close()
result={'scope':'Static analysis only. Certificate table, checksum and security directory excluded; trailing zero padding compared separately. No signer authentication or redistribution clearance.','files':out}
(P/'evidence/windows-eight-binary-differences.json').write_text(json.dumps(result,indent=2))
for x in out:
 for c in x['comparisons']:print(x['package'],c['runtime_path'],'section differences',sum(not s['same_data'] for s in c['sections']),'equal after zeros',c['normalized_and_trailing_zero_trim_equal'],'trimmed',c['zero_trim_removed_package_bytes'],c['zero_trim_removed_runtime_bytes'])
