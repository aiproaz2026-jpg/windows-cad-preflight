#!/usr/bin/env python3
"""Static file-level evidence comparison, not a compliance certificate."""
from pathlib import Path
import json,hashlib,collections
BASE=Path('/tmp/cad-windows-inputs/dependency-license-inputs');PROJECT=Path('/tmp/cad-development')
RUNTIME=Path('/tmp/cad-windows-inputs/windows-runtime/FreeCAD_1.1.4-Windows-x86_64-py311')
records=json.loads((PROJECT/'evidence/windows-runtime-inventory.json').read_text())['binary_records']
by_name=collections.defaultdict(list)
for row in records:by_name[Path(row['path']).name.lower()].append(row)
out=[]
for package in sorted(p for p in BASE.iterdir() if p.is_dir()):
 path=package/'info/paths.json'
 if not path.exists():continue
 rows=[]
 for entry in json.loads(path.read_text())['paths']:
  rel=entry['_path'];name=Path(rel).name.lower()
  if not name.endswith(('.dll','.exe','.pyd')):continue
  matches=by_name[name];exact=[m['path'] for m in matches if m['sha256']==entry.get('sha256')]
  rows.append({'package_path':rel,'package_sha256':entry.get('sha256'),'runtime_same_filename':[m['path'] for m in matches],'byte_identical_runtime_paths':exact,'status':'byte-identical' if exact else 'same-name-different-bytes' if matches else 'not-located'})
 out.append({'package':package.name,'native_file_count':len(rows),'byte_identical_count':sum(r['status']=='byte-identical' for r in rows),'same_name_different_bytes_count':sum(r['status']=='same-name-different-bytes' for r in rows),'not_located_count':sum(r['status']=='not-located' for r in rows),'files':rows})
report={'scope':'Exact package-file hashes compared with runtime hashes by filename. Identical hashes establish those bytes; matching names do not. Different signed runtime bytes may reflect signatures, relocation, patches or different content, unresolved here. Absence can be stripped/relocated input, not a missing dependency conclusion.','packages':out,'license_compliance_complete':False}
(PROJECT/'evidence/windows-priority-file-provenance.json').write_text(json.dumps(report,indent=2))
print('Packages',len(out),'native files',sum(r['native_file_count'] for r in out),'identical',sum(r['byte_identical_count'] for r in out),'same-name-different',sum(r['same_name_different_bytes_count'] for r in out),'not-located',sum(r['not_located_count'] for r in out))
for r in out:
 if r['package'] in ('pyside6','occt','qt6-main','ffmpeg','ucrt','vc14_runtime'):print(r['package'],{k:v for k,v in r.items() if k.endswith('count')})
