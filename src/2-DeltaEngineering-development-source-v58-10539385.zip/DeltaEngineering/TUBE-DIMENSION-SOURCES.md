# Nominal tube dimension provenance

This small preset collection contains factual nominal outside-diameter and wall-thickness pairs for NPS 1 through 4 Schedule 40. It does not contain third-party CAD models, artwork, code, complete tables or manufacturer prose. Geometry and integration code are original GPL-3.0-or-later project code. Manufacturer trademarks identify the source only; no endorsement or product equivalence is implied.

Primary source read on 2026-11-24:
- Wheatland Tube, Schedule 40 Submittal Data Sheet, document marking WFS-121824, dimensions section. https://www.wheatland.com/wp-content/uploads/2017/12/Schedule-40-Submittal-Sheet.pdf

Cross-check read on 2026-11-24:
- Wheatland Tube, SureThread submittal, document marking WST-011724. https://www.wheatland.com/wp-content/uploads/2017/12/SureThread-ASTM-A53-Type-F-Grade-B-Submittal-Sheet.pdf

The primary source's published millimetre columns are used, rather than converting its rounded inch columns. For example, NPS 2 is nominal OD 60.3 mm and wall 3.91 mm; NPS 4 is OD 114.3 mm and wall 6.02 mm. The inch column conversions are not identical at all decimal places because both columns are rounded independently.

Only the nominal dimension pair is inherited. None of the manufacturer's material, pressure, certification, approval, coating, application, tolerances or availability statements apply to this generated geometry. The elbow radius remains user-entered illustrative geometry, not a sourced fitting dimension. The collection does not establish any piping-system compliance or suitability for construction.

Each created/applied object stores the nominal preset ID, source URL, source document marking, source dimensions and scope. A status check detects when manually edited dimensions no longer match the recorded pair. This is dimensional provenance, not a complete parts catalog or approval workflow.
