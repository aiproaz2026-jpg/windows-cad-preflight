@echo off
setlocal
set "ROOT=%~dp0"
if not exist "%ROOT%runtime\bin\FreeCAD.exe" (
 echo Development package only. Bundled Windows runtime is not present.
 exit /b 2
)
"%ROOT%runtime\bin\FreeCAD.exe" -M "%ROOT%Mod\DeltaEngineering" "%ROOT%LaunchDelta.FCMacro" %*
