# Current status

V57 input/provenance review supersedes older source-acquisition counts below. Read WINDOWS-RELEASE-INPUT-REVIEW.md first. The retained V56 candidate is 815,973,444 bytes, SHA256 edaf079f5b28080525a7d2c7d6a746d5c99416e8e3753697bb76913c9316110e. It remains untested and unshared. Historical V53 counts below describe that checkpoint only.

# Windows packaging inputs and remaining gates

## V53 local result, 24 November 2026

The missing Windows runtime and compiler inputs have been obtained locally without an account, paid service, remote build or user-device access. One self-contained Windows setup development candidate has been cross-compiled. It embeds the full Windows runtime and the Delta module, split into internal payload chunks only to avoid a compiler large-file crash. The user would not operate a separate CAD helper application.

This is NOT the requested finished installation-ready product. Windows has not executed this setup or application. The setup's extraction, per-user shortcuts, uninstall, Arabic dialogs, profile behavior and file permissions have no native or pixel acceptance. Redistribution/source fulfillment review is unfinished. The EXE remains local, marked UNTESTED, and is not delivered as usable software.

## Verified runtime input

Official release: https://github.com/FreeCAD/FreeCAD/releases/tag/1.1.4

Current download page: https://www.freecad.org/downloads

The official Windows x86_64 portable archive is 418,088,341 bytes. SHA256 matches the release's separate checksum asset:

`4828741fc91ee37fafcdb97a1abacb18b04ba451ac4372d9ff7a7349b36f4d6d`

The matching official FreeCAD source archive also matches its checksum asset:

`674f2c42dc060b71c8b052c70b04a9a995dde6cb868fe568615d3ff3f2717748`

Runtime extraction contains 35,582 files, 2,307,792,881 bytes before the original module is added. Exact runtime inventory identifies 1,707 EXE/DLL/PYD candidates, including 772 native Python modules, plus 258 notice/license candidates. Package listing contains 235 package rows. Full official runtime notices are retained unchanged. These counts do not prove complete dependency/license coverage.

## Compiler and build

NSIS official features: https://nsis.sourceforge.io/Features

Current source: https://nsis.sourceforge.io/Download

License: https://nsis.sourceforge.io/License

Official documentation permits compiling the installer generator on Linux without Wine. The Ubuntu NSIS 3.08 packages produced a small smoke setup but failed with the large payload. The current NSIS 3.13 source was then downloaded from its official page and its native compiler built locally. Its data/stubs came from the corresponding official setup archive, extracted without running it. Source checksum was recorded locally but not independently authenticated against an upstream checksum, which remains a build-tool provenance caveat. The source-generated compiler version reports a date/CVS string, not the release number; the downloaded archive identity is recorded separately.

The full one-file payload also triggered a native compiler crash. Using 25 internal 32 MiB chunks succeeded. The repeatable builder creates a compressed payload, a checksum, internal chunks and an NSIS executable. Setup reassembles/checks the payload and checks installed-file hashes before creating shortcuts. Uninstall targets only listed payload files and attempts removal of empty directories; it does not recursively delete user projects. These are source-level safety measures, not proven Windows behavior. PowerShell is used through Windows' built-in executable, not a separately installed helper application.

The latest candidate is 815,970,769 bytes. Static extraction reassembled all chunks to the identical payload checksum. See `evidence/windows-candidate-build.json`. No malware, signature-validity, installation or execution conclusion follows from this check. The locally built setup itself is unsigned.

## License/source work actually completed

Official license guidance: https://raw.githubusercontent.com/FreeCAD/FreeCAD-documentation/main/wiki/License.md

The official source's package lock could be exactly matched by package name/version/build to 202 of the runtime's 235 package rows. 33 do not match that lock, including Python, Qt, Gmsh and Graphviz. Do not substitute nearby versions or silently claim this is the runtime's build lock.

Four exact matching package archives were obtained, each hash-matching the official source lock, and their recipe/license metadata extracted: Coin3D, Open CASCADE, PySide6 and CalculiX. Package metadata identifies BSD-3-Clause, LGPL-2.1-only, LGPL-3.0-only and GPL-2.0-or-later respectively. This is metadata evidence, not final legal interpretation. OCCT's exception and each package's exact source/patch/build materials still need review. CalculiX and other unused bundled tools are still shipped because the runtime has not been reduced or revalidated; their obligations cannot be ignored merely because the Delta UI does not invoke them.

Only FreeCAD's own full matching source archive is presently acquired. A link or a recipe alone is not complete corresponding-source fulfillment. All component source/notice obligations remain a release gate, as do Microsoft CRT redistribution terms and resource/trademark review.

## Native Windows verification

Normal Microsoft ISO page: https://www.microsoft.com/en-us/software-download/windows11

Enterprise evaluation: https://www.microsoft.com/en-us/evalcenter/evaluate-windows-11-enterprise

The normal ISO does not establish a free Windows license. Current Enterprise evaluation instructions require registration and a Microsoft account. Neither account creation nor license acceptance outside the existing scope was attempted. Local inspection found no Windows execution environment or KVM device; memory available to this environment is about 1.9 GiB. No suitable no-account native Windows test path is available here. Wine, if later used, would not be native Windows acceptance and cannot settle hardware/driver or minimum-medium-machine behavior.

## Next dependencies

1. Finish exact component/source/notice mapping for the real Windows payload, resolving the 33 lock mismatches and relevant proprietary redistributable terms.
2. Arrange an authorized licensed Windows test environment with adequate memory/graphics and capture installation, launch, Arabic/spaced path, save/restore, geometry/export and uninstall pixels/results.
3. Fix any Windows failures and test performance on a recorded medium Windows computer before claiming the user's install-and-use outcome.

The earlier V52 statement that runtime/compiler were absent described that earlier local state. Those inputs are now present. The execution and full redistribution gates are still open.
