# V57 Windows release input review

24 November 2026. Development evidence only, not installation-ready software.

## Result

The functional application remains the V50 code tested through V51. V57 preserves further exact package, source, recipe and notice evidence. It does not change or rebuild the V56 Windows installer. The installer remains local, unsigned, unexecuted on Windows and not cleared for redistribution.

## File provenance

The priority archive set has 976 native-file records. Of those, 658 have byte-identical matches in the official Windows runtime, 253 have matching filenames but different bytes, and 65 are not located by filename. The latter are mainly standalone tools omitted from the runtime, not evidence that 65 required dependencies are missing. This is not a complete payload-to-package mapping.

For 245 of the 253 differing files, exclusion of only the PE certificate table, security-directory entry and checksum yields identical remaining bytes. The other eight have identical PE section data. After the same exclusions, trimming trailing zero alignment yields identical remaining bytes for all eight. The runtime has two to six additional zero bytes before its certificate table. These static comparisons explain the observed differences without attributing signer identity. They do not verify signatures, authenticity of signing, licensing or safe execution.

Evidence: windows-priority-file-provenance.json, windows-pe-signature-normalized-provenance.json and windows-eight-binary-differences.json under evidence/.

## Source and notice inputs

- 29 recipe-SHA256 source targets were acquired through the legacy recipe review. Four other recipe entries were excluded from that generic path: the defunct OCCT URL, prebuilt Mesa binary, UCRT SDK ISO and VC runtime installer. Separate OCCT tag provenance is retained.
- 12 source inputs from six rendered-recipe packages were acquired with recipe-SHA256 matches.
- Earlier Qt and Python archives have recipe-MD5 matches. This is not equivalent to independent upstream SHA256 authentication.
- 132 shallow notice candidates were extracted in the first pass. Another 438 candidates were extracted from 18 archives, including Qt, Python, FreeCAD and the rendered-recipe sources. Candidate counts are extraction records, not distinct licenses or a completed attribution document.
- 177 recipe patch references across 49 retained package recipe trees resolve to included files after checking parent recipe directories. This is availability only. Patch application, build reproduction, submodule completeness and complete corresponding-source obligations have not been established.
- 1,160 package metadata/recipe/license files, totaling 15,925,061 bytes, have been preserved under release-inputs/package-evidence/. Some overlap the earlier checkpoint. The acquired large package and upstream source archives remain local inputs and are not inside this development ZIP.

The component-fulfillment matrix deliberately marks corresponding-source fulfillment and redistribution clearance false. A download link, source snapshot or package license label is not fulfillment. Qt third-party notices, optional GPL components shipped in the full runtime, Microsoft runtime redistribution terms, installation information and source-delivery method still need exact review. Do not remove runtime components solely because a tool is unused without rebuilding and validating the resulting payload.

## Native Windows dependency

Fresh official checks did not find a usable registration-free licensed Windows test route. The former developer virtual-machine address currently opens general developer tools material. Enterprise evaluation instructions require registration and Microsoft-account sign-in. The normal ISO page does not grant a free license. Windows 11 specifications list at least 4 GB RAM and 64 GB storage, with other processor, firmware, TPM and graphics requirements. The inspected local environment previously had about 1.9 GiB memory and no KVM device. This is a local observation, not a claim about every possible platform route.

No registration, account creation, remote execution, user-device access or paid service has been started. Next native execution requires an authorized licensed Windows environment with adequate resources. Wine or Linux PowerShell cannot replace Windows acceptance.

Official sources checked:

- https://developer.microsoft.com/en-us/windows/downloads/virtual-machines/
- https://www.microsoft.com/en-us/evalcenter/evaluate-windows-11-enterprise
- https://www.microsoft.com/en-us/software-download/windows11
- https://www.microsoft.com/en-us/windows/windows-11-specifications
- https://github.com/FreeCAD/FreeCAD/releases/tag/1.1.4
- https://raw.githubusercontent.com/FreeCAD/FreeCAD-documentation/main/wiki/License.md

## Still required before ready-to-use delivery

1. Complete exact payload-to-component/source/notice mapping and redistribution obligations, including the full runtime rather than only this priority subset.
2. Execute installation, application startup, Arabic/spaced paths, edit/save/reopen/export, shortcut behavior and selective uninstall on native Windows. Capture pixels and explicit positive assertions.
3. Measure responsiveness and memory on a recorded medium Windows machine. Resolve remaining localization and professional-workflow/library gaps without describing illustrative geometry or symbols as certified engineering libraries.
4. Deliver a tested install-and-use distribution only after those gates pass. A compiled EXE, source ZIP or Linux test report is not that outcome.
