# Arabic workflows, development checkpoint 58

24 November 2026

This checkpoint completes a bounded Arabic presentation pass across Delta Engineering's current custom workflows. It is development source, not a tested Windows release or engineering approval.

## Changed

- Custom warnings and errors now use actionable Arabic messages. The catalog has 233 entries; automated coverage checks 216 literal validation messages found in the application. Dynamic coordinate-line errors include the line number. Unknown external errors retain the original technical detail after Arabic guidance.
- Input, warning, confirmation and information dialogs opened by custom commands use Arabic buttons and right-to-left layout. Styling is applied to the matching custom dialog only. No application-wide translator is installed.
- Numeric and coordinate fields remain left-to-right, including multiline coordinate input. Axes, units, filenames, technical identifiers, terminal references, source links, saved data and schema keys are not translated.
- Preflight severities and diagnostic details are Arabic. Object labels remain intact. Measurement headings, source-choice roles, nominal tube statuses and snap-mode status text are localized.
- Status and selection labels use plain text, so names containing angle brackets are displayed rather than interpreted as markup.
- Custom native mechanical/electrical sheet headings, safety disclaimers and scaled-output calibration captions are Arabic. The sheet geometry and calibration line dimensions are unchanged.

## Verification

Linux FreeCAD 1.1.4 only:

- 25 of 25 nonvisual suites passed.
- 41 of 41 GUI suites passed with explicit fresh completion, zero exit, and checks for fresh error files and exception diagnostics.
- New Arabic GUI test exercises actual modal OK/Cancel and Yes/No buttons, actionable edge-reselection warning, Arabic numeric model creation, preflight details, and RTL versus LTR field behavior.
- Actual 1100 by 800 screenshots and rendered PDF pixels were inspected. The final electrical-sheet disclaimer was checked after correcting a replacement-order defect. A temporary translation approach was removed after visual review exposed a native-menu redraw problem; the final implementation uses dialog-local button styling instead.
- This is regression evidence, not a claim that every text combination or every downstream platform layout has been tested.

Evidence: `evidence/developer-regression.json`, `evidence/gui-arabic-full.json`, `evidence/arabic-ui-results.json`, `evidence/arabic-*.png`, and the existing generated drawing PDFs. The new tests are `tests/arabic_presentation.py` and `arabic_ui_test.FCMacro`.

## Visible limits

- Native FreeCAD menus, property names, start page, file chooser internals, workbenches and upstream dialogs are not fully translated by this pass. The screenshots deliberately show this boundary. Generic shared input fields are left-to-right for technical input; Arabic text remains accepted.
- Unknown kernel/import/export errors may still include English technical detail, accompanied by Arabic next-step guidance.
- Existing saved native sheets retain their own content. Newly generated sheets use the revised Arabic template. No existing project files are silently migrated.
- Pipe and electrical tools remain geometric/logical tools with the limits already stated in their UI and output. No pressure, stress, code compliance, construction readiness or electrical safety certification has been added.

## Release state

The existing untested Windows reference installer was not rebuilt or modified. Its SHA-256 remains `edaf079f5b28080525a7d2c7d6a746d5c99416e8e3753697bb76913c9316110e`, size 815,973,444 bytes. It does not contain this source-only localization checkpoint.

Native Windows installation/execution/clean-machine testing, distribution and corresponding-source fulfillment, signing/delivery, target-machine performance and the broader professional-workflow gates remain open. See `WINDOWS-CONSOLIDATED-RELEASE-GATES.md`. The integrated single-application goal is unchanged. This archive must not be presented as the user's finished install-ready product.
