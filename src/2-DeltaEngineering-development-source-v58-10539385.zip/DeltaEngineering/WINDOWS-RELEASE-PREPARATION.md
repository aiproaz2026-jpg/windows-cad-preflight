# Windows release preparation, not a Windows release

## Local evidence at V52

The only available execution runtime is the extracted Linux AppImage. No Windows FreeCAD executable, portable Windows runtime archive, Windows execution environment, or Windows installer compiler was found in the development inputs/environment inspected for this checkpoint. This is an environment finding, not a claim that a Windows runtime is unavailable elsewhere.

The local inventory records 264 license/notice file candidates and the runtime's 328-line package listing. A filename hit can be an unused license database entry, not the license of a shipped binary. These records are leads for review, not a software bill of materials, license clearance, or permission to redistribute. The Linux inventory must not be reused as the Windows dependency manifest.

`python development/inventory_runtime.py --runtime /path/to/runtime --output /path/to/inventory.json` scans without executing a runtime. It hashes candidate binaries/notices and checks whether `bin/FreeCAD.exe` is a real x86_64 PE file. It always reports `release_ready: false`. File presence, a valid PE header, and license filenames do not pass the release gates.

## Proposed single-application layout

```text
DeltaEngineering/
  LaunchDelta.cmd
  LaunchDelta.FCMacro
  Mod/DeltaEngineering/
    Init.py
    InitGui.py
    DeltaEngineering/...
  runtime/
    bin/FreeCAD.exe
    [complete verified official Windows runtime, including its dependencies/notices]
  licenses/
    DeltaEngineering-GPL-3.0.txt
    [reviewed third-party license notices, mappings, and source fulfillment material]
  release/
    runtime-origin.json
    runtime-inventory.json
    windows-test-results.json
    manifest.sha256.json
```

This preserves embedded native tools in one application launch. It is not permission to make the user install and operate separate helper applications. The existing launcher is a fail-closed template, not tested Windows installation machinery. The complete module stage is `package/Mod/DeltaEngineering`; launcher files currently live at the development root and must be assembled into the final application root by future packaging work.

## Gate order

1. Obtain the official Windows x86_64 runtime archive and its independent checksum evidence. Record original observed download URL, checksum source, version, architecture, archive hash, acquisition time and complete extraction layout. Do not substitute Linux binaries or a remembered release URL.
2. Run static inventory on the actual extracted Windows tree. Map shipped executable libraries and Python packages to versions, license texts, copyright notices, source locations and redistribution obligations. Resolve unmatched files and mixed-license resources. Preserve the complete runtime notices. Review brand/icon and modified-distribution requirements separately. Do not infer permission from FreeCAD's top-level license alone.
3. Assemble the proposed tree without editing the installed user's system. Recheck every copied hash. Include source for the original module and fulfill each third-party component's applicable source/notice requirements. A checklist is not legal clearance.
4. Prepare and compile an installer using available, reviewed, no-cost tooling. Use per-user installation unless an actual requirement needs elevation. Start-menu shortcut must target this application. Do not overwrite unrelated FreeCAD profiles, register file associations, add network updaters, or uninstall shared dependencies without explicit product decisions and tests.
5. Execute clean Windows installation and first launch. Confirm one entrypoint, native embedded workbenches, no separately operated helper applications, Arabic/spaced user paths, offline launch, save/reopen and fixture restoration. Test PDF physical scale, STEP/DXF readback, invalid-model refusal, dialogs and layout in actual Windows pixels. Capture version/OS/hardware and explicit results.
6. Test uninstall and reinstall without deleting user projects. Exercise normal-user permissions, missing/corrupt files, disk-space failure, installation cancellation and source/notice access. Malware/signing/reputation handling needs an explicit release decision; do not invent signing or claim trust based on local tests.
7. Measure startup, memory, editing and export on an actual medium Windows machine with recorded hardware and representative mixed documents. Linux timings do not settle the user's requirement.

## Concrete dependency

Local preparation can advance inventory tooling and a blocked package plan. It cannot truthfully deliver the requested install-and-use Windows product until an actual verified Windows runtime and a Windows test environment are available, the distribution obligations are reviewed and fulfilled, and an installer is built and tested there. No external acquisition, account, paid service or device access was performed in this preparation checkpoint.

V53 closes the missing local Windows runtime/compiler inputs: checksum-verified official portable runtime and matching FreeCAD source, actual Windows binary/notice inventory, locally built current NSIS compiler, one self-contained cross-compiled setup candidate with static payload readback. The candidate remains local/UNTESTED, not license-cleared or Windows-executed and is NOT delivered as a finished product. See WINDOWS-PACKAGING-STATUS.md and provenance/build reports. 202 runtime package rows match the source lock; 33 do not. Four exact package archives/recipe/license inputs were acquired with matching lock hashes; full corresponding-source/redistribution review remains open. No accounts, paid services, remote jobs or device access used. Functional application code remains V50 tested through V51.
