# نطاق القبول وخطة الإصدار

## الهدف الكامل
برنامج واحد لويندوز، مجاني، يستخدم مكتبات مدمجة ولا يطلب تشغيل برامج مساعدة. يضم الرسم الميكانيكي والقطع والتجميعات ثلاثية الأبعاد، المواسير ومحطات الطلمبات، والرسومات الكهربائية، مع دعم العربية. يستهدف الأجهزة المتوسطة وما فوق، لكن مواصفات التشغيل الفعلية تحتاج قياساً على ويندوز ومع أحجام مشروعات معروفة.

## حالة هذه الحزمة
هذه شيفرة مرحلة تكامل وظيفية، وليست المنتج المطلوب كاملاً ولا مثبت ويندوز. الاسم «دلتا» اسم تطوير قابل للتغيير، وليس اسماً اختاره المستخدم.

تم التنفيذ والاختبار على FreeCAD 1.1.4 في Linux:
- رسم دائرة مقيدة بالكامل وبثقها إلى جسم ميكانيكي باستخدام Sketcher وPartDesign الأصليين.
- مواسير مجوفة بأقطار وسمك ومسار قابل للتعديل، وحصر طول خط المركز.
- رموز كهربائية عامة ووصلة منطقية مرتبطة بعناصرها، تتغير هندستها عند نقل الرمز.
- حفظ المشروع وإعادة فتحه مع بقاء الخصائص والمراجع والعناوين العربية.
- أوامر عربية لإضافة ماسورة ورمز وتوصيل رمزين وحصر الأطوال داخل واجهة واحدة.
- اختبار هندسة وتراجع وتصدير STEP وقراءة النتيجة ومقارنة الحجم.

غير منفذ أو غير متحقق بعد:
- التجميعات الميكانيكية المقيدة داخل سير العمل المخصص، كتالوجات الطلمبات والوصلات، أدوات التخطيط التفصيلية للمحطات.
- الأكواع والوصلات الحقيقية عند التقاء المواسير. النموذج الحالي يجمع قطع أنابيب مستقيمة، ولا ينتج وصلة تنفيذية.
- محرر دوائر كهربائية متخصص، أرقام أطراف وأسلاك متكاملة، مراجع متقاطعة وتوافق معايير.
- حسابات اختيار الطلمبات والضغط والحماية والكابلات، أو أي اعتماد هندسي للتنفيذ.
- تحرير DWG شامل أو توافق مضمون مع أوتوكاد. لا يوجد دعم DWG مخصص منفذ في هذه الحزمة.
- تعريب كامل لكل قوائم FreeCAD الموروثة، اختبارات اتجاه الكتابة في كل نافذة وطباعة.
- مثبت موحد مكتمل ومختبر على ويندوز، توقيع رقمي أو اختبار أجهزة متوسطة.

## اختبارات الإصدار النهائي
1. تثبيت وتشغيل وإزالة نظيفة على ويندوز مدعوم دون تنزيل مساعدات أثناء الاستخدام.
2. تحرير فعلي وحفظ وإعادة فتح وتراجع وإعادة، مع ملفات ومسارات عربية.
3. اختبارات أبعاد ووحدات وحجوم ومراجع تجميعات ورفض إدخال غير صالح.
4. اختبار استمرارية المواسير والوصلات وحصر الكميات على أمثلة يراجعها مختص.
5. اختبار اتصالات كهربائية وترقيم ومراجع عبر الصفحات وفق الوظائف المتفق عليها.
6. مقارنة الوارد والصادر مع ملفات مرجعية، وإظهار أي عناصر غير مدعومة دون فقد صامت.
7. اختبار سرعة الاستجابة واستهلاك الذاكرة على جهاز متوسط مع توثيق حجم النموذج ومواصفات الجهاز. لا يصح استنتاج مواصفات دنيا من نموذج صغير.
8. فحص بصري مباشر للواجهة والرسومات والطباعة، وليس نجاح التشغيل البرمجي فقط.
9. جرد تراخيص المكونات والرموز والخطوط وإرفاق النصوص والمصدر المطلوب قانوناً.

## مثال الاختبار
المثال المرفق توضيحي وقابل للحذف: قاعدة دائرية ومسار أنابيب ورمزان كهربائيان. ليس تصميم محطة حقيقية ولا يقلص المتطلبات الأصلية إلى هذا المثال. إعدادات النموذج بالمليمتر.

## ما يلزم لاحقاً
توفير بيئة اختبار ويندوز مجانية مصرح بها، ثم عينة مشروع حقيقي ونتيجة مطلوبة عندما تتاح. لا توجد حاجة لمعلومات شخصية أو تراخيص مدفوعة. لا يجوز وصف هذه الحزمة بأنها جاهزة للتثبيت والاستخدام النهائي.

## تحديث مرحلة التكامل الثانية
أضيف كوع هندسي مجوف ٩٠ درجة مستقل مع اختبار الحجم، دون كتالوج أو تصنيف ضغط. أضيف نموذج بيانات أطراف وأسلاك مع رفض التكرار والمراجع المفقودة وتصدير قائمة اتصالات JSON. أضيف تجميع ميكانيكي أصلي بروابط مكونات وتثبيت القاعدة؛ لم تختبر قيود التزاوج أو الحركة. هذه إضافات محدودة ولا تحول المرحلة إلى المنتج الكامل. اختبار تحميل الوحدة تلقائياً وإعادة تكوين مشروع محفوظ نجح في عملية جديدة على Linux.

## تحديث المشروع المترابط
أصبح أمر المثال ينشئ مشروعاً واحداً يحوي تجميعاً ميكانيكياً وروابطه ومساراً متصلاً بكوع وثلاث وصلات كهربائية محددة الأطراف، مع مرجع من رمز المحرك إلى المكون الميكانيكي. اختبر حفظه وإعادة فتحه وفحص تطابق نهايات خط المركز والتلامس وعدم التداخل. اكتشف الاختبار الأول أن فحص التلامس وحده لا يكشف كل حالات عدم التطابق، فأضيف فحص النهايات صراحة. لا يعد هذا تخطيط محطة أو تصميماً هندسياً معتمداً.

## إخراج اللوحات في مرحلة التطوير
أضيفت لوحتان أصليتان قابلتان للتعديل عبر TechDraw: مسقط علوي ومنظور ميكانيكي مرتبطان بالنموذج، ولوحة اتصالات كهربائية منطقية وقائمة أطراف. اختبر تصدير PDF وفحصت الصفحتان بصرياً. عناوين اللوحات ما زالت بالإنجليزية، ولا توجد أبعاد تنفيذية أو ادعاء مطابقة معايير. يلزم تحسين انتظار اكتمال الإسقاط قبل التصدير بدلاً من مهلة زمنية ثابتة في الإصدار النهائي.

## مسار مواسير قابل للرسم والتعديل
أضيف تحويل مسار مفتوح بزوايا قائمة إلى مواسير مجوفة وأكواع مقصوصة بنصف قطر محدد، مع ربط النتيجة بالمسار الأصلي وإعادة التكوين عند تعديله. اختبرت مسارات مسطحة وثلاثية الأبعاد وطول خط المركز والحجم والتلامس، ورفض المقاطع القصيرة والزوايا غير القائمة والتداخل بين أجزاء غير متجاورة. هذه هندسة مسار وليست مكتبة وصلات معتمدة أو حساب ضغط. فحص التداخل الحالي زوجي وقد يحتاج تحسين أداء عند كبر المسار.

## تصحيح جاهزية الإخراج وتعريب الناتج
أُلغي انتظار مدة ثابتة قبل إخراج PDF. الأمر الرئيسي يسقط هندسة المصدر الحالية بصورة متزامنة ثم ينشئ ملفي PDF متجهيين، مع إظهار الخطأ وحماية الملفات السابقة عند فشل التوليد. اختبرت تعديلات فورية قبل الإخراج وأسماء ملفات عربية وفشلاً متعمداً في الصفحة الثانية. اللوحات الأصلية عبر TechDraw ما زالت قابلة للتعديل، لكن ملفات الإخراج الآمنة تولد من النموذج الحالي ولا تدعي نقل كل تعديل يدوي على تلك اللوحات. أصبح ناتج PDF بعناوين عربية وتسميات الأجهزة والأطراف، وفحص بصرياً. الإخراج ملائم للصفحة وليس بمقياس طباعة معتمد. قد يحجب الحساب المتزامن الواجهة مؤقتاً في النماذج الكبيرة؛ تحسين الاستجابة يظل مفتوحاً.

## محرر الكهرباء التجريبي
أضيفت لوحة عربية لإدارة الرموز والأطراف والأسلاك. إعادة تسمية الطرف تحدث مراجع التوصيل معاً. حذف الطرف أو الرمز المتصل يحتاج تأكيد إزالة الأسلاك، ويمكن التراجع عن العملية واستعادة المراجع. جربت إنشاء وتوصيل وفصل وحذف وإلغاء حذف وإعادة تسمية، ثم حفظ وإعادة فتح وإخراج PDF من نفس المشروع. تحديد السلك يظهره في الرسم. المحرر ما زال لرموز عامة وليس نظام رسومات كهربائية كامل بمعايير ومكتبات تنفيذية.

## الرسم والأبعاد المرتبطة
أضيفت لوحة إحداثيات عربية لرسم مسارات Draft أصلية وتعديلها وإضافة بعد خطي مرتبط بين نقطتين وتحويل نفس المسار إلى مواسير. تعديل الإحداثيات يحدث البعد والمواسير معاً؛ إذا كسر التعديل هندسة المواسير يلغى بالكامل. تغيير عدد النقاط ممنوع عند وجود أبعاد مرتبطة بترتيبها. جربت التراجع والحفظ وإعادة الفتح وإخراج PDF ببعد فعلي بالمليمتر وأسهم. الإخراج الحالي لمسارات مستوى XY وأبعاد خطية فقط، ملائم للصفحة وليس معيار رسم تنفيذي أو مقياس طباعة معتمداً.

## مشروع فارغ من عمل المستخدم
أضيف بدء مشروع فارغ بأقسام الرسم والميكانيكا والمواسير والكهرباء. اكتشاف عناصر الإخراج لم يعد يعتمد على أسماء النموذج التجريبي. اختبر إنشاء مسار وبعد ومواسير ورموز وتوصيل من الصفر، ثم تعديل وحفظ وإعادة فتح وإخراج لوحتين. استبعدت الأشكال المكررة الناتجة من مجموعات المستند ومسارات الإنشاء التابعة. المستند الفارغ يرفض بوضوح؛ لا توجد دعوى دعم كل أنواع التجميعات أو واردات أوتوكاد أو المخططات التنفيذية.

## فحص المتانة
اختبرت أحداث نقر وكتابة فعلية عبر Qt على واجهة لينكس، ثم التعديل والتراجع والإعادة والحفظ والفتح. رُفض الإدخال غير الرقمي والنقاط المكررة وغير المحدودة وفهارس الأبعاد الخاطئة والتعديل على مسار في مستند آخر. يفحص تعارض أسماء المجموعات قبل تغيير المستند. إخراج PDF يرفض أكثر من ١٤ سلكاً أو التسميات الطويلة بدلاً من قصها بصمت؛ تقسيم الصفحات لم ينفذ بعد. هذه اختبارات آلية وليست تجربة بشرية على ويندوز.

## رسم يدوي ودقيق
إدخال مطلق ونسبي ووحدات طول، وطول وزاوية، والتقاط نقاط من نافذة الرسم مع معاينة وشبكة وتعامد ونهاية ومنتصف خط. نفس جدول المسار يدعم التحريك والدوران ثم الحفظ كتعديل واحد قابل للتراجع. اختبرت نقرات فعلية وإنهاء بالرسم وإلغاء بالكيبورد، والتقاط النهاية والمنتصف في الإسقاط، والحفظ والفتح والأبعاد والمواسير المرتبطة. مستوى الرسم XY بارتفاع محدد، وليس نظام قيود هندسية احترافياً كاملاً.

## من المقطع إلى الجزء
إضافة مستطيل ودائرة بإحداثيات ووحدات دقيقة، وبروز مصمت مرتبط بالمقطع وتعديل المركز ونصف القطر والارتفاع. تغيير أبعاد المستطيل يحدث الجسم والبعد المرتبط؛ التعديل المتقاطع ذاتياً يرجع دون تغيير المشروع. اختبرت أزرار الواجهة والحفظ والفتح والتراجع والتصدير وفتحاً مستقلاً من النسخة المجمعة للمصدر. لم تنفذ الثقوب والجيوب والشطف وحسابات التصميم أو التجميع الاحترافي الكامل.

## قيود أصلية ومقياس
قوالب مستطيل وحلقة بقيود Sketcher كاملة، وتعديل قيود الأبعاد مع تحديث المصمت والتراجع، وفتح محرر Sketcher الأصلي وإغلاقه. اختبرت تعارضاً فعلياً في المحلل والتراجع عنه، وبروز مقطع بفتحة مغلقة مع تحقق الحجم. أمر PDF مستقل بمقياس محدد على A3 ويرفض تجاوز الصفحة، مع خط معايرة ١٠٠ مم. قيست متجهات PDF للتحقق من مستطيل نموذج ٣٠٠×١٠٠ مم يطبع ١٥٠×٥٠ مم عند ١:٢. يلزم الطباعة ١٠٠٪ والتحقق من المعايرة؛ لا يوجد اعتماد معيار أو تصميم.

## تخطيط الكهرباء والقوائم
تحريك رمز بإحداثيات دقيقة وإزاحة مسار متعامد مع المحافظة على اتصال الأطراف والتراجع والحفظ والفتح. يمنع المحرر القديم بعد تغيير المستند من تعديل عناصر مشابهة دون تحديث. قوائم PDF تتوزع على صفحات وتلتف الأسطر الطويلة؛ اختبرت ٨٠ توصيلاً في ٥ صفحات وتحققت من ظهور كل معرّف مرة واحدة. ليس تخطيطاً تلقائياً لتجنب العوائق أو اعتماداً لرموز كهربائية معيارية.

## تحرير المصمتات
قص ودمج وتقاطع عبر ميزات Part الأصلية وروابط مصادرها. اختبرت فتحة فعلية وحجمها وتحديث نصف قطر أداة القص والتراجع والفتح والتصدير، وأحجام الدمج والتقاطع الدقيقة. العملية الفارغة أو غير الصالحة مرفوضة. أصلحت سباق تهيئة نافذة العرض في الأبعاد بإنشاء كائن البعد الأصلي مع مستوى واضح.

## تبادل الهندسة
تصدير STEP مع إعادة قراءة والتحقق من الحجم قبل استبدال الملف، واستيراد هندسة STEP مع التراجع والإعادة. DXF لمقاطع XY على Z=0 فقط، مع تحقق إعادة قراءة أصلي للمستطيل والدائرة. لا يضمن تاريخ الميزات أو الأبعاد أو النصوص أو الطبقات، ولا يوجد ادعاء دعم DWG.

## مساحة العمل وصحة الحالة
قسمت أدوات الأجزاء إلى مجموعات وحقول حسب المهمة، وعرض اللوحة الافتراضي ٤٠٠ بكسل بدلاً من نصف النافذة. اختبرت التنقل والنقر الفعلي على الأدوات الظاهرة وعلى نافذة ١١٠٠×٨٠٠. يمنع التصدير إذا كان قيد أو عنصر أصلي غير صالح حتى لا يخرج آخر شكل مخزن كأنه الحالة الحالية.

V23: explicit generic tee-port linked tube legs. Three distinct outward local ports, one generated leg per port; length editing, link-driven OD/wall/start/direction. Source translation/rotation and existing parent-Part placement propagate; leg Placement locked. Generated legs must remain outside Part containers. Source hierarchy changes require recreating legs and output validation blocks stale connection geometry. Direct invalid source clears dependent shapes. This is geometry-only attachment, no collision, weld, hydraulic, electrical or pressure-network validation. STEP/PDF, UI, independent staged restore, hollow volume, face contact/no overlap, undo/redo/rollback tested on Linux. Windows distribution remains untested.

V24: explicit selection loader now loads nominal tube/tee lengths, bend radius or generated-port-leg length/port. Automatic selection still preserves typed entries. Custom OD/wall clears preset selection instead of silently picking the closest nominal size; explicit preset required before applying. PortSource navigation selects the dimensional source. Direct nominal-size application to dependent leg blocked before any dimensional-provenance properties are written. Actual UI tests exercise these paths, including custom 61 mm diameter and restored nominal 60.3 mm, plus prior selection/tube/tee/compact/integrated/export-limit regressions.

V25: five ORIGINAL ILLUSTRATIVE electrical template choices (generic block, motor concept, open-switch concept, coil concept, earth concept). These are not IEC/ANSI or manufacturer symbols and do not claim standard pin order, device ratings or circuit correctness. Selection applies to new device creation only; existing editable terminals preserved and template identity read-only to avoid silent rewiring. Terminal graph, movement, rename, PDF tags/terminal labels/netlist, UI creation of each template and independent staged-source restore tested. Leaders are schematic drawings only. Crossings remain non-junctions unless terminal graph explicitly connects them; no automatic crossing/junction/collision analysis. No source artwork copied.

V26: explicit terminal-graph connectivity inspection. Deterministic connected-component groups, isolated terminals and duplicate reversed wire-pair warnings displayed in Arabic read-only table. Device-internal connections and geometric crossings are NOT inferred. Unwired terminal is descriptive, not a design failure. NETnnn labels are report-time indices and can change after edits, not persistent user net labels. Cycle/transitive grouping, reverse duplicates, isolated device terminals, rename/delete consistency tested. This does not simulate voltage/current, infer motor windings/switch contacts, certify earthing or analyze safety.

V27 placement correctness: current-source PDF and explicit-scale PDF now include parent Part global placement for leaf geometry, with native Link handling and no double transformation. Regression: translated/rotated parent plus separate reference projects 200 x 100 mm at 1:1; source shape unchanged, nested link parent checked. Electrical schematic uses Position in a shared coordinate frame, not arbitrary transformed container/object Placement; export blocks nonidentity electrical Placement rather than silently drawing wrong labels/wires. STEP/DXF/native-sheet behavior not broadened by this change.

V28 STEP placement fix: native export of selected child solids did not include ancestor placement in probe. Export now stages world-shape copies in a temporary document, cleans it and restores active document, and readback verifies volume AND six world-coordinate bounds. Labels retained but no original feature history claim. Test bounds [50,200,0,250,300,30], source unchanged and original documents retained. DXF remains root XY-wire-only; transformed parent now explicitly rejected before target replacement, rather than silently flattened. STEP imported viewport visually inspected.

V29: developer regression runner collects 13 suites, requires exact success marker as well as process status and no exception diagnostic. Supports fixture relocation in temporary script copies, per-suite timeout and machine-readable results. It is NOT a Windows validation or installer. Staging tree now includes required original SVG drawing template. README current-status summary supersedes chronological obsolete claims below it.

V30: endpoint/straight-edge-midpoint snap candidates now use global parent/Link geometry, not child-local coordinates. Hidden Part/Body ancestry excluded from snaps and visible model discovery. Tests verify translated/rotated parent endpoint/midpoint exact coordinates, hidden-parent exclusion and native Link candidates. Existing snap plane/ortho/candidate limits remain. No intersection/tangent/arc snapping added. All 13 nonvisual suites and hybrid/compact UI regressions pass.

V31 custom-command frame boundary: custom extrusion, linked routed piping, boolean controls and linked dimensions accept root-frame sources only, not source objects inside native Part/Body containers. A parent container can change without recomputing linked leaf features, so output validation independently rejects such links rather than trusting cached shapes. Native tools remain available for their own supported workflows. Ordinary/scaled PDF/STEP of valid final leaf solids still supports parent placement as V27/V28 describe. This is a guard, not generalized assembly-aware dependency editing. Native PartDesign Pad profiles are unaffected. New frame-guard suite joins the developer runner (14 suites).

V32: canonical-source archive builder added. Earlier archives included only a partial duplicate package tree, despite complete root module; install only root or full rebuilt stage, never both. Builder now generates complete staging tree from canonical Python/SVG/Init files, excludes logs/caches and validates every entry CRC/hash. Fresh archive isolated module restore and native-sheet template lookup checked. Development-only source, no runtime or installer.

V33: read-only technical project preflight command collects multiple native/constraint/parametric/frame/electrical-graph faults and custom nominal-dimension notes, and selects a row object without repairing/mutating design values. No-error result is NOT engineering approval. The Arabic header lists excluded collision/pressure/stress/electrical safety/standards/Windows checks. Diagnostic details remain partly English, localization incomplete. 15 developer suites pass plus command/compact UI regressions. Current model counts exclude invalid/null geometry; errors separately identify those objects.

V34 scale probe: single local Linux runs exercise geometric routes at 5/10/20 segments and explicit graph at 25/75/150 devices. Results in evidence/scale-probe.json; timing is local, cold/warm/shared-host variable, not minimum computer requirements, Windows benchmark or UI/PDF responsiveness claim. A proposed bounding-box optimization showed no measured improvement and was NOT retained. No performance promise follows.

V35 refines V32 Unicode-path finding: isolated -M discovery under Arabic path passed when LANG and LC_ALL were set to C.UTF-8 before runtime launch. Default AppImage process used ASCII filesystem encoding, causing import failure. No loader-code workaround retained; original launcher unchanged. This is Linux locale-specific evidence, not Windows deployment. Arabic module path + document proxy restoration tested with explicit UTF-8 process locale.

V36 coordinate-text workflow: paste comma-separated X,Y,Z rows, optional header, explicit length units; copy current table as mm CSV text. Parsing/limits/duplicate/units checks complete before buffer replacement, with explicit replacement confirmation. Model unchanged until Draw new or Save edit. Invalid/cancelled paste preserves buffer. 10000 rows and 2 MB input cap. This is not arbitrary spreadsheet/file import, formula evaluation or CAD interchange. 16 developer suites pass plus actual button/table/copy/paste and compact/hybrid/selection GUI regressions.

V37 numeric safety and Arabic input: custom precision fields translate Arabic/Persian digits, Arabic decimal separator and minus; explicit unit aliases مم/سم/م/بوصة/قدم supported alongside mm/cm/m/in/ft/um. Native quantity parser probe silently misread unsupported strings, so custom fields now accept ONE numeric literal plus an allowlisted unit only, rejecting unknown suffixes, formulas, grouping separators and fractions rather than guessing. Numeric angles/scale use the same digit translation. This intentionally narrows custom expression syntax; native property editor semantics are unchanged. 17 developer suites plus Arabic coordinate-paste/button, hybrid/profile/tube UI regressions pass.

V38 native ring editing: explicit named outer/inner radius edit command updates constrained ring and linked hollow extrusion. Positive ordered radii prevalidated; transaction rollback, undo/redo, exact-volume, save/reopen, Arabic digit/unit input and actual UI edit/load tested. This is a geometric ring template, not a standard flange/gasket or pressure-rated part. 18 nonvisual suites pass.

V39 fit-to-page PDF line readability: projection line width now follows view extent, not fixed 2.5 model units. Small parts no longer render with very heavy outlines. Unit-scale invariance tested at 1/100/10000 model extents; native explicit-scale PDF line calibration unchanged. Mechanical ring and electrical symbol/netlist PDFs visually inspected. 19 nonvisual suites plus ring/symbol/integrated/pagination/export-limit GUI regressions pass. This is not a drafting-lineweight standards claim.

V40 linked linear pattern: selected root-frame single solid becomes 2-200 separate copied solids, including original location, with integer count and XYZ step; source dimensions recompute pattern. Original retained/hidden and excluded from duplicate model export; source navigation supported. Conservative axis-aligned box clearance rejects possibly touching/overlapping copies, not a general collision engine. Not fused/PartDesign feature repetition, assembly links or BOM counts. Negative steps, exact volumes, invalid spacing rollback, undo/redo, save/reopen, isolated staged restore and actual UI create/edit/source/STEP/PDF tested. 20 developer suites pass.

V41 quality correction: V40 introduced an accidental three-argument hasattr in explicit property loader. Corrected; port/ring/selection paths now freshly pass. Compact test updated expected six actions to eight and catches timer callback errors. New GUI acceptance runner requires explicit completion, zero exit, no exception/assertion diagnostics and no newly written error file. All 32 current GUI macros rerun under this gate, all pass; all 20 nonvisual suites rerun/pass. This reconciles current behavior, not proof that every older checkpoint GUI claim was valid. Earlier reporting based on missing error files was insufficient. No Windows/human usability claim follows.

V42 acceptance-runner self-test: explicit good completion accepted; deliberate emitted assertion, asynchronous callback exception, fresh error artifact and absent completion rejected. These deliberately failing fixtures are not product regression failures. Distinct report name option prevents subset runs overwriting full-suite record. Full V41 32-suite result retained; compact/selection/ports/ring rerun on final runner pass.

V43 native source-linked revolution: closed planar root-frame profile, explicit axis base/direction and angle (0,360], native Part::Revolution result with retained source. Axis must lie in profile plane and outside/tangent to conservative profile box; one valid solid required. General crossing-axis/self-intersecting revolve not supported. Native source link updates solid; custom path edits now validate dependent features before committing, unsupported crossing-source edits roll back. Create/edit/source navigation, full/partial exact volumes, invalid angle/axis, undo/redo, save/reopen, STEP/PDF and Arabic numeric UI tested. Compact solid page now has 10 tested actions. 21 nonvisual suites pass; targeted GUI reports have explicit completion/log/error gates. Prior full 32-suite GUI report belongs to V41, not a claim of full rerun at V43.

V44 read-only selection measurement: one or two selected whole objects or single Vertex/Edge/Face per entry, kernel edge length/area/volume/world bounds, circular-edge radius, vertex world XYZ, minimum two-shape separation and acute unoriented straight-edge angle. No saved drawing dimension, center-distance inference, thickness, fit/tolerance/design approval. Single document and valid supported model required to avoid stale cached measurement. Does not change design values or create objects. Transformed parent/vertex positions, separate-box 70 mm distance, radius, angle, unsupported/mixed-document rejection and Arabic result table UI tested. 22 nonvisual suites pass; targeted command/compact/measurement GUI checks use explicit success gates.

V45 schematic terminal layout: explicit left/right side and top-to-bottom name order while preserving every current terminal name exactly once. No rename/add/remove through this command; connected wires follow same named terminal, netlist identities unchanged. Not physical manufacturer pin mapping, internal device connectivity or electrical validation. Missing/duplicate/new names rejected before mutation. Undo/redo/save/reopen, actual Arabic command and exported labels/netlist tested. All 23 nonvisual suites and targeted electrical-layout/panel/symbol GUI tests pass strict gates.

V46 explicit-scale orthographic PDF: Top/Front/Right selector with fixed screen axes, A3 scale denominator/overflow rejection and 100 mm paper calibration. Front maps horizontal X, vertical Z; Right horizontal Y, vertical Z. Whole current visible model only, separate single-view page, not combined projection-standard sheets/hidden-line/production dimension layout. Asymmetric 120x80x50 mm box projects 120x80 / 120x50 / 80x50; independent vector PDF measurement at 1:2 verifies 60x40 / 60x25 / 40x25 mm. Actual Arabic UI selector and invalid projection rejection tested, pixels inspected. All 23 nonvisual suites and targeted scale/constraints/combined/compact GUI checks pass.

V47: read-only measurement now accepts two native subelements of the same object, such as two vertices or two edges. Native FreeCAD groups these in one selection entry; the command expands explicitly selected targets instead of treating them as a whole-object selection or rejecting them. Three targets and duplicate targets are rejected. Existing separate-object measurement remains tested. Actual GUI test measures two vertices of one box at 20 mm, creates no document object, and the resized dialog shows all rows without initial scrolling. Fresh full acceptance: 23 nonvisual suites and all 37 current GUI macros, explicit completion/exit/exception/fresh-error gates. Orthographic projection adds a signed asymmetric-point orientation assertion and unchanged-source assertion for all named axes. Tested Linux only, no Windows installation or engineering approval claim.

V48: native Part::Fillet constant-radius edge rounding from 1 to 32 explicitly selected edges on one root-frame solid. Arabic length input, radius edit, native source link, rollback, undo/redo and save/reopen tested. Invalid/oversized radius and wrong/duplicate selections rejected. A stored exact BREP digest refuses output/measurement and custom radius editing after source geometry changes, requiring explicit source-edge re-selection/recreation rather than silently trusting old edge indices. This is a conservative fail-closed limit, not topology-stable feature retargeting. Consumed source excluded from model output. Original native Part tools remain available. All 24 nonvisual suites and targeted fillet/compact/combined/world output/world STEP GUI macros pass. Compact 1100x800 layout and actual rounded solid workspace visually inspected. No chamfer, variable-radius fillet, manufacturing/design approval or Windows test claim.

V49 acceptance hardening: native fillet reopened in a separate GUI process, explicitly shown from the headless test fixture, and exported to PDF/STEP with readback. A 1e-9 mm upstream edit is refused by model validation and both exports. Exact BREP fingerprint is intentionally conservative and can remain changed even after restoring the same numeric dimension; reload the unchanged saved project or reselect/recreate the feature. It is not a tolerance-equivalence check. All 39 current GUI macros pass fresh strict gates (corrected fixture rerun replaces its initial failed attempt). All 24 nonvisual suites pass.

V50: read-only measurement adds acute/unoriented angle for two planar faces, including two faces of one object. Parallel faces report 0 degrees, perpendicular faces 90 degrees; curved faces intentionally report no face angle, not an invented tangent/dihedral angle. Existing minimum distance remains shortest surface separation, never normal gap/center distance/wall thickness. Native full-precision angle math and rotated-parent geometry tested in the nonvisual suite; actual GUI adjacent faces show 0 mm separation and 90 degrees, screenshot inspected. All 24 nonvisual suites plus three measurement GUI paths rerun/pass. Full 39-suite evidence remains V49 scoped, not a full V50 rerun. No persistent angular dimension or engineering tolerance claim.

V51 verification-only checkpoint: all 40 current GUI macros freshly pass strict completion/exit/exception/fresh-error gates on the V50 functional source. Independent V50 archive re-extraction passes all 24 nonvisual suites using relocated fixtures; 358 manifest entries/112 Python sources parsed and checked, all canonical/staged module files byte-identical. No new application functionality or Windows release claim.

V52 release preparation only: WINDOWS-RELEASE-PREPARATION.md records single-application layout, actual runtime/license/source review and installer/Windows acceptance gates. Read-only inventory tool hashes locally present runtime binary candidates (1888), notice-file candidates (264) and includes the Linux package listing (328 lines); these are not a cleared Windows SBOM. PE-header self-tests pass; tool never marks release ready. Actual Windows runtime and test environment plus distribution-obligation review are concrete remaining dependencies. No Windows executable/portable archive or installer compiler was available among inspected local inputs. No external acquisition, spending, accounts or device access performed. Functional application remains V50 code with V51 verification.

V53 closes the missing local Windows runtime/compiler inputs: checksum-verified official portable runtime and matching FreeCAD source, actual Windows binary/notice inventory, locally built current NSIS compiler, one self-contained cross-compiled setup candidate with static payload readback. The candidate remains local/UNTESTED, not license-cleared or Windows-executed and is NOT delivered as a finished product. See WINDOWS-PACKAGING-STATUS.md and provenance/build reports. 202 runtime package rows match the source lock; 33 do not. Four exact package archives/recipe/license inputs were acquired with matching lock hashes; full corresponding-source/redistribution review remains open. No accounts, paid services, remote jobs or device access used. Functional application code remains V50 tested through V51.

V54 packaging follow-through: exact current registry name/version/build license leads now cover all 235 Windows package rows. Ten exact package archives/recipe-license inputs retained, five additional component source inputs hash-verified plus Python source recipe-MD5 match. Evidence and source/patch/license metadata included, not full compliance or file-to-package certification. Candidate one-file setup remains local and unexecuted on Windows. See WINDOWS-PACKAGING-FOLLOWTHROUGH.md.

V55 packaging correctness fix: Linux PowerShell tiny-fixture execution exposed the chunk glob also matching its open payload.zip. Restricted chunks to exactly three decimal digits, reran successful extraction/hash checks, nonempty-target refusal, corruption refusal, uninstall path-escape refusal, and preservation of modified/unlisted project files. Corrected candidate rebuilt and internal payload/extractor statically read back. These are Linux PowerShell 7.7 tests, NOT native Windows PowerShell 5.1/NSIS/install/UI/uninstall acceptance. Prior candidate is explicitly superseded and remains undelivered. Qt full source acquired via official archive (recipe MD5 match), CalculiX source recipe-SHA256 verified; full corresponding-source/distribution review remains unfinished. Functional CAD code unchanged.

V56 release-logic verification: corrected extractor ran on the full embedded Windows payload under Linux PowerShell 7.7, checked every installed-manifest hash, and selective removal preserved a modified launcher and unlisted user project while removing all other payload files. Native Windows/PS5.1/NSIS registration/UI/permissions remain untested. Installer source now explicitly refuses pre-Windows-10 and non-x64 targets; cross-compilation passes warnings-as-errors, behavior unexecuted. OCCT/PySide upstream exact tags resolved to commits and source snapshots acquired; unlike recipe-hash-matched archives, these are tag provenance, not byte-identical recipe archives. Full source fulfillment and dependency review remain open. See evidence/windows-tagged-sources.json. Latest local candidate is v56 UNTESTED, never delivered as a release.
